#########
# Part 0# load R package
#########
library(mlbench) #Version 2.1.3
library(Cubist)   #Version 0.4.2.1
library(tseriesChaos) #Version 0.1.13.1
library(TTR)       #Version 0.24.3
library(ifultools) #Version 2.0.26
library(wmtsa)     #Version 2.0.3
library(DescTools) #Version 0.99.49
library(scatterplot3d) #Version 0.3.44
library(forecast)   #Version 8.21
library(gtools)     #Version 3.9.4 
library(infotheo)   #Version 1.2.0.1
library(rEDM)       #Version 1.2.3
library(seasonal)#Version 1.9.0
library(ape)     #Version 5.7.1
library(rgee)    #Version 1.1.5
library(ggplot2) #Version 3.4.2
library(tidyr)   #Version 1.3.0
library(ggplot2) #Version 3.4.2
library(reticulate) #Version 1.28
library(earlywarnings) #Version 1.1.29
library(gridExtra) #Version 2.3
library(EpiEstim)  #version 4.1.3


#########
# Part 1# surrogates
#########

############# method 1, Fourier-transformed data 
#Transforming the original time series data to the frequency domain using the Fourier transform.
#Randomizing the phases of the Fourier-transformed data.
#Transforming back to the time domain to obtain a surrogate time series.
#Repeating steps 1-3 multiple times to generate a distribution of surrogate datasets.
#Comparing the statistic of interest (e.g., the Kendall rank correlation) calculated on the original data to the distribution obtained from the surrogate datasets.


Fourier_method<-function(number_surrogate, original_data) {
  library(tseries)
  # Function to generate a surrogate dataset
  generate_surrogate <- function(data) {
    n <- length(data)
    fft_data <- fft(data)
    # Generate random phases
    random_phases <- exp(1i * runif(n/2 - 1, -pi, pi))
    # Apply random phases
    fft_data[2:(n/2)] <- fft_data[2:(n/2)] * random_phases
    fft_data[(n/2 + 2):n] <- Conj(fft_data[2:(n/2)])
    # Inverse Fourier transform to get surrogate data
    surrogate_data <- Re(fft(fft_data, inverse = TRUE) / n)
    return(surrogate_data)
  }
  
  # Generate number of surrogate datasets
  surrogate_stats <- numeric(number_surrogate)
  set.seed(2)
  for (i in 1:number_surrogate) {
    surrogate_data <- generate_surrogate(original_data)
    surrogate_stats[i] <- cor.test(1:length(surrogate_data), surrogate_data, method = "kendall")$estimate
  }
  
  # Calculate the Kendall rank correlation on the original data
  original_stat <- cor.test(1:length(original_data), original_data, method = "kendall")$estimate
  
  # Calculate the p-value
  if(original_stat>=0) {p_value <- sum(surrogate_stats >= original_stat) / number_surrogate}
  if(original_stat<0) {p_value <- sum(surrogate_stats <= original_stat) / number_surrogate}
  
  return ( c(p_value, original_stat/abs(original_stat)) )
  
}  


# example
set.seed(123)
original_data <- arima.sim(model = list(ar = 0.9), n = 50) # Generate some example time series data
plot(original_data, col="red", type="o")
num_surrogates <- 100 # number of surrogates

Fourier_method(number_surrogate=number_surrogate, original_data=original_data)

#[1] 0.11 1.00 # 0.11 is p value; 1.00 means upward (-1 means downward)
#thus, insignificant upward.



############# method 2, Ebisuzaki (1997), Generate phase-randomized surrogate series as in Ebisuzaki (1997)
number_surrogate=100
#original_data=AR1(new_data$Incidence,leng_window,1)
#original_data=no_outliers(new_data$Incidence,leng_window,1)
#original_data=Max_eigen(new_data$Incidence,leng_window,1)

Ebisuzaki_method<-function(number_surrogate, original_data) {
  
  original_datass=original_data[!(is.na(original_data))] #NA remove
  
  if( all(original_datass==0) || length(unique(original_datass))==1 ){tau_original=NA;p_value=NA;trendss=NA}
  if( !(all(original_datass==0) || length(unique(original_datass))==1) ){
    if(length(original_datass)<2) {tau_original=NA;p_value=NA;trendss=NA }  
    if(length(original_datass)>=2) { 
      library(astrochron)
      surrogates <- as.data.frame( matrix(nrow=length(original_datass)), ncol= number_surrogate)
      set.seed(2)
      for (i in 1:number_surrogate) {
        surrogates[,i] <- surrogates(original_datass, nsim=1, preserveMean=T, std=T, genplot=F, verbose=F)
      }
      
      #number_surrogate:Number of phase-randomized surrogate series to generate.
      #preserveMean:Should surrogate series have the same mean value as data series? (T or F)
      #std:Standardize results to guarantee equivalent variance as data series? (T or F)
      #genplot:Generate summary plots? Only applies if nsim=1. (T or F)
      #verbose:Verbose output? (T or F)
      
      # calculate Kendall's tau for the original data
      tau_original <- cor(1:length(original_datass),original_datass, method="kendall")
      # calculate Kendall's tau for each surrogate
      tau_surrogates <- apply(surrogates, 2, function(x) cor(1:length(original_datass), x, method="kendall"))
      # calculate p-value
      
      if(tau_original>=0) {p_value <- sum(tau_surrogates >= tau_original) / number_surrogate}
      if(tau_original<0) {p_value <- sum(tau_surrogates <= tau_original) / number_surrogate}
      trendss=tau_original/abs(tau_original)
    }#if(length(original_datass)>=2)
  }#if
  return ( c(tau_original, p_value, trendss) )
}



#example data
set.seed(123)
original_data <- rnorm(1000)
plot(original_data, col="red", type="o")
number_surrogate <- 100

Ebisuzaki_method(number_surrogate, original_data)

#[1] 0.32 1.00 # 0.32 is p value; 1.00 means upward (-1 means downward)
#thus, insignificant upward.


#########
# Part 2# 11 classic EWIS
#########
############## Part 1. AR(1)
#1.0
AR1 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    AR_1<-function(x){
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series and its lagged version
      deviations <- x - mean_ts
      lagged_deviations <- c(NA, deviations[-length(deviations)])
      # Compute the AR(1) coefficient
      ar1_coefficient <- sum(deviations * lagged_deviations, na.rm = TRUE) / sum(deviations^2)
      return(ar1_coefficient)
    } # end AR1 function
    
    Ews <- c(Ews, AR_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
AR1(time_series_data)

############## Part 2. AR(2)
AR2 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    AR_2<-function(x){
      #set.seed(1)
      #time_series_data <- ts(rnorm(100))
      # Compute the mean of the time series
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series and its lagged versions
      deviations <- x - mean_ts
      lagged_deviations_1 <- c(NA, deviations[-length(deviations)])
      lagged_deviations_2 <- c(NA, NA, deviations[-(length(deviations)-1)])
      # Remove the NA in the data
      data <- x[!is.na(lagged_deviations_2)]
      lagged_deviations_1 <- lagged_deviations_1[!is.na(lagged_deviations_2)]
      lagged_deviations_2 <- lagged_deviations_2[!is.na(lagged_deviations_2)]
      # Fit an AR(2) model using lm function
      model <- lm(data ~ lagged_deviations_1 + lagged_deviations_2)
      # Print the model to get the AR(2) coefficients
      return(model$coefficients[[3]])
    }    #end AR2 function
    
    Ews <- c(Ews, AR_2(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
AR2(time_series_data)



############## Part 3. AR(3)
AR3 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    AR_3<-function(x){
      # Compute the mean of the time series
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series and its lagged versions
      deviations <- x - mean_ts
      lagged_deviations_1 <- c(NA, deviations[-length(deviations)])
      lagged_deviations_2 <- c(NA, NA, deviations[-(length(deviations)-1)])
      lagged_deviations_3 <- c(NA, NA, NA, deviations[-(length(deviations)-2)])
      # Remove the NA in the data
      data <- x[!is.na(lagged_deviations_3)]
      lagged_deviations_1 <- lagged_deviations_1[!is.na(lagged_deviations_3)]
      lagged_deviations_2 <- lagged_deviations_2[!is.na(lagged_deviations_3)]
      lagged_deviations_3 <- lagged_deviations_3[!is.na(lagged_deviations_3)]
      # Fit an AR(3) model using lm function
      model <- lm(data ~ lagged_deviations_1 + lagged_deviations_2 + lagged_deviations_3)
      # Print the model to get the AR(3) coefficients
      return(model$coefficients[[4]])
    }    #end AR3 function  
    
    Ews <- c(Ews, AR_3(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
AR3(time_series_data)



############## Part 4. SD
SD <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    SD1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the mean of the squared deviations
      mean_squared_deviations <- mean(squared_deviations)
      # Compute the standard deviation as the square root of the mean of the squared deviations
      sd <- sqrt(mean_squared_deviations)
      # Print the standard deviation
      return(sd)
    }    #end SD function
    
    Ews <- c(Ews, SD1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
SD(time_series_data)



############## Part 5. Skewness
Skewness <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Skewness_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the cubed deviations
      cubed_deviations <- deviations^3
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the skewness as the mean of the cubed deviations divided by the square root of the cube of the mean of the squared deviations
      skewness <- mean(cubed_deviations) / sqrt(mean(squared_deviations)^3)
      # Print the skewness
      return(skewness)
    }    #end Skewness function
    
    Ews <- c(Ews, Skewness_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Skewness(time_series_data)


############## Part 6. Kurtosis
Kurtosis <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Kurtosis_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the cubed deviations
      cubed_deviations <- deviations^3
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the skewness as the mean of the cubed deviations divided by the square root of the cube of the mean of the squared deviations
      skewness <- mean(cubed_deviations) / sqrt(mean(squared_deviations)^3)
      # Print the skewness
      return(skewness)
    }    #end Kurtosis function
    
    Ews <- c(Ews, Kurtosis_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Kurtosis(time_series_data)



############## Part 7. coefficient of variation (CV)
CV <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    CV_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the standard deviation as the square root of the mean of the squared deviations
      sd <- sqrt(mean(squared_deviations))
      # Compute the CV as the ratio of the standard deviation to the mean
      cv <- sd / mean_data
      # Print the CV
      return(cv)
    }    #end CV
    
    Ews <- c(Ews, CV_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
CV(time_series_data)



############## Part 8. first_differenced_variance
first_differenced_variance <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    first_differenced_variance_1<-function(x){
      # Compute the first differences of the time series
      first_differences <- diff(x)
      # Compute the mean of the first differences
      mean_diff <- mean(first_differences)
      # Compute the deviations from the mean for the first differences
      deviations <- first_differences - mean_diff
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the first-differenced variance as the mean of the squared deviations
      first_diff_variance <- mean(squared_deviations)
      # Print the first-differenced variance
      return(first_diff_variance)
    }    #end first_diff_variance
    
    Ews <- c(Ews, first_differenced_variance_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
first_differenced_variance(time_series_data)


############## Part 9. Autocovariance
Autocovariance <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Autocovariance_1<-function(x){
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series
      deviations <- x - mean_ts
      # Compute the lagged deviations
      lagged_deviations <- c(NA, deviations[-length(deviations)])
      # Compute the autocovariance as the mean of the product of the deviations and the lagged deviations
      autocovariance <- mean(deviations * lagged_deviations, na.rm = TRUE)
      # Print the autocovariance
      return(autocovariance)
    }    #end autocovariance
    
    Ews <- c(Ews, Autocovariance_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Autocovariance(time_series_data)



############## Part 10. The index of dispersion
# a measure of statistical dispersion. defined as the ratio of the variance to the mean
index_of_dispersion <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    index_of_dispersion_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the variance as the mean of the squared deviations
      variance <- mean(squared_deviations)
      # Compute the index of dispersion as the ratio of the variance to the mean
      index_of_dispersion <- variance / mean_data
      # Print the index of dispersion
      return(index_of_dispersion)
    }    #end index_of_dispersion
    
    Ews <- c(Ews, index_of_dispersion_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
index_of_dispersion(time_series_data)


############## Part 11. density_ratio
density_ratio <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    density_ratio_1<-function(x){
      # Compute the Fast Fourier Transform of the time series data
      fft_data <- fft(x)
      # Compute the spectral density
      spectral_density <- Mod(fft_data)^2
      # Define the low and high frequency ranges
      # These ranges might need to be adjusted depending on your specific needs
      #low_frequency_range <- 2:10
      #high_frequency_range <- 11:20
      # Compute the spectral density at low and high frequencies
      #spectral_density_low <- mean(spectral_density[low_frequency_range])
      #spectral_density_high <- mean(spectral_density[high_frequency_range])
      #by me
      low_frequency_range <-sort(spectral_density)[1:floor(length(spectral_density)/2)]
      high_frequency_range <-sort(spectral_density)[(floor(length(spectral_density)/2)+1):length(spectral_density)]
      # Compute the spectral density at low and high frequencies
      spectral_density_low <- mean(low_frequency_range)
      spectral_density_high <- mean(high_frequency_range)
      # end by me
      # Compute the density ratio as the ratio of the spectral density at low frequency to the spectral density at high frequency
      density_ratio <- spectral_density_low / spectral_density_high
      # Print the density ratio
      return(density_ratio)
    } # end density_ratio
    
    Ews <- c(Ews, density_ratio_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
density_ratio(time_series_data)


############## Part 12. dominant eigen value
Max_eigen <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Max_eigen_1 <- function(x){
      
      if (all(x==0)){eigen_final=NA}
      if (!(all(x==0))){
        
        library("rEDM")
        library("sapa")
        
        tau <- 1
        theta <- seq(0,10,by=0.5)
        time_series <- (x - mean(x, na.rm=TRUE))/sd(x, na.rm=TRUE)#stadardize data
        #simplex to find E
        sim_r <- simplex(time_series,lib=c(1,floor(length(time_series)/2)),pred=c(floor(length(time_series)/2)+1,length(time_series)),E=c(1:sqrt(length(time_series))))
        
        if( all(is.na(sim_r$rho)) ){eigen_final=NA}
        if( !(all(is.na(sim_r$rho))) ){
          E <-sim_r[which.min(sim_r$mae),"E"][1] 
          #E <-sim_r[which.max(sim_r$rho),"E"][1]
          
          # calculate best theta
          smap <- s_map(time_series, E=E, tau=tau, theta=theta, silent=TRUE)
          best <- order(-smap$rho)[1]
          theta_best <- smap[best,]$theta
          # calculate eigenvalues for best theta
          smap <- s_map(time_series, E=E, tau=tau, theta=theta_best, silent=TRUE, save_smap_coefficients=TRUE)
          smap_co <- smap$smap_coefficients[[1]]
          matrix_eigen <- matrix(NA, nrow = NROW(smap_co), ncol = 3)
          for(k in 1:NROW(smap_co)){
            if(!is.na(smap_co[k,1]))
            {
              M <- rbind(as.numeric(smap_co[k, 1:E]), cbind(diag(E - 1), rep(0, E - 1)))
              M_eigen <- eigen(M)$values
              lambda1 <- M_eigen[order(abs(M_eigen))[E]]
              
              matrix_eigen[k,1] <- abs(lambda1)
              matrix_eigen[k,2] <- Re(lambda1)
              matrix_eigen[k,3] <- Im(lambda1)
            }
          }
          eigen_final=mean(matrix_eigen[,1], na.rm=TRUE)
        }#if( !(all(is.na(sim_r$rho))) )
      }# if
      return(eigen_final)
    } # end Max_eigen
    
    Ews <- c(Ews, Max_eigen_1(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Max_eigen(time_series_data)



#########
# Part 3# 11 from Vest
#########
# Part 1,relative_dispersion
#### function: compute a Earlier warming signal (e.g. relative_dispersion) in Vest R package
relative_dispersions <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "relative_dispersion" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    relative_dispersion <-
      function(x) {
        sd(x) / sd(diff(x)[-1])
      }  # end of the "relative_dispersion" function
    
    Ews <- c(Ews, relative_dispersion(inciddences[(j-window_size+1):j]) )   #compute the "relative_dispersion" for each rolling window
  }
  return(Ews)
}



# Part 2,max_lyapunov_exp
#### function: compute a Earlier warming signal (e.g. max_lyapunov_exp) in Vest R package
max_lyapunov_exps <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "max_lyapunov_exp" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    max_lyapunov_exp <-
      function(x) {
        library(nonlinearTseries) 
        len <- length(x)
        Reduce(max,
               nonlinearTseries::divergence(
                 nonlinearTseries::maxLyapunov(
                   time.series = x,
                   min.embedding.dim = 1,
                   max.embedding.dim = len,
                   radius = ceiling(sqrt(len)),
                   do.plot = FALSE
                 )
               ))
      }  # end of the "max_lyapunov_exp" function
    
    Ews <- c(Ews, max_lyapunov_exp(inciddences[(j-window_size+1):j]) )   #compute the "max_lyapunov_exp" for each rolling window
  }
  return(Ews)
}

# Part 3, Hurst exponent
#### function: compute a Earlier warming signal (e.g. Hurst exponent) in Vest R package
#dataset=new_data$Incidence
#window_size=10
#j=37
#x=inciddences[(j-window_size+1):j]
#window_indices=37

Hurst_exponents <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Hurst exponent" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    HURST <-function(x, nmoments=1) {
      
      if (all(x==0)){HURST_final=NA}
      if (!(all(x==0))){
        library(Rwave)
        cwtwnoise <- DOG(x, 10, 5, nmoments, plot = FALSE)
        mcwtwnoise <- Mod(cwtwnoise)
        mcwtwnoise <- mcwtwnoise * mcwtwnoise
        wspwnoise <- tfmean(mcwtwnoise, plot = FALSE)
        
        HURST_final<-hurst.est(wspwnoise, 1:5, 5, plot = FALSE)[[2]]
      }#if
      return(HURST_final)
    }  # end of the "Hurst exponent" function
    
    Ews <- c(Ews, HURST(inciddences[(j-window_size+1):j]) )   #compute the "Hurst exponent" for each rolling window
  }
  return(Ews)
}


# Part 4, time series acceleration
#### function: compute a Earlier warming signal (e.g. time series acceleration) in Vest R package
time_series_acceleration <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "time series acceleration" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    accelaration <-
      function(x) {
        #require(TTR)
        
        if (length(x) > 10) {
          n <- 5
        }
        else {
          n <- 3
        }
        
        if (length(x) < 4) {
          return(
            c(avg_accl=NA,
              sdev_accl=NA)
          )
        }
        
        ts_sma <- TTR::SMA(x, n = n)
        ts_ema <- TTR::EMA(x, n = n)
        
        ts_sma <- ts_sma[!is.na(ts_sma)]
        ts_ema <- ts_ema[!is.na(ts_ema)]
        
        sema <- ts_sma / ts_ema
        sema <- sema[!(is.infinite(sema) | is.na(sema))]
        
        accl_ <- ts_sma / ts_ema
        
        c(avg_accl=mean(accl_),
          sdev_accl=stats::sd(accl_))
      }  # end of the "accelaration" function
    
    Ews <- c(Ews, accelaration(inciddences[(j-window_size+1):j]) )   #compute the "time series acceleration" for each rolling window
  }
  return(Ews)
}



# Part 5, Slope
#### function: compute a Earlier warming signal (e.g. Slope) in Vest R package
Slopes <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Slope" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    slope <-
      function(x) {
        time_x <- seq_along(x)
        lmfit <- lm(x ~ time_x)
        
        lmfit$coefficients[[2]]
      }  # end of the "Slope" function
    
    Ews <- c(Ews, slope(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 6, Daubechies DWT
#### function: compute a Earlier warming signal (e.g. Daubechies DWT) in Vest R package
Daubechies_DWT <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    #library(Rssa)
    #library(chronosphere)
    #library(remotes)
    #library(wavelets)
    
    #install.packages("wmtsa", repos="http://R-Forge.R-project.org")
    library(wmtsa)
    
    # load the "Daubechies DWT" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    dauDWTenergy <-
      function(x, lvl=4) {
        
        r <-tryCatch(wavDWT(x, wavelet="s8", n.levels=lvl),
                     error = function(e) {
                       NA
                     })
        
        if (is.na(r)) {
          dummy_ed <- rep(NA, times=lvl)
          names(dummy_ed) <- paste0("Ed",1:lvl)
          
          return(c(E_ra5=NA,dummy_ed))
        }
        
        dwt_result <- r$data
        
        E_a5 <- reconstruct(r) # reconstruct(r) is to re-achive the r
        E_a5 <- norm(t(E_a5))
        
        E_dk <- sapply(dwt_result[1:lvl], function(x) norm(t(x)))
        names(E_dk) <- paste0("Ed", 1:length(E_dk))
        
        E_T <- E_a5 + sum(E_dk)
        
        E_ra5 <- E_a5 / E_T
        
        E_rdk <- E_dk / E_T
        
        c(E_ra5=E_ra5,E_rdk)
      }  # end of the "Daubechies DWT" function
    
    Ews <- c(Ews, dauDWTenergy(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 7, no outliers
#### function: compute a Earlier warming signal (e.g. no outliers) in Vest R package
#dataset=new_data$Incidence
#x=dataset
#window_size=10
#steps=1
#window_indices=10

no_outliers <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "no outliers" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    nout2 <-
      function(x) {
        detr <- diff(x)
        
        sum(abs(detr) > 1.5*IQR(detr))
      }  # end of the "no outliers" function
    
    Ews <- c(Ews, nout2(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 8, Step change
#### function: compute a Earlier warming signal (e.g. Step change) in Vest R package
Step_changes <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Step change" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    step_change <-function(x) {
      lko <- x[length(x)]
      rv <- x[-length(x)]
      
      has_s_c <- abs(lko - mean(rv)) > 2*sd(rv)
      
      as.integer(has_s_c)
    }  # end of the "Step change" function
    
    Ews <- c(Ews, step_change(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 9, N peaks
#### function: compute a Earlier warming signal (e.g. N peaks) in Vest R package
N_peaks <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "N peaks" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    npeaks <-
      function(x) {
        nincr <- sum(diff(sign(diff(x)))==-2)
        ndecr <- sum(diff(sign(diff(x)))==2)
        l <- length(x)
        
        c(ndecr=ndecr/l, nincr=nincr/l)
      }  # end of the "N peaks" function
    
    Ews <- c(Ews, npeaks(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 10, Turning Points
#### function: compute a Earlier warming signal (e.g. Turning Points) in Vest R package
Turning_Points <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Turning Points" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    tpoints <-
      function(x) {
        dx <- diff(x)
        sum(sign(dx))
      }  # end of the "Turning Points" function
    
    Ews <- c(Ews, tpoints(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 11, Convert FFT
#### function: compute a Earlier warming signal (e.g. Convert FFT) in Vest R package
Convert_FFT <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Convert FFT" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    convert.fft <-
      function(cs) {
        sample.rate = 1
        
        cs <- cs / length(cs) # normalize
        
        distance.center <- function(c)
          signif(Mod(c),        4)
        angle           <- function(c)
          signif(180 * Arg(c) / pi, 3)
        
        df <- data.frame(
          cycle    = 0:(length(cs) - 1),
          freq     = 0:(length(cs) - 1) * sample.rate / length(cs),
          strength = sapply(cs, distance.center),
          delay    = sapply(cs, angle)
        )
        df
      }  # end of the "Convert FFT" function
    
    Ews <- c(Ews, convert.fft(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 12, FFT AMP
#### function: compute a Earlier warming signal (e.g. FFT AMP) in Vest R package
FFT_AMP <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "FFT AMP" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    fft_strength <-
      function(x) {
        dx <- diff(x)
        library(vest)
        fft_data <- convert.fft(stats::fft(dx))
        
        mean(fft_data[,"strength"])
      } # end of the "FFT AMP" function
    
    Ews <- c(Ews, fft_strength(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 13, Poincare variability
#### function: compute a Earlier warming signal (e.g. Poincare variability) in Vest R package
poincare_variabilitys <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Poincare variability" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    poincare_variability <-
      function(x) {
        sd1 = sd(diff(x))/sqrt(2)
        sd2 = sqrt(2 * var(x) - sd1^2)
        
        c(sd1=sd1,sd2=sd2)
      } # end of the "Poincare variability" function
    
    Ews <- c(Ews, poincare_variability(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


#########
# Part 4# estimate Re over time
#########
# function
estimateRe <- function(dates,
                       incidenceData,
                       estimateOffsetting = 0, #7, #10
                       rightTruncation = 0,
                       leftTruncation = 0, #5
                       method = "Cori", #"Cori", #"WallingaTeunis",
                       variationType = "slidingWindow",
                       #interval_ends = c("2020-03-13", "2020-03-16", "2020-03-20"),
                       minimumCumul = 0, #5
                       windowLength = 1, #4
                       mean_si = 1.1, #3,
                       std_si = 1 #2.4
) {
  offset <- 1
  cumulativeIncidence <- 0
  while (cumulativeIncidence < minimumCumul) {
    if (offset > nrow(incidenceData)) {
      return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
    }
    cumulativeIncidence <- cumulativeIncidence + incidenceData[offset, 1]
    offset <- offset + 1
  }
  
  ## offset needs to be at least two for EpiEstim
  offset <- max(2, offset)
  
  rightBound <- nrow(incidenceData) - (windowLength - 1)
  
  if (rightBound < offset) { ## no valid data point, return empty estimate
    return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
  }
  
  ## generate start and end bounds for Re estimates
  if (variationType == "step") {
    
    # index in incidenceData that corresponds to the interval_end date
    interval_end_indices <- sapply(
      interval_ends,
      function(x) {
        which(dates == as.Date(x))[1]
      }
    )
    
    # starts and end indices of the intervals (numeric vector)
    # t_start = interval_end + 1
    t_start <- c(offset, na.omit(interval_end_indices) + 1)
    t_end <- c(na.omit(interval_end_indices), nrow(incidenceData))
    
    if (offset >= nrow(incidenceData)) {
      return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
    }
    
    # remove intervals if the offset is greater than the
    # end of the interval
    while (offset > t_end[1]) {
      t_start <- t_start[-1]
      t_start[1] <- offset
      t_end <- t_end[-1]
    }
    
    # make sure there are no intervals beyond the length of the data
    while (t_start[length(t_start)] >= nrow(incidenceData)) {
      t_end <- t_end[-length(t_end)]
      t_start <- t_start[-length(t_start)]
    }
    
    outputDates <- dates[t_start[1]:t_end[length(t_end)]]
  } else if (variationType == "slidingWindow") {
    # computation intervals corresponding to every position of the
    # sliding window
    t_start <- seq(offset, rightBound)
    t_end <- t_start + windowLength - 1
    outputDates <- dates[t_end]
  } else {
    print("Unknown time variation.")
    return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
  }
  
  ## offset dates to account for delay between infection and recorded event (testing, hospitalization, death...)
  outputDates <- outputDates - estimateOffsetting
  
  if (method == "Cori") {
    R_instantaneous <- estimate_R(
      incidenceData,
      method = "parametric_si",
      config = make_config(
        list(
          mean_si = mean_si,
          std_si = std_si,
          t_start = t_start,
          t_end = t_end,
          mean_prior = 1
        )
      )
    )
  } else if (method == "WallingaTeunis") {
    R_instantaneous <- wallinga_teunis(
      incidenceData,
      method = "parametric_si",
      config = list(
        mean_si = mean_si, std_si = std_si,
        t_start = t_start,
        t_end = t_end,
        n_sim = 10
      )
    )
  } else {
    print("Unknown estimation method")
    return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
  }
  
  if (variationType == "step") {
    R_mean <- unlist(lapply(
      seq_along(t_start),
      function(x) {
        rep(R_instantaneous$R$`Mean(R)`[x], t_end[x] - t_start[x] + 1)
      }
    ))
    R_highHPD <- unlist(lapply(
      seq_along(t_start),
      function(x) {
        rep(R_instantaneous$R$`Quantile.0.975(R)`[x], t_end[x] - t_start[x] + 1)
      }
    ))
    R_lowHPD <- unlist(lapply(
      seq_along(t_start),
      function(x) {
        rep(R_instantaneous$R$`Quantile.0.025(R)`[x], t_end[x] - t_start[x] + 1)
      }
    ))
  } else {
    R_mean <- R_instantaneous$R$`Mean(R)`
    R_highHPD <- R_instantaneous$R$`Quantile.0.975(R)`
    R_lowHPD <- R_instantaneous$R$`Quantile.0.025(R)`
  }
  
  if (rightTruncation > 0) {
    if (rightTruncation >= length(outputDates)) {
      return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
    }
    originalLength <- length(outputDates)
    outputDates <- outputDates[-seq(originalLength, by = -1, length.out = rightTruncation)]
    R_mean <- R_mean[-seq(originalLength, by = -1, length.out = rightTruncation)]
    R_highHPD <- R_highHPD[-seq(originalLength, by = -1, length.out = rightTruncation)]
    R_lowHPD <- R_lowHPD[-seq(originalLength, by = -1, length.out = rightTruncation)]
  }
  
  if (leftTruncation > 0) {
    if (leftTruncation >= length(outputDates)) {
      return(data.frame(date = c(), variable = c(), value = c(), estimate_type = c()))
    }
    originalLength <- length(outputDates)
    outputDates <- outputDates[-seq(1, leftTruncation)]
    R_mean <- R_mean[-seq(1, leftTruncation)]
    R_highHPD <- R_highHPD[-seq(1, leftTruncation)]
    R_lowHPD <- R_lowHPD[-seq(1, leftTruncation)]
  }
  
  result <- data.frame(
    date = outputDates,
    R_mean = R_mean,
    R_highHPD = R_highHPD,
    R_lowHPD = R_lowHPD
  )
  
  result <- reshape2::melt(result, id.vars = "date")
  colnames(result) <- c("date", "variable", "value")
  result$estimate_type <- paste0(method, "_", variationType)
  
  return(result)
}

# function 2
doReEstimation <- function(data_subset,
                           slidingWindow = 1,
                           methods,
                           variationTypes,
                           interval_ends = c("2020-04-01"),
                           delays,
                           truncations) {
  end_result <- data.frame()
  
  for (method_i in methods) {
    for (variation_i in variationTypes) {
      if (nrow(data_subset %>% filter(local_infection == FALSE)) > 0) {
        incidence_data_local <- data_subset %>%
          filter(local_infection == TRUE) %>%
          pull(value)
        incidence_data_import <- data_subset %>%
          filter(local_infection == FALSE) %>%
          pull(value)
        
        incidence_data <- data.frame(
          local = incidence_data_local,
          imported = incidence_data_import
        )
      } else {
        incidence_data <- data.frame(I = data_subset %>% filter(local_infection == TRUE) %>% pull(value))
      }
      
      dates <- data_subset %>%
        filter(local_infection == TRUE) %>%
        pull(date)
      
      offsetting <- delays[method_i]
      
      leftTrunc <- truncations$left[method_i]
      rightTrunc <- truncations$right[method_i]
      
      result <- estimateRe(
        dates = dates,
        incidenceData = incidence_data,
        windowLength = slidingWindow,
        estimateOffsetting = offsetting,
        rightTruncation = rightTrunc,
        leftTruncation = leftTrunc,
        method = method_i,
        variationType = variation_i,
        interval_ends = interval_ends
      )
      if (nrow(result) > 0) {
        result$region <- unique(data_subset$region)[1]
        result$country <- unique(data_subset$country)[1]
        result$source <- unique(data_subset$source)[1]
        result$data_type <- unique(data_subset$data_type)[1]
        result$replicate <- unique(data_subset$replicate)[1]
        ## need to reorder columns in 'results' dataframe to do the same as in data
        result <- result[, c(
          "date", "region", "country", "source", "data_type", "estimate_type",
          "replicate", "value", "variable"
        )]
        end_result <- bind_rows(end_result, result)
      }
    }
  }
  
  return(end_result)
}


# function 3

## Perform R(t) estimations with EpiEstim on each 'region' of the data, with each 'method' and on each 'data_type'
## 'region' is the geographical region
## 'data_type' can be 'confirmed' for confirmed cases, 'deaths' for fatalities,
##    'hospitalized' for hospitalization data directly from hospitals (not via openZH here)
doAllReEstimations <- function(data,
                               slidingWindow = 3,
                               methods = c("Cori", "WallingaTeunis"),
                               variationTypes = c("step", "slidingWindow"),
                               all_delays,
                               truncations,
                               interval_ends = list(default = c("2020-04-01")),
                               ...) {
  results_list <- list()
  
  for (source_i in unique(data$source)) {
    cat("estimating Re for data source: ", source_i, "...\n")
    for (region_i in unique(data$region)) {
      cat("  Region: ", region_i, "\n")
      
      if ("list" %in% class(interval_ends)) {
        if (!is.null(interval_ends[[region_i]])) {
          region_interval_ends <- interval_ends[[region_i]]
        } else {
          region_interval_ends <- interval_ends[["default"]]
        }
      } else if ("Date" %in% class(interval_ends)) {
        region_interval_ends <- interval_ends
      } else {
        warning(str_c(
          "no valid interval ends for region ", region_i, ". ",
          "Interval ends must be a vector of dates or a named list with names corresponding to regions",
          "(or \"default\")."
        ))
        region_interval_ends <- ""
      }
      if (length(region_interval_ends) == 0) {
        region_interval_ends <- "01-01-2020"
      }
      ## Run EpiEstim
      for (data_type_i in unique(data$data_type)) {
        subset_data <- data %>% filter(region == region_i & source == source_i & data_type == data_type_i)
        if (nrow(subset_data) == 0) {
          next
        }
        cat("    Data type: ", data_type_i, "\n")
        
        delay_i <- all_delays[[data_type_i]]
        
        for (replicate_i in unique(unique(subset_data$replicate))) {
          subset_data_rep <- subset(subset_data, subset_data$replicate == replicate_i)
          results_list <- c(
            results_list,
            list(
              doReEstimation(
                subset_data_rep,
                slidingWindow = slidingWindow,
                methods = methods,
                variationTypes = variationTypes,
                interval_ends = region_interval_ends,
                delays = delay_i,
                truncations = truncations
              )
            )
          )
        }
      }
    }
  }
  
  return(bind_rows(results_list))
}

##### function 4

# Clean up Re Estimates and summarise the confidence intervals
# across bootstrap replicates

cleanCountryReEstimate <- function(countryEstimatesRaw, method = "bootstrap",
                                   rename_types = TRUE,
                                   report_sd = FALSE,
                                   alpha = 0.95) {
  if (rename_types) {
    cleanEstimate <- as_tibble(countryEstimatesRaw) %>%
      mutate(
        data_type = factor(
          data_type,
          levels = c(
            "infection_Confirmed cases",
            "infection_Confirmed cases / tests",
            "infection_Hospitalized patients",
            "infection_Deaths",
            "infection_Excess deaths"
          ),
          labels = c(
            "Confirmed cases",
            "Confirmed cases / tests",
            "Hospitalized patients",
            "Deaths",
            "Excess deaths"
          )
        )
      )
  } else {
    cleanEstimate <- as_tibble(countryEstimatesRaw)
  }
  
  if (method == "legacy") {
    legacy_ReEstimates <- cleanEstimate %>%
      pivot_wider(names_from = "variable", values_from = "value") %>%
      dplyr::group_by(date, country, region, data_type, source, estimate_type) %>%
      dplyr::summarize(
        median_R_mean = median(R_mean),
        median_R_highHPD = median(R_highHPD),
        median_R_lowHPD = median(R_lowHPD),
        mean_R_mean = mean(R_mean),
        .groups = "keep"
      ) %>%
      dplyr::select(
        country, region, source, data_type, estimate_type, date,
        median_R_mean, median_R_highHPD, median_R_lowHPD,
        mean_R_mean
      ) %>%
      arrange(country, region, source, data_type, estimate_type, date) %>%
      ungroup()
    ReEstimates <- legacy_ReEstimates
  } else if (method == "bootstrap") {
    
    # low_quan <- (1-alpha)/2
    high_quan <- 1 - (1 - alpha) / 2
    
    orig_ReEstimate <- cleanEstimate %>%
      filter(replicate == 0) %>%
      pivot_wider(names_from = "variable", values_from = "value") %>%
      rename(median_R_mean = R_mean)
    # this is called median to be compatible with legacy code
    
    MM_ReEstimates <- cleanEstimate %>%
      filter(replicate != 0) %>%
      pivot_wider(names_from = "variable", values_from = "value") %>%
      dplyr::group_by(date, country, region, data_type, source, estimate_type) %>%
      dplyr::summarize(
        sd_mean = sd(R_mean), # across all bootstrap replicates
        # sd_highHPD = sd(R_highHPD), #across all bootstrap replicates
        # sd_lowHPD = sd(R_lowHPD), #across all bootstrap replicates
        .groups = "drop"
      ) %>%
      right_join(orig_ReEstimate, by = c(
        "date", "country", "region",
        "data_type", "source", "estimate_type"
      )) %>%
      dplyr::mutate(
        median_R_highHPD = median_R_mean + qnorm(high_quan) * sd_mean,
        median_R_lowHPD = median_R_mean - qnorm(high_quan) * sd_mean # ,
        # R_highHPD_top = R_highHPD + qnorm(high_quan)*sd_highHPD,
        # R_highHPD_bot = R_highHPD - qnorm(high_quan)*sd_highHPD,
        # R_lowHPD_top = R_lowHPD + qnorm(high_quan)*sd_lowHPD,
        # R_lowHPD_bot = R_lowHPD - qnorm(high_quan)*sd_lowHPD
      ) %>%
      mutate(
        median_R_highHPD = ifelse(median_R_highHPD < 0, 0, median_R_highHPD),
        median_R_lowHPD = ifelse(median_R_lowHPD < 0, 0, median_R_lowHPD) # ,
        # R_highHPD_top = ifelse(R_highHPD_top <0, 0, R_highHPD_top),
        # R_highHPD_bot = ifelse(R_highHPD_bot <0, 0, R_highHPD_bot),
        # R_lowHPD_top = ifelse(R_lowHPD_top <0, 0, R_lowHPD_top),
        # R_lowHPD_bot = ifelse(R_lowHPD_bot <0, 0, R_lowHPD_bot)
      )
    # we add the estimate-type extension later, because simpleUnion and
    # wideHPDs still derive from this df
    
    simple_Union <- MM_ReEstimates %>%
      left_join(orig_ReEstimate, by = c(
        "date", "country", "region",
        "data_type", "source", "estimate_type"
      )) %>%
      rowwise() %>%
      mutate(
        median_R_mean = median_R_mean.x,
        median_R_highHPD = max(median_R_highHPD, R_highHPD.y),
        median_R_lowHPD = min(median_R_lowHPD, R_lowHPD.y)
      ) # ,
    # estimate_type = paste0(estimate_type, '_simple_Union'))
    
    # wideHPDs <- MM_ReEstimates %>%
    #   mutate(median_R_highHPD = R_highHPD_top,
    #          median_R_lowHPD = R_lowHPD_bot,
    #          estimate_type = paste0(estimate_type, '_wideHPDs'))
    #
    # MM_baggedMedian <- cleanEstimate %>%
    #   filter(replicate != 0 ) %>%
    #   pivot_wider(names_from = "variable", values_from = "value") %>%
    #   dplyr::group_by(date, country, region, data_type, source, estimate_type) %>%
    #   dplyr::summarize(
    #     sd_mean = sd(R_mean),
    #     .groups = "drop"
    #   ) %>%
    #   left_join(legacy_ReEstimates, by = c('date', 'country', 'region',
    #                                      'data_type', 'source', 'estimate_type')) %>%
    #   dplyr::mutate(median_R_highHPD = median_R_mean + qnorm(high_quan)*sd_mean,
    #                 median_R_lowHPD = median_R_mean - qnorm(high_quan)*sd_mean) %>%
    #   mutate(median_R_highHPD = ifelse(median_R_highHPD <0, 0, median_R_highHPD),
    #          median_R_lowHPD = ifelse(median_R_lowHPD <0, 0, median_R_lowHPD))
    
    # MM_baggedMean <- cleanEstimate %>%
    #   #filter(replicate != 0 ) %>%
    #   pivot_wider(names_from = "variable", values_from = "value") %>%
    #   dplyr::group_by(date, country, region, data_type, source, estimate_type) %>%
    #   dplyr::summarize(
    #     sd_mean = sd(R_mean),
    #     .groups = "drop"
    #   ) %>%
    #   left_join(legacy_ReEstimates, by = c('date', 'country', 'region',
    #                                        'data_type', 'source', 'estimate_type')) %>%
    #   dplyr::mutate(median_R_highHPD = mean_R_mean + qnorm(high_quan)*sd_mean,
    #                 median_R_lowHPD = mean_R_mean - qnorm(high_quan)*sd_mean) %>%
    #   mutate(median_R_highHPD = ifelse(median_R_highHPD <0, 0, median_R_highHPD),
    #          median_R_lowHPD = ifelse(median_R_lowHPD <0, 0, median_R_lowHPD))
    
    # bag_Union <- MM_baggedMean %>%
    #   left_join(legacy_ReEstimates, by = c('date', 'country', 'region',
    #                                        'data_type', 'source', 'estimate_type')) %>%
    #   rowwise() %>%
    #   mutate(median_R_mean = median_R_mean.x,
    #          median_R_highHPD = max(median_R_highHPD.x, median_R_highHPD.y),
    #          median_R_lowHPD = min(median_R_lowHPD.x, median_R_lowHPD.y),
    #          estimate_type = paste0(estimate_type, '_bag_Union'))
    
    unsortedReEstimates <- bind_rows( # legacy_ReEstimates,
      # MM_ReEstimates #%>% mutate(estimate_type = paste0(estimate_type, '_MM')),
      # MM_baggedMedian %>% mutate(estimate_type = paste0(estimate_type, '_MM_baggedMedian')),
      # MM_baggedMean #%>% mutate(estimate_type = paste0(estimate_type, '_MM_baggedMean'))
      simple_Union # , bag_Union,
      # wideHPDs
    )
    
    if (report_sd) {
      ReEstimates <- unsortedReEstimates %>%
        dplyr::select(
          country, region, source, data_type, estimate_type, date,
          median_R_mean, median_R_highHPD, median_R_lowHPD, sd_mean
        ) %>%
        arrange(country, region, source, data_type, estimate_type, date) %>%
        ungroup()
    } else {
      ReEstimates <- unsortedReEstimates %>%
        dplyr::select(
          country, region, source, data_type, estimate_type, date,
          median_R_mean, median_R_highHPD, median_R_lowHPD
        ) %>%
        arrange(country, region, source, data_type, estimate_type, date) %>%
        ungroup()
    }
  }
  return(ReEstimates)
}

#########
# Part 5# unite_country
#########
unite_country<-function(the_location,the_length,disease_data) {
  if (length(unlist(the_location))==0){subs_final=disease_data}
  if (length(unlist(the_location))>0){
    #all
    full_length=1:the_length
    #the disease excluding the the_location
    remian_leng=full_length[!(full_length %in% c(unlist(the_location)))]
    #the data excluding the the_location
    subs_1<-disease_data[disease_data$full_name %in% unique(disease_data$full_name)[remian_leng],]
    #
    subs_2=NULL
    for (i in 1:length(the_location)) {
      sub_data1=sub_data2=NULL
      sub_data1=disease_data[which(disease_data$full_name %in% unique(disease_data$full_name)[the_location[[i]]]),]
      sub_data1=sub_data1[order(sub_data1$start),] #order date
      
      dupli_date=sub_data1$start[which(duplicated(as.Date(sub_data1$start, "%Y-%m-%d")))] #duplicate date
      uniq_dupli_date=unique(dupli_date) #unique of these duplicate date
      ii=3
      if(length(uniq_dupli_date)>0){
        for (ii in 1:length(uniq_dupli_date)) {
          posi_thes<-which(sub_data1$start %in% uniq_dupli_date[ii])
          sub_data1$value[posi_thes[1]]<-sum(sub_data1$value[posi_thes])
          sub_data1$value[  posi_thes[!posi_thes == posi_thes[1]]  ]<-NA 
        }#for
        sub_data1=sub_data1[!is.na(sub_data1$value), ]
      }#if
      sub_data1=sub_data1[order(sub_data1$start),] #order date
      
      #combine date
      date_com=NULL
      date_com=unique( as.character(as.Date(sub_data1$start,"%Y-%m-%d")) )
      new_frame=NULL
      new_frame=data.frame(
        X=NA,end=NA,
        start=date_com[order(date_com)], 
        value=NA, id=NA,
        disease=NA,location=NA,duration=NA,
        url=NA,name=NA,full_name=NA,
        admin_level_name=NA,parent=NA, centroid_lat_long=NA,
        longitude=NA,latitude=NA,
        disease_name=NA )
      # X
      new_frame$url[which(new_frame$start %in% sub_data1$start)]<-sub_data1$X
      # end
      new_frame$end[which(new_frame$start %in% sub_data1$start)]<-sub_data1$end
      #start
      new_frame$start[which(new_frame$start %in% sub_data1$start)]<-as.character(as.Date(sub_data1$start,"%Y-%m-%d"))
      #value
      new_frame$value[which(new_frame$start %in% sub_data1$start)]<-sub_data1$value
      #id
      new_frame$id[which(new_frame$start %in% sub_data1$start)]<-sub_data1$id
      #disease
      new_frame$disease[which(new_frame$start %in% sub_data1$start)]<-sub_data1$disease
      #location
      new_frame$location[which(new_frame$start %in% sub_data1$start)]<-sub_data1$location
      #duration
      new_frame$duration[which(new_frame$start %in% sub_data1$start)]<-sub_data1$duration
      #url
      new_frame$url[which(new_frame$start %in% sub_data1$start)]<-sub_data1$url
      #name
      new_frame$name[which(new_frame$start %in% sub_data1$start)]<-sub_data1$name
      #full_name
      new_names=NULL
      j=1
      for (j in 1:length(unique(sub_data1$full_name))){
        new_names<-paste(new_names,unique(sub_data1$full_name)[j],sep=';', collapse=NULL) }
      new_frame$full_name<-paste('combined_',new_names,sep='', collapse=NULL)
      #admin_level_name
      new_frame$admin_level_name[which(new_frame$start %in% sub_data1$start)]<-sub_data1$admin_level_name
      #parent
      new_frame$parent[which(new_frame$start %in% sub_data1$start)]<-sub_data1$parent
      #centroid_lat_long
      new_frame$centroid_lat_long[which(new_frame$start %in% sub_data1$start)]<-sub_data1$centroid_lat_long
      #longitude
      new_frame$longitude[which(new_frame$start %in% sub_data1$start)]<-sub_data1$longitude
      #latitude
      new_frame$latitude[which(new_frame$start %in% sub_data1$start)]<-sub_data1$latitude
      #disease_name
      new_frame$disease_name[which(new_frame$start %in% sub_data1$start)]<-sub_data1$disease_name
      
      colnames(new_frame)
      colnames(subs_2)
      colnames(subs_1)
      
      # bind subs_1 with it
      subs_2=rbind(subs_2,new_frame)
    }#for
    subs_final=rbind(subs_1,subs_2)
    subs_final$value<-as.numeric(subs_final$value)
  }# if
  return(as.data.frame(subs_final))
}#unite_country function

#########
# Part 6# EWs_do
#########
##function
#EWs_do(new_datas)

EWs_do<-function (new_datas){
  new_data=new_datas  
  proportion_0<-sum(new_data$Incidence==0)/nrow(new_data);proportion_0
  if (proportion_0>=0.90){final_results_2=NULL}else{
    #common EWs + P value
    leng_window=20 # difine the length of time window
    number=100 # define the number of surrogates
    final_results_2=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
                          c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
                          c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
                          c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
                          c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                          c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                          c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
                          c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                          c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                          c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                          c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                          c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                          #vest function
                          c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)[!(is.infinite(relative_dispersions(new_data$Incidence,leng_window,1)))]),"relative_dispersions"),
                          #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                          c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                          c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                          c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                          #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                          c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                          c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                          c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                          c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                          c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                          c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys") )
    
    final_results_2=as.data.frame(final_results_2)
    
    final_results_2$i_number=i_number
    final_results_2$the_total=NA
    final_results_2$time_length=length(new_data$Incidence)
    final_results_2$frequency=The_frequece
    final_results_2$disease=the_diseases
    final_results_2$country_region=the_countrys
    final_results_2$outbreaks=the_outbreak
    final_results_2$number=1
    colnames(final_results_2)=c("Tau_original","P_value","trend","EWs",
                                "ith_number","the_total",
                                "time_length","frequency",
                                "disease","country_region","outbreaks","number") #1 upward; -1 downward
    final_results_2
    
    return(final_results_2)
  } # if
  
  
} # function EWs_do
