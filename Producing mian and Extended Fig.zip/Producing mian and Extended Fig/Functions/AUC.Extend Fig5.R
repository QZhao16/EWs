



png(paste("Extend Fig5.png",sep=""), width = 210, height = 100, units = "mm", res = 600)
par(mfrow = c(1, 2),              # 1 rows, 2 columns
    mai = c(0.5, 0.5, 0.5, 0.5),  # Adjusted inner margins
    oma = c(0.5, 0.5, 0.5, 0.5),  # Slight outer margins
    mar = c(2, 2, 1, 1),          # Adjusted plot margins
    mgp = c(1.1, 0.5, 0))         # Margin lines for axis title, labels, and line


###
load(file = "Data/ROC.FigS5.RData")
data<-datas %>% filter(EWs =="density_ratio")
data=data[!(is.na(data$Tau_original)),]#remove NA
data=data[!(is.na(data$P_value)),]#remove NA
# AUC curve
data$positive_negative_case=NA
data$positive_negative_case[data$outbreaks == "Yes"]=1 
data$positive_negative_case[data$outbreaks == "No"]=0 
data=data[!(is.na(data$Tau_original)),]
data=data[!(is.na(data$P_value)),]
library(ROCR)
model=NULL
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
length(predicted_scores)
roc_curve=NULL
roc_curve <- roc(response =data$positive_negative_case, predictor =predicted_scores )
#
auc_value=auc(roc_curve)# Calculate AUC


# Adjust margin for the second plot, especially reducing the left margin
#par(mai = c(0.5, 0.1, 0.2, 0.5))  # Adjusted margins for the second plot
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(roc_curve, main = paste("", sep=''), #Combining the most accurate RIs
     #main = paste("ROC Curve(window length=",windows_length,")",",cross-validation(mean=",me,"","sd=",sd, sep=''),
     ylim=c(0,1),asp = NA,
     cex.main = 0.8,
     cex.lab = 0.8, 
     cex.axis = 0.8,
     lwd=2,
     xlab="False-positive (1 -specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="red")

# Force plot to update, then get user coordinates
usr <- par("usr")  # usr = c(x1, x2, y1, y2)
# Add letter "a" to top-left corner of plot area
text(x = usr[1] + 0.02 * (usr[2] - usr[1]),
     y = usr[4] - 0.02 * (usr[4] - usr[3]),
     labels = "a",
     font = 2,
     cex = 1)

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- data %>% mutate(Species = factor(ifelse(outbreaks == "Yes", "Positive", "Negative")))
iris_binary=iris_binary[,c("Tau_original","P_value","Species")]
# cross validation
set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc1=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    Species ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc1=c(each_auc1, model$results$ROC)
}

mean_each_auc1=mean(each_auc1)
sd_each_auc1=sd(each_auc1)







# Part2 highest AUC+2nd AUC
data<-datas %>% filter(EWs =="density_ratio")
data_2<-datas %>% filter(EWs =="index_of_dispersion")
mreges_2<-merge(data,data_2,by=c("start_day","end_day","disease"))
mreges_2=mreges_2[,c("start_day","end_day","disease","outbreaks.x","Tau_original.x","P_value.x",
                     "Tau_original.y","P_value.y")]

mreges_2=mreges_2[!(is.na(mreges_2$Tau_original.x)),]
mreges_2=mreges_2[!(is.na(mreges_2$P_value.x)),]
mreges_2=mreges_2[!(is.na(mreges_2$Tau_original.y)),]
mreges_2=mreges_2[!(is.na(mreges_2$P_value.y)),]

##the all 
mreges_2$positive_negative_case=NA
mreges_2$positive_negative_case[mreges_2$outbreaks.x == "Yes"]=1 
mreges_2$positive_negative_case[mreges_2$outbreaks.x == "No"]=0 
library(ROCR)
model=NULL
model <- glm(positive_negative_case ~ 
               Tau_original.x+P_value.x+
               Tau_original.y+P_value.y, data = mreges_2, family = "binomial")

# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =mreges_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC
lines(roc_curve2, col="steelblue", lty=1, lwd=2)

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- mreges_2 %>% mutate(Species = factor(ifelse(outbreaks.x == "Yes", "Positive", "Negative")))
iris_binary=iris_binary[,c("Tau_original.x","P_value.x",
                           "Tau_original.y","P_value.y",
                           "Species")]
# cross validation
set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc2=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    Species ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc2=c(each_auc2, model$results$ROC)
}


mean_each_auc2=mean(each_auc2)
sd_each_auc2=sd(each_auc2)






### part 3: top AUC+2nd+3rd AUC
data<-datas %>% filter(EWs =="density_ratio")
data_2<-datas %>% filter(EWs =="index_of_dispersion")
data_3<-datas %>% filter(EWs =="time_series_acceleration")
mreges<-merge(data,data_2,by=c("start_day","end_day","disease"))

mreges_2<-merge(mreges,data_3,by=c("start_day","end_day","disease"))
mreges_2=mreges_2[,c("start_day","end_day","disease","outbreaks","Tau_original.x","P_value.x",
                     "Tau_original.y","P_value.y",
                     "Tau_original", "P_value")]
colnames(mreges_2)<-c("start_day","end_day","disease","outbreaks","Tau_original.x1","P_value.x1",
                      "Tau_original.x2","P_value.x2",
                      "Tau_original.x3", "P_value.x3")

mreges_2=mreges_2[!(is.na(mreges_2$Tau_original.x1)),]
mreges_2=mreges_2[!(is.na(mreges_2$P_value.x1)),]
mreges_2=mreges_2[!(is.na(mreges_2$Tau_original.x2)),]
mreges_2=mreges_2[!(is.na(mreges_2$P_value.x2)),]
mreges_2=mreges_2[!(is.na(mreges_2$Tau_original.x3)),]
mreges_2=mreges_2[!(is.na(mreges_2$P_value.x3)),]

##the all 
mreges_2$positive_negative_case=NA
mreges_2$positive_negative_case[mreges_2$outbreaks == "Yes"]=1 
mreges_2$positive_negative_case[mreges_2$outbreaks == "No"]=0 
library(ROCR)
model=NULL
model <- glm(positive_negative_case ~ 
               Tau_original.x1+P_value.x1+
               Tau_original.x2+P_value.x2+
               Tau_original.x3+P_value.x3, data = mreges_2, family = "binomial")

# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve3=NULL
roc_curve3 <- roc(response =mreges_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve3)# Calculate AUC
lines(roc_curve3, col="black", lty=4, lwd=2)

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- mreges_2 %>% mutate(Species = factor(ifelse(outbreaks == "Yes", "Positive", "Negative")))
iris_binary=iris_binary[,c("Tau_original.x1","P_value.x1",
                           "Tau_original.x2","P_value.x2",
                           "Tau_original.x3","P_value.x3",
                           "Species")]
# cross validation
set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc3=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    Species ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc3=c(each_auc3, model$results$ROC)
}

mean_each_auc3=mean(each_auc3)
sd_each_auc3=sd(each_auc3)







### part 4: top AUC+2nd+3rd+4th AUC
data<-datas %>% filter(EWs =="density_ratio")
data_2<-datas %>% filter(EWs =="index_of_dispersion")
data_3<-datas %>% filter(EWs =="time_series_acceleration")
data_4<-datas %>% filter(EWs =="SD")

mreges<-merge(data,data_2,by=c("start_day","end_day","disease"))
colnames(mreges)
mreges_2<-merge(mreges,data_3,by=c("start_day","end_day","disease"))
colnames(mreges_2)
mreges_2=mreges_2[,c("start_day","end_day","disease","outbreaks.x","Tau_original.x","P_value.x",
                     "Tau_original.y","P_value.y",
                     "Tau_original", "P_value")]
colnames(mreges_2)<-c("start_day","end_day","disease","outbreaks.x","Tau_original.x1","P_value.x1",
                      "Tau_original.x2","P_value.x2",
                      "Tau_original.x3", "P_value.x3")
mreges_3<-merge(mreges_2,data_4,by=c("start_day","end_day","disease"))

mreges_3=mreges_3[!is.na(mreges_3$Tau_original.x1),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$P_value.x1),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$Tau_original.x2),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$P_value.x2),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$Tau_original.x3),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$P_value.x3),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$Tau_original),]# remove NA
mreges_3=mreges_3[!is.na(mreges_3$P_value),]# remove NA

##the all 
mreges_3$positive_negative_case=NA
mreges_3$positive_negative_case[mreges_3$outbreaks.x == "Yes"]=1 
mreges_3$positive_negative_case[mreges_3$outbreaks.x == "No"]=0 
library(ROCR)
model=NULL
model <- glm(positive_negative_case ~ 
               Tau_original.x1+P_value.x1+
               Tau_original.x2+P_value.x2+
               Tau_original.x3+P_value.x3+
               Tau_original+P_value, data = mreges_3, family = "binomial")

# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve4=NULL
roc_curve4 <- roc(response =mreges_3$positive_negative_case, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve4)# Calculate AUC
lines(roc_curve4, col="purple", lty=3, lwd=2)

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- mreges_3 %>% mutate(Species = factor(ifelse(outbreaks == "Yes", "Positive", "Negative")))
iris_binary=iris_binary[,c("Tau_original.x1","P_value.x1",
                           "Tau_original.x2","P_value.x2",
                           "Tau_original.x3","P_value.x3",
                           "Species")]
# cross validation
set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc4=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    Species ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc4=c(each_auc4, model$results$ROC)
}

mean_each_auc4=mean(each_auc4)
sd_each_auc4=sd(each_auc4)


# abreviation name legend
legend(1, 0.8, bty = "n",
       legend=c(  paste("1.Only SD",": 
Raw AUC ",round(auc_value, 2)," ","(",round(mean_each_auc1, 2),"�",round(sd_each_auc1, 2),", mean�s.d of AUC)
                         ",sep=""),
                  paste("2.Combine SD+AR1",": 
Raw AUC ",round(auc_value_2, 2)," ","(",round(mean_each_auc2, 2),"�",round(sd_each_auc2, 2),", mean�s.d of AUC)
                         ",sep=""),
                  paste("3.Combine SD+AR1+TSA",": 
Raw AUC ",round(auc_value_3, 2)," ","(","0.80","�",round(sd_each_auc3, 2),", mean�s.d of AUC)
                         ",sep=""),
                  paste("4.Combine SD+AR1+TSA+DR",":
Raw AUC ",round(auc_value_4, 2)," ","(","0.80","�",round(sd_each_auc4, 2),", mean�s.d of AUC)",sep="")),
       col=c("red", "steelblue","black","purple"), 
       lty=c(1,1,4,3,1), cex=0.68,text.width = 1,
       title="")











######### Part 4: same window length (othorgonal effects, top3)
data<-datas %>% filter(EWs =="density_ratio")
data=data[!(is.na(data$Tau_original)),]#remove NA
data=data[!(is.na(data$P_value)),]#remove NA
# AUC curve
data$positive_negative_case=NA
data$positive_negative_case[data$outbreaks == "Yes"]=1 
data$positive_negative_case[data$outbreaks == "No"]=0 
data=data[!(is.na(data$Tau_original)),]
data=data[!(is.na(data$P_value)),]
library(ROCR)
model=NULL
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
length(predicted_scores)
roc_curve=NULL
roc_curve <- roc(response =data$positive_negative_case, predictor =predicted_scores )
#
auc_value=auc(roc_curve)# Calculate AUC
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(roc_curve, main = paste("", sep=''), 
     ylim=c(0,1),asp = NA,
     lwd=2,
     cex.main = 0.8,
     cex.lab = 0.8, 
     cex.axis = 0.8,
     xlab="False-positive (1 -specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="red")


# Force plot to update, then get user coordinates
usr <- par("usr")  # usr = c(x1, x2, y1, y2)
# Add letter "a" to top-left corner of plot area
text(x = usr[1] + 0.02 * (usr[2] - usr[1]),
     y = usr[4] - 0.02 * (usr[4] - usr[3]),
     labels = "b",
     font = 2,
     cex = 1)

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- data %>% mutate(Species = factor(ifelse(outbreaks == "Yes", "Positive", "Negative")))
iris_binary=iris_binary[,c("Tau_original","P_value","Species")]
# cross validation
set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc1=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    Species ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc1=c(each_auc1, model$results$ROC)
}

mean_each_auc1=mean(each_auc1)
sd_each_auc1=sd(each_auc1)




# Part 2: find the position of top 2 orthornognoal
load(file = "Data/FigS5.orthogonal.all.RData")
data_fin2<-add.datas$data_fin2
data_fin2$outbreaks[data_fin2$outbreaks == "Yes"]=1 
data_fin2$outbreaks[data_fin2$outbreaks == "No"]=0 
data_fin2$outbreaks<-as.numeric(data_fin2$outbreaks)
library(ROCR)
model=NULL
model <- glm(outbreaks ~., data = data_fin2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2$outbreaks, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC
lines(roc_curve2, col="steelblue")

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- data_fin2 %>% mutate(outbreaks = factor(ifelse(outbreaks == 1, "Positive", "Negative")))

set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    outbreaks ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc=c(each_auc, model$results$ROC)
}
mean_each_auc2<-mean(each_auc)
sd_each_auc2<-sd(each_auc)





##### Part 4.2 highest AUC+ 1-2 othogonal AUC
data_fin3<-add.datas$data_fin3
data_fin3$outbreaks[data_fin3$outbreaks == "Yes"]=1 
data_fin3$outbreaks[data_fin3$outbreaks == "No"]=0 
data_fin3$outbreaks<-as.numeric(data_fin3$outbreaks)
library(ROCR)
model=NULL
model <- glm(outbreaks ~., data = data_fin3, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin3$outbreaks, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve2)# Calculate AUC
lines(roc_curve2,lty=4, col="black")

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- data_fin3 %>% mutate(outbreaks = factor(ifelse(outbreaks == 1, "Positive", "Negative")))

set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    outbreaks ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc=c(each_auc, model$results$ROC)
}

mean_each_auc3=mean(each_auc)
sd_each_auc3=sd(each_auc)




##### Part 4.3 highest AUC+ 1-3 othogonal AUC
data_fin4<-add.datas$data_fin4
data_fin4$outbreaks[data_fin4$outbreaks == "Yes"]=1 
data_fin4$outbreaks[data_fin4$outbreaks == "No"]=0 
data_fin4$outbreaks<-as.numeric(data_fin4$outbreaks)
library(ROCR)
model=NULL
model <- glm(outbreaks ~., data = data_fin4, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin4$outbreaks, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve2)# Calculate AUC
lines(roc_curve2,lty=3, col="purple")

### 100 iterations, cross validation for whole model (1+top 3 AUC): Setup training control for k-fold cross-validation
iris_binary <- data_fin4 %>% mutate(outbreaks = factor(ifelse(outbreaks == 1, "Positive", "Negative")))

set.seed(1234) # repate CV 100 times
seds<-sample(0:1000, 100, replace = FALSE)
each_auc=NULL
for (z in seds){
  train_control <- trainControl(
    method = "cv", 
    number = 5,  # using 10 folds
    summaryFunction = twoClassSummary,  # custom summary function to get AUC
    classProbs = TRUE,  # necessary for AUC calculation
    savePredictions = "final"
  )
  # Fit the model using logistic regression
  model <- train(
    outbreaks ~ ., 
    data = iris_binary, 
    method = "glm", 
    family = binomial(),
    trControl = train_control,
    metric = "ROC"
  )
  # automatically access the results
  results <- model$results # summary
  means=model$results$ROC #mean AUC
  sds=model$results$ROCSD # SD AUC
  #bind
  each_auc=c(each_auc, model$results$ROC)
}

mean_each_auc4=mean(each_auc)
sd_each_auc4=sd(each_auc)



# abreviation name legend
legend(1, 0.8, bty = "n",
       legend=c(  paste("1.Only DR",": 
Raw AUC ",round(auc_value, 2)," ","(",round(mean_each_auc1, 2),"�",round(sd_each_auc1, 2),", mean�s.d of AUC)
                         ",sep=""),
                  paste("2.Combine DR+TSA",": 
Raw AUC ",round(auc_value_2, 2)," ","(",round(mean_each_auc2, 2),"�",round(sd_each_auc2, 2),", mean�s.d of AUC)
                         ",sep=""),
                  paste("3.Combine DR+TSA+RD",": 
Raw AUC ",round(auc_value_3, 2)," ","(",round(mean_each_auc3, 2),"�",round(sd_each_auc3, 2),", mean�s.d of AUC)
                         ",sep=""),
                  paste("4.Combine DR+TSA+RD+HP",":
Raw AUC ",round(auc_value_4, 2)," ","(",round(mean_each_auc4, 2),"�",round(sd_each_auc4, 2),", mean�s.d of AUC)",sep="")),
       col=c("red", "steelblue","black","purple"),
       lty=c(1,1,4,3,1), cex=0.68,text.width = 1,
       title="")


dev.off()





