load(file = "Data/data.FigS6.RData")

finals$Variable_new<-c("pathegon:bacteria","pathegon:virus","Vector-borne:No","Vector-borne:Yes","pathegon:bacteria","pathegon:virus","Vector-borne:No","Vector-borne:Yes")


library(ggplot2)
dodge <- position_dodge(width = 0.9)
limits <- aes(ymax = Mean + SE, ymin = Mean - SE)

P<-ggplot(finals, aes(x = Variable_new, y = Mean, fill = type)) +
  #ggplot(finals, aes(x = factor, y = Mean, color=Variable,fill = type)) +
  geom_bar(stat = "identity", position = position_dodge(), color = "black") +  # Create grouped bar plot
  geom_errorbar(aes(ymin = Mean - SE, ymax = Mean + SE), width = 0.2, 
                position = position_dodge(0.9)) +  # Add error bars
  labs(title = "",
       x = "",
       y = "Lead time (day)") +
  theme_minimal() +
  theme(legend.title = element_blank(),
        axis.title.y = element_text(colour="black",size=10),
        axis.text.x = element_text(colour="black",size=8, angle = 45, hjust = 1, vjust = 1.1),
        axis.text.y = element_text(colour="black",size=8),  #,face="bold"
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=7) )+  # Remove legend title
  annotate("text", x = 2.3, y = 150, 
           label = "Weekly data: Mean lead time =50.6 day across all diseases", 
           fontface = "bold", size = 2.3) +
  annotate("text", x = 2.28, y = 130, 
           label = "Dayily data: Mean lead time =17.7 day across all diseases", 
           fontface = "bold", size = 2.3) +
  scale_y_continuous(limits = c(0, 190))
P
P+geom_errorbar(limits, position = dodge, width=0.2)+ # remove lower bar
  geom_bar(position = dodge, stat = "identity")+scale_fill_manual(values = c("daily" = "#00A9FF", "weekly" = "#8494FF")) 

ggsave(filename = "Extend Fig6.png", width = 130, height = 80, dpi = 600, units = "mm", device='png')


