

# Get world map data
world <- ne_countries(scale = "large", returnclass = "sf")
# Sampled countries (replace with your list of countries)
sampled_countries <- c(
  "Australia",
  "Austria",
  "Bangladesh",
  "Belgium",
  "Bulgaria",
  "Republic of Congo",
  "Micronesia",
  "Fiji",
  "Finland",
  "France",
  "Germany",
  "Greece",
  "Guyana",
  "Haiti",
  "Honduras",
  "Hong Kong",
  "Hungary",
  "Iceland",
  "Iraq",
  "Ireland",
  "Israel",
  "Italy",
  "Japan",
  "Jordan",
  "Kenya",
  "Kyrgyzstan",
  "Liberia",
  "Madagascar",
  "Malaysia",
  "Malta",
  "Mauritius",
  "Mexico",
  "Netherlands",
  "New Zealand",
  "Nicaragua",
  "Norway",
  "Peru",
  "Philippines",
  "Qatar",
  "Romania",
  "Samoa",
  "Sierra Leone",
  "Singapore",
  "Slovenia",
  "South Africa",
  "South Korea",
  "Spain",
  "Sudan",
  "Sweden",
  "Tajikistan",
  "Turkey",
  "Uganda",
  "United Kingdom",
  "Vietnam",
  "Zimbabwe")





# Subset world map data for sampled countries
sampled_countries_map <- world[world$name %in% sampled_countries, ]
sampled_countries[which (!( sampled_countries %in% world$name) )] # nay country missing

      

# Get state-level shapefile data for a specific country (e.g., USA)
usa_states <- ne_states(country = "united states of america", returnclass = "sf")
usa_states$name_es
# Sampled states within the USA (replace with your list of states)
sampled_states <- c(
  "California",
  "Anchorage",
  "California",
  "Casa Grande",
  "Colorado",
  "District of Columbia",
  "El Paso",
  "Honolulu",
  "Illinois",
  "Kentucky",
  "Las Vegas",
  "Michigan",
  "New Jersey",
  "New York",
  "North Carolina",
  "Ohio",
  "Rhode Island",
  "San Diego",
  "Utah",
  "Vancouver",
  "Virginia",
  "Washington",
  "Wisconsin")
sampled_states_map_1 <- usa_states[usa_states$name %in% sampled_states, ]

#
cities <- data.frame(city = c("Anchorage","Casa Grande","El Paso","Honolulu","Las Vegas","San Diego","Vancouver"),
                     lon = c(-149.9003,-111.768036,-106.485022,-157.858333,-115.139830,-117.1647,-122.661),
                     lat = c(61.2181,32.881893,31.761878,21.306944,36.169941,32.7157,45.6387)
                     ) 
sampled_states_map_1.1 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 


# Get state-level shapefile data for a specific country (e.g., USA)
location_2 <- ne_states(country = "Australia", returnclass = "sf") # city level
# Sampled states within the USA (replace with your list of states)
sampled_states <- c("Adelaide")
# Subset state-level shapefile data for sampled states
sampled_states_map_2 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Adelaide"),lon = c(138.6007),lat = c(-34.9285)) 
sampled_states_map_2 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 


location_2 <- ne_states(country = "Austria", returnclass = "sf")
sampled_states <- c("Salzburg")
sampled_states_map_3 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Bhutan", returnclass = "sf")
sampled_states <- c("Pemagatsel")
sampled_states_map_4 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Brazil", returnclass = "sf")
sampled_states <- c("S�o Paulo")
sampled_states_map_5 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Bulgaria", returnclass = "sf")
sampled_states <- c("Kyustendil")
sampled_states_map_6 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Cambodia", returnclass = "sf")
sampled_states <- c("K�mp�ng Spo")
sampled_states_map_7 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Canada", returnclass = "sf")
sampled_states <- c("Alberta","Manitoba","Nova Scotia")
sampled_states_map_8 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "China", returnclass = "sf")
sampled_states <- c("Beijing","Guangdong","Shaanxi","Shanghai","Sichuan","Wuxi") # having city
sampled_states_map_9 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Wuxi"),lon = c(120.327583),lat = c(31.565372)) 
sampled_states_map_9.2 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 

location_2 <- ne_states(country = "Colombia", returnclass = "sf") 
sampled_states <- c("Girardot","San Andr�s") 
sampled_states_map_10 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Democratic Republic of the Congo", returnclass = "sf") 
sampled_states <- c("�quateur","Impfondo","Kasai-Occidental") 
sampled_states_map_11 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Egypt", returnclass = "sf") 
sampled_states <- c("Aswan")
sampled_states_map_12 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "El Salvador", returnclass = "sf") 
sampled_states <- c("San Vicente") 
sampled_states_map_13 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Ethiopia", returnclass = "sf") 
sampled_states <- c("Amhara","Somali") 
sampled_states_map_14 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "France", returnclass = "sf") 
sampled_states <- c("Martinique","Mayotte","Montpellier","Poitier") 
sampled_states_map_15 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Greece", returnclass = "sf") # a city
sampled_states <- c("Thessaloniki") 
sampled_states_map_16 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Thessaloniki"),lon = c(22.9444191),lat = c(40.6400629)) 
sampled_states_map_16 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 

location_2 <- ne_states(country = "India", returnclass = "sf") 
sampled_states <- c("Chennai","Maharashtra","Orissa","West Bengal") 
sampled_states_map_17 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Japan", returnclass = "sf") #city
sampled_states <- c("Kanazawa") 
sampled_states_map_18 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Kanazawa"),lon = c(136.656205),lat = c(36.561325)) 
sampled_states_map_18 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 

location_2 <- ne_states(country = "Italy", returnclass = "sf") 
sampled_states <- c("Ravenna") 
sampled_states_map_19 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Laos", returnclass = "sf") 
sampled_states <- c("Champasak","X�kong") 
sampled_states_map_20 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Liberia", returnclass = "sf") 
sampled_states <- c("Montserrado") 
sampled_states_map_21 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Mexico", returnclass = "sf") 
sampled_states <- c("Jalisco") 
sampled_states_map_22 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Netherlands", returnclass = "sf") 
sampled_states <- c("Gelderland") 
sampled_states_map_23 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "New Zealand", returnclass = "sf") # city
sampled_states <- c("Hastings") 
sampled_states_map_24 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Hastings"),lon = c(176.8392),lat = c(-39.6396)) 
sampled_states_map_24 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 
                                                                                
location_2 <- ne_states(country = "Nigeria", returnclass = "sf") # city
sampled_states <- c("Jos") 
sampled_states_map_25 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Jos"),lon = c(8.8583),lat = c(9.8965)) 
sampled_states_map_25 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 

location_2 <- ne_states(country = "Norway", returnclass = "sf") # city
sampled_states <- c("Kirkenes") 
sampled_states_map_26 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Kirkenes"),lon = c(30.0458),lat = c(69.7271)) 
sampled_states_map_26 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 


location_2 <- ne_states(country = "Papua New Guinea", returnclass = "sf") 
sampled_states <- c("Morobe") 
sampled_states_map_27 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Paraguay", returnclass = "sf") 
sampled_states <- c("San Pedro") 
sampled_states_map_28 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Peru", returnclass = "sf") #city
sampled_states <- c("Pisco") 
sampled_states_map_29 <- location_2[location_2$name %in% sampled_states, ]
#
cities <- data.frame(city = c("Pisco"),lon = c(-76.2054),lat = c(-13.7103)) 
sampled_states_map_29 <- st_as_sf(cities, coords = c("lon", "lat"), crs = 4326) 

location_2 <- ne_states(country = "Portugal", returnclass = "sf") 
sampled_states <- c("Madeira") 
sampled_states_map_30 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Spain", returnclass = "sf") 
sampled_states <- c("Barcelona","Madrid") 
sampled_states_map_31 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Sweden", returnclass = "sf") 
sampled_states <- c("Stockholm") 
sampled_states_map_32 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Tunisia", returnclass = "sf") 
sampled_states <- c("Sousse") 
sampled_states_map_33 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "Uganda", returnclass = "sf") 
sampled_states <- c("Kabale","Kibale","Mayuge") 
sampled_states_map_34 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "United Kingdom", returnclass = "sf") 
sampled_states <- c("Northumberland") 
sampled_states_map_35 <- location_2[location_2$name %in% sampled_states, ]

location_2 <- ne_states(country = "United States Virgin Islands", returnclass = "sf") 
sampled_states <- c("Saint Thomas") 
sampled_states_map_36 <- location_2[location_2$name %in% sampled_states, ]




# Plot world map with sampled countries and states highlighted
ggplot() +
  geom_sf(data = world, fill = "lightblue") + #transparent
  geom_sf(data = sampled_countries_map, fill = "purple", color = "black") +
  
  geom_sf(data = sampled_states_map_1, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_1.1, fill = "purple", color = "black",size = 0.8, shape = 23) +
  
  geom_sf(data = sampled_states_map_2, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_3, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_4, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_5, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_6, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_7, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_8, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_9, fill = "purple", color = "black") +
  
  geom_sf(data = sampled_states_map_9.2, fill = "purple", color = "black",size = 0.8, shape = 23) +
  
  geom_sf(data = sampled_states_map_10, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_11, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_12, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_13, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_14, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_15, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_16, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_17, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_18, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_19, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_20, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_21, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_22, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_23, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_24, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_25, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_26, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_27, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_28, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_29, fill = "purple", color = "black",size = 0.8, shape = 23) +
  geom_sf(data = sampled_states_map_30, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_31, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_32, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_33, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_34, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_35, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_36, fill = "purple", color = "black") +
  
  labs(title = "") +
  theme_minimal()+
  theme(plot.title = element_text(hjust = 0.5, size=18))+
  theme(
    plot.background = element_rect(fill = "white", color = NA),
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_blank(),  # Remove major grid lines
    panel.grid.minor = element_blank(),  # Remove minor grid lines
    plot.title = element_text(size = 20)) 



ggsave(filename = "fig2.a.png", width = 10, height = 9.3, dpi = 600, units = "in", device='png', bg = "white")



###### disease category
load("Data/disease.category.RData")
fins<-finlass %>% subset(level=="N_time.series")

fig1<-ggplot(fins, aes(x = factor, y = numbers)) +
  geom_bar(stat = "identity", fill = "#8494FF")+
  theme_minimal()+
  ggtitle("") +
  xlab("") +
  ylab("Number of time series")+
  theme(plot.title = element_text(hjust = 0.5, size = 10)) +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='none')+
  guides(color = guide_legend(nrow = 2))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=8),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  scale_y_continuous(limits = c(0, 185), breaks = seq(0, 185, by = 15)) 
fig1


fins_2<-finlass %>% subset(level=="N_diseases")
fig2<-ggplot(fins_2, aes(x = factor, y = numbers)) +
  geom_bar(stat = "identity", fill = "#00A9FF")+
  theme_minimal()+
  ggtitle("") +
  xlab("") +
  ylab("Number of disease")+
  theme(plot.title = element_text(hjust = 0.5, size = 10)) +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='none')+
  guides(color = guide_legend(nrow = 2))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=8),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))+
  scale_y_continuous(limits = c(0, 35), breaks = seq(0, 35, by = 5)) 

fig2

####### combine figures
X11(width=15, height=18)
# Adjust the margins of each plot
fig1 <- fig1 + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))
fig2 <- fig2 + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))
# Arrange plots again with minimized margins
combined_plot <- plot_grid(
  fig2, fig1,
  nrow = 1, ncol = 2, 
  align = "hv", 
  axis = "lrbt",
  rel_heights = c(1, 1),
  rel_widths = c(1, 1)
)

# Display the combined plot
print(combined_plot)

ggsave(filename = "fig2.b-c.png", width = 170, height = 100, dpi = 600, units = "mm", device='png')



