


################################### log-using
load("Data/Cox proportional hazard model.RData")

summary(model_s1111 <- coxme::coxme(Surv(seq_length, outbreak_posit2)~ 
                                      
                                      I(scale(temp_in_window_mean_log)^2)+
                                      scale(temp_in_window_mean_log)+
                                      I(scale(PRCP_mean_log)^2)+
                                      scale(PRCP_mean_log)+
                                      HDI_s+
                                      scale(length_time_series_log)+
                                      Pathegon_type+
                                      Vector_borne+
                                      
                                      Pathegon_type*I(scale(temp_in_window_mean_log)^2)+
                                      Pathegon_type*scale(temp_in_window_mean_log)+
                                      
                                      Vector_borne*scale(PRCP_mean_log)+
                                      Vector_borne*I(scale(PRCP_mean_log)^2)+
                                      Vector_borne*HDI_s+
                                      
                                      (1|country_region/disease),
                                    data=sub_3) )


# raw coeffiecent
model_summary <- summary(model_s1111)
coefficients_table <- model_summary$coef
coefficients_table<-as.data.frame(coefficients_table)
coeff_ = data.frame(predictor=rownames(coefficients_table), coef=coefficients_table$coef, se=coefficients_table$se,p_value=coefficients_table$p )
#
coeff_$predictor<-c(
  "temperature^2",
  "temperature",
  "precipitation^2",
  "precipitation",
  "HDI (low)",
  "HDI (medium)",
  "length time series",
  "Pathogen type",
  "Vector borne",
  
  "Pathogen type*temperature^2",
  "Pathogen type*temperature",
  "Vector borne*precipitation",
  "Vector borne*precipitation^2",
  "Vector borne*HDI (low)",
  "Vector borne*HDI (medium)"
  
  
)

library(scales) # to access break formatting functions
Fig_coeffcient<- ggplot(coeff_, aes(x=predictor,  y=coef, fill=predictor))+
  geom_col()+
  geom_point(size=0.4)+
  geom_errorbar(aes(ymin=coef-se, ymax=coef+se), width=0.2, size=0.3)+
  coord_flip() +
  theme(legend.position="none")+
  ylab("Coefficient")+
  xlab("")+
  ggtitle("") +
  theme(plot.title = element_text(hjust = 0.5,size=9), legend.position='none')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  scale_y_continuous(limits=c(-11, 42))+
  geom_hline(yintercept=0, linetype="dashed",size=0.5)+
  
  geom_text(aes(x = 14.5, y = 30, label = "P=0.01*"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 13.3, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  
  geom_text(aes(x = 12.5, y = 32, label = "P=0.001**"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 11.3, y = 32, label = "P=0.0003***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 10.5, y = 32, label = "P=0.85"), size=2.6,vjust = -1, color = "black")+
  
  geom_text(aes(x = 9.3, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 8.5, y = 32, label = "P=0.36"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 7.5, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 6.3, y = 32, label =  "P=0.85"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 5.3, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 4.5, y = 32, label = "P=0.06"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 3.5, y = 32, label = "P=0.009**"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 2.5, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 1.5, y = 32, label = "P=0.95"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 0.5, y = 32, label = "P=0.64"), size=2.6,vjust = -1, color = "black")
Fig_coeffcient


ggsave(filename = "Fig 5-1.png", width = 80, height = 90, dpi = 600, units = "mm", device='png')




#############
###### Part 1: only for tau value
#############
#cosme
options(na.action = "na.fail")
summary(model_ <- coxme::coxme(Surv(seq_length, outbreak_posit2)~ 
                                 tau_value+
                             (1|country_region/disease),
                           data=sub_3) )


# raw coeffiecent
model_summary <- summary(model_)
coefficients_table <- model_summary$coef
coefficients_table<-as.data.frame(coefficients_table)
coeff_ = data.frame(predictor=rownames(coefficients_table), coef=coefficients_table$coef, se=coefficients_table$se )
#
coeff_$predictor<-c("tau_value")
#
library(scales) 
Fig_coeffcient<- ggplot(coeff_, aes(x=predictor,  y=coef, color=predictor))+
  geom_line() +
  geom_point(size=1.5)+
  geom_errorbar(aes(ymin=coef-se, ymax=coef+se), width=0.2, size=0.5)+
  theme_gray() +
  theme(legend.position="none")+
  ylab("Coefficient")+
  xlab("Tau value of RIs")+
  ggtitle("") +
  theme(plot.title = element_text(hjust = 0.5,size=9), legend.position='none')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_blank(),  
        axis.text.y = element_text(colour="black",size=10),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  scale_y_continuous(limits=c(0, 2))+
geom_text(aes(x = 1, y = 1.8, label = "P=0.03*"), size=3,vjust = -1, color = "black")

Fig_coeffcient


#glmmtmb
summary(model_full <- glmmTMB(
    length_ss~
    tau_value+
    (1 | country_region:disease ),
  data = sub_3,
  family = nbinom2(link = "log")
)  
)


preds <- ggpredict(model_full, terms = c("tau_value[all]"))
preds <- as.data.frame(preds)
#
fig3_incubation<-ggplot(preds, aes(x = x, y = predicted)) +
  geom_line(aes(x = x, y = predicted),linewidth=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Tau value of RIs",
       y = "Time to outbreak (day)",
       color = "") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  scale_y_continuous(limit = c(4,63))+
  scale_x_continuous(limit = c(-0.8,1))

fig3_incubation

fig3_incubation<- fig3_incubation +geom_point(data = sub_3, aes(x = tau_value , y = length_ss), color="#00A9FF", shape=20, size=3) + #color="#00A9FF",  color="#8494FF",  
theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_incubation



############### 
library(cowplot)
fig1 <- Fig_coeffcient + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))
fig2 <- fig3_incubation + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))

X11(width=15, height=18)
combined_plot <- plot_grid(
  fig1, fig2, 
  nrow = 1, ncol = 2, 
  align = "hv", 
  axis = "lrbt",
  rel_heights = c(1, 1,1, 1,1, 1,1, 1),
  rel_widths = c(1, 1,1, 1,1, 1,1, 1),
  labels = c("a", "b", "c", "d", "e", "f","g", "h"),
  label_size = 10
)

# Display the combined plot
print(combined_plot)



ggsave(filename = "Extend Fig3.png", width = 180, height = 90, dpi = 600, units = "mm", device='png')





#####
load("Data/data.Fig5.time.to.occurence.RData")
full.data

# Plotting 
fig3_prep_vector_borne<-ggplot(full.data$data_1, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Ln(precipitation[mm]+0.1)",
       y = "Time to outbreak (day)",
       color = "Vector-borne") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10),  
        axis.text.x = element_text(colour="black",size=8),   
        axis.text.y = element_text(colour="black",size=8),   
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  + 
  scale_y_continuous(limit = c(-2,180))+
  scale_x_continuous(limit = c(-3,0.5))

fig3_prep_vector_borne
fig3_prep_vector_borne<- fig3_prep_vector_borne +geom_point(data = full.data$data_4, aes(x = PRCP_mean_scale, y = length_ss), shape=20, color="black",size=3) +
  geom_point(data = full.data$data_4, aes(x = PRCP_mean_scale, y = length_ss, color=Vector_borne ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_prep_vector_borne

ggsave(filename = "Fig5 -2.png", width = 70, height = 70, dpi = 600, units = "mm", device='png')




datasetss<-full.data$data_2 %>% subset( (group=="bacteria" & predicted<=135 ) | group=="virus")# no overshoot CI
fig3_temp_Pathegon_type<-ggplot(datasetss, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Ln(temperature[�C]+20)",
       y = "Time to outbreak (day)",
       color = "Pathogen type") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10),  
        axis.text.x = element_text(colour="black",size=8),   
        axis.text.y = element_text(colour="black",size=8),   
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  + 
  scale_y_continuous(limit = c(-2,165))+
  scale_x_continuous(limit = c(2.5,4.7))

fig3_temp_Pathegon_type
fig3_temp_Pathegon_type<- fig3_temp_Pathegon_type +geom_point(data = full.data$data_4, aes(x = temp_in_window_mean_scale, y = length_ss), shape=20, color="black",size=3) +
  geom_point(data = full.data$data_4, aes(x = temp_in_window_mean_scale, y = length_ss, color=Pathegon_type ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_temp_Pathegon_type

ggsave(filename = "Fig5 -3.png", width = 70, height = 70, dpi = 600, units = "mm", device='png')


#
limits <- aes(ymax = MeanResponse + SE, ymin = MeanResponse - SE)
dodge <- position_dodge(width = 0.9)
HDis<-ggplot(full.data$data_3, aes(x = Vector_borne, y = MeanResponse, fill = HDI)) + geom_bar(position = dodge, stat = "identity") +
  geom_errorbar(limits, position = dodge, width = 0.2)+
  labs(title = "",
       x = "Vector-borne",
       y = "Time to outbreak (day)",
       color = "HDI") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10),  
        axis.text.x = element_text(colour="black",size=8),   
        axis.text.y = element_text(colour="black",size=8),   
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8)) +
  scale_y_continuous(limit = c(-2,118))+
  geom_segment(aes(x = 1, y = 108, xend = 2, yend = 108))+
  geom_segment(aes(x = 1, y = 107, xend = 1, yend = 108))+
  geom_segment(aes(x = 2, y = 107, xend = 2, yend = 108))+
  
  # non vector-borne
  geom_segment(aes(x = 0.6, y = 90, xend = 1, yend = 90))+
  geom_segment(aes(x = 0.6, y = 90, xend = 0.6, yend = 90))+
  geom_segment(aes(x = 1, y = 90, xend = 1, yend = 90))+
  
  geom_segment(aes(x = 0.6, y = 96, xend = 1.4, yend = 96))+
  geom_segment(aes(x = 0.6, y = 96, xend = 0.6, yend = 96))+
  geom_segment(aes(x = 1.4, y = 96, xend = 1.4, yend = 96))+
  
  geom_segment(aes(x = 1, y = 102, xend = 1.4, yend = 102))+
  geom_segment(aes(x = 1, y = 102, xend = 1, yend = 102))+
  geom_segment(aes(x = 1.4, y = 102, xend = 1.4, yend = 102))+
  
  # vector-borne
  geom_segment(aes(x = 1.6, y = 95, xend = 2, yend = 95))+
  geom_segment(aes(x = 1.6, y = 95, xend = 1.6, yend = 95))+
  geom_segment(aes(x = 2, y = 95, xend = 2, yend = 95))+
  
  geom_segment(aes(x = 1.6, y = 102, xend = 2.4, yend = 102))+
  geom_segment(aes(x = 1.6, y = 102, xend = 1.6, yend = 102))+
  geom_segment(aes(x = 2.4, y = 102, xend = 2.4, yend = 102))+
  
  geom_segment(aes(x = 2, y = 90, xend = 2.4, yend = 90))+
  geom_segment(aes(x = 2, y = 90, xend = 2, yend = 90))+
  geom_segment(aes(x = 2.4, y = 90, xend = 2.4, yend = 90))+
  scale_fill_manual(
    name = "HDI", 
    values = c("0high" = "#F8766D", "3low" = "#6699FF", "2medium" = "#0CB702"),
    labels = c("0high" = "high", "3low" = "low","2medium" = "medium" ))


HDis  
HDis <- HDis+geom_errorbar(limits, position = dodge, width=0.2) +
  geom_bar(position = dodge, stat = "identity")+
  annotate("text", x = 0.8, y=93, label = "P=0.67", size=2)+ 
  annotate("text", x = 1, y=99, label = "P=0.78", size=2)+   
  annotate("text", x = 1.2, y=105, label = "P=0.67", size=2)+ 
  # vector borne
  annotate("text", x = 1.8, y=98, label = "P=0.43", size=2)+  
  annotate("text", x = 2, y=105, label = "P=0.0001", size=2)+ 
  annotate("text", x = 2.2, y=93, label = "P=0.0001", size=2)+ 
  
  annotate("text", x = 1.5, y=112, label = "P=0.003", size=2)

HDis

ggsave(filename = "Fig5 -4.png", width = 70, height = 70, dpi = 600, units = "mm", device='png')


