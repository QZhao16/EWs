


load("Data/leadtime.timeToevent.RData")
# Create bar plot with error bars
dodge <- position_dodge(width = 0.9)
limits <- aes(ymax = Mean + SE, ymin = Mean - SE)
P<-ggplot(result, aes(x = factor_new, y = Mean, fill=factor_new)) +
  #ggplot(result, aes(x = factor_new, y = Mean, fill = Variable)) +
  geom_bar(stat = "identity", position = position_dodge(), color = "black") +  # Create grouped bar plot
  geom_errorbar(aes(ymin = Mean - SE, ymax = Mean + SE), width = 0.2, 
                position = position_dodge(0.9)) +  # Add error bars
  labs(title = "",
       x = "",
       y = "Lead time (day)") +
  theme_minimal() +
 
  theme(legend.title = element_blank(),
        axis.title.y = element_text(colour="black",size=10),
        axis.text.x = element_text(colour="black",size=8, angle = 45, hjust = 1, vjust = 1.1),
        axis.text.y = element_text(colour="black",size=8),  #,face="bold"
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=7),
        legend.position = "none")+  # Remove legend title
  
  annotate("text", x = 2.3, y = 31, 
           label = "Mean lead time =21.3 day across all diseases", 
           fontface = "bold", size = 2.3) +
  scale_y_continuous(limits = c(0, 35))
  #scale_x_discrete(labels = c("1bacteria" = "bacteria", "1virus" = "virus","2No" = "No","2Yes" = "Yes" ))
P
P+geom_errorbar(limits, position = dodge, width=0.2)+ # remove lower bar
  geom_bar(position = dodge, stat = "identity")


ggsave(filename = "Extend Fig4.png", width = 130, height = 90, dpi = 600, units = "mm", device='png')

