
load("Data/data.FigS1.AUC.each.RI.RData") # V1 is raw AUC, V2 is the AUC from cross-validation, v3 is sd of AUC

sub_1<-data.fig1$sub_1
# Fit a linear model with a quadratic term
model <- lm(sub_1$V3 ~ poly(sub_1$leng_window, 3))
summary(model)
model2  <- gam(sub_1$V3 ~ s(sub_1$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig2.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_1$leng_window, sub_1$V3, 
     xlab="Length of moving window",
     ylab="AUC value of Mean incidence",cex.lab = 0.55,cex.axis = 0.55,cex = 0.55, 
     ylim=c(0.35,0.723),
     pch = 16, col = "black", main = "")

df<-as.data.frame( cbind(sub_1$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_1$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 1,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)
legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()





## part 3.1 SD
sub_2<-data.fig1$sub_2
# Fit a linear model with a quadratic term
model <- lm(sub_2$V3 ~ poly(sub_2$leng_window, 3))
summary(model)
model2  <- gam(sub_2$V3 ~ s(sub_2$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-1.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_2$leng_window, sub_2$V3, 
     xlab="Length of moving window",
     ylab="AUC value of SD",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     #ylim=c(0.4,1),
     pch = 16, col = "black", main = "")

df<-as.data.frame( cbind(sub_2$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_2$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 1,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)
legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.2 wavelet_filtering
sub_3<-data.fig1$sub_3
# Fit a linear model with a quadratic term
model <- lm(sub_3$V3 ~ poly(sub_3$leng_window, 2))
summary(model)
model2  <- gam(sub_3$V3 ~ s(sub_3$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-2.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_3$leng_window, sub_3$V3, 
     xlab="Length of moving window",
     ylab="AUC value of wavelet filtering",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_3$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_3$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 1,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.3 wavelet_reddening
sub_4<-data.fig1$sub_4
# Fit a linear model with a quadratic term
model <- lm(sub_4$V3 ~ poly(sub_4$leng_window, 3))
summary(model)
model2  <- gam(sub_4$V3 ~ s(sub_4$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-3.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_4$leng_window, sub_4$V3, 
     xlab="Length of moving window",
     ylab="AUC value of wavelet reddening",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_4$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_4$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.4 AR1
sub_5<-data.fig1$sub_5
# Fit a linear model with a quadratic term
model <- lm(sub_5$V3 ~ poly(sub_5$leng_window, 2))
summary(model)
model2  <- gam(sub_5$V3 ~ s(sub_5$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-4.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_5$leng_window, sub_5$V3, 
     xlab="Length of moving window",
     ylab="AUC value of AR1",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_5$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_5$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.5 AR2
sub_6<-data.fig1$sub_6
# Fit a linear model with a quadratic term
model <- lm(sub_6$V3 ~ poly(sub_6$leng_window, 3))
summary(model)
model2  <- gam(sub_6$V3 ~ s(sub_6$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-5.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_6$leng_window, sub_6$V3, 
     xlab="Length of moving window",
     ylab="AUC value of AR2",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_6$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_6$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)


legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.6 AR3
sub_7<-data.fig1$sub_7
# Fit a linear model with a quadratic term
model <- lm(sub_7$V3 ~ poly(sub_7$leng_window, 2))
summary(model)
model2  <- gam(sub_7$V3 ~ s(sub_7$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-6.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_7$leng_window, sub_7$V3, 
     xlab="Length of moving window",
     ylab="AUC value of AR3",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_7$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_7$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)
legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.7 Skewness
sub_8<-data.fig1$sub_8
# Fit a linear model with a quadratic term
model <- lm(sub_8$V3 ~ poly(sub_8$leng_window, 3))
summary(model)
model2  <- gam(sub_8$V3 ~ s(sub_8$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-7.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_8$leng_window, sub_8$V3, 
     xlab="Length of moving window",
     ylab="AUC value of Skewness",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_8$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_8$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.8 Kurtosis
sub_9<-data.fig1$sub_9
# Fit a linear model with a quadratic term
model <- lm(sub_9$V3 ~ poly(sub_9$leng_window, 3))
summary(model)
model2  <- gam(sub_9$V3 ~ s(sub_9$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-8.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_9$leng_window, sub_9$V3, 
     xlab="Length of moving window",
     ylab="AUC value of Kurtosis",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_9$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_9$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)


legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.9 CV
sub_10<-data.fig1$sub_10
# Fit a linear model with a quadratic term
model <- lm(sub_10$V3 ~ poly(sub_10$leng_window, 3))
summary(model)
model2  <- gam(sub_10$V3 ~ s(sub_10$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-9.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_10$leng_window, sub_10$V3, 
     xlab="Length of moving window",
     ylab="AUC value of CV",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_10$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_10$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.10 Autocovariance
sub_11<-data.fig1$sub_11
# Fit a linear model with a quadratic term
model <- lm(sub_11$V3 ~ poly(sub_11$leng_window, 3))
summary(model)
model2  <- gam(sub_11$V3 ~ s(sub_11$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-10.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_11$leng_window, sub_11$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of Autocovariance",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_11$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_11$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.11 index_of_dispersion
sub_12<-data.fig1$sub_12
# Fit a linear model with a quadratic term
model <- lm(sub_12$V3 ~ poly(sub_12$leng_window,3))
summary(model)
model2  <- gam(sub_12$V3 ~ s(sub_12$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-11.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_12$leng_window, sub_12$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of index of dispersion",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_12$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_12$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.12 density_ratio
sub_13<-data.fig1$sub_13
# Fit a linear model with a quadratic term
model <- lm(sub_13$V3 ~ poly(sub_13$leng_window, 3))
summary(model)
model2  <- gam(sub_13$V3 ~ s(sub_13$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-12.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_13$leng_window, sub_13$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of density ratio",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_13$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_13$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.13 relative_dispersions
sub_14<-data.fig1$sub_14
# Fit a linear model with a quadratic term
model <- lm(sub_14$V3 ~ poly(sub_14$leng_window, 2))
summary(model)
model2  <- gam(sub_14$V3 ~ s(sub_14$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-13.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_14$leng_window, sub_14$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of relative dispersions",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_14$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_14$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()



## part 3.14 Hurst_exponents
sub_15<-data.fig1$sub_15
# Fit a linear model with a quadratic term
model <- lm(sub_15$V3 ~ poly(sub_15$leng_window, 3))
summary(model)
model2  <- gam(sub_15$V3 ~ s(sub_15$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-14.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_15$leng_window, sub_15$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of Hurst exponents",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_15$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_15$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.15 time_series_acceleration
sub_16<-data.fig1$sub_16
# Fit a linear model with a quadratic term
model <- lm(sub_16$V3 ~ poly(sub_16$leng_window, 3))
summary(model)
model2  <- gam(sub_16$V3 ~ s(sub_16$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-15.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_16$leng_window, sub_16$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of time series acceleration",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_16$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_16$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()


## part 3.6 First differenced variance
sub_17<-data.fig1$sub_17
# Fit a linear model with a quadratic term
model <- lm(sub_17$V3 ~ poly(sub_17$leng_window, 3))
summary(model)
model2  <- gam(sub_17$V3 ~ s(sub_17$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-16.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_17$leng_window, sub_17$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of first differenced variance",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_17$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_17$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 1,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()





## part 3.17 Max_eigen
sub_18<-data.fig1$sub_18
# Fit a linear model with a quadratic term
model <- lm(sub_18$V3 ~ poly(sub_18$leng_window, 2))
summary(model)
model2  <- gam(sub_18$V3 ~ s(sub_18$leng_window))
summary(model2)
# Plot the data and fitted model
png("Extend Fig1-17.png", width = 50, height = 50, units = "mm", res = 600)
par(mgp = c(1.1, 0.5, 0), mar = c(2, 2, 1, 1))
plot(sub_18$leng_window, sub_18$V3, 
     xlab="Length of moving window",cex.lab = 0.6,cex.axis = 0.6,cex = 0.6,
     ylab="AUC value of Max(eigen)",
     pch = 16, col = "black", main = "")
df<-as.data.frame( cbind(sub_18$leng_window, predict(model)) );df <- df[order(df[, 1]), ]
df2<-as.data.frame( cbind(sub_18$leng_window, predict(model2)) );df2 <- df2[order(df2[, 1]), ]
lines(df[,1], df[,2], lty = 2,col = "blue", lwd = 1)
lines(df2[,1], df2[,2], lty = 1,col = "coral1", lwd = 1)

legend("bottom", legend = c("polynomial", "Gam"), col = c("blue", "coral1"), lwd = 1,cex = 0.5)
dev.off()




