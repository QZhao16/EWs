library(mgcv)
library(dplyr)
library(ggplot2)
library(ggeffects)
library(Matrix)
library(lme4)
library(glmmTMB)
library(glmmADMB)
library(rnaturalearth)
library(rnaturalearthdata)
library(rnaturalearthhires)
library(sf)
library(cowplot)
library(tidyverse)
library(multcompView)
library(lmerTest)
library(reshape2)
library(multcomp)
library(emmeans)
library(cluster)
library(scales)
library(coxme)
library(car)
library(pcr)
library(pROC)
library(caret)


# set current folder as Working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

source("Functions/map.Fig2.R")              #Generate Fig 2
source("Functions/ROC-AUC.Fig3.R")          #Generate Fig 3
source("Functions/lead time.Fig4.R")        #Generate Fig 4
source("Functions/Cox proportional hazard model.Fig5-Extend Fig3.R") #Generate Fig 5, Extend Fig 3
source("Functions/Extend Fig1-2.R")              #Generate Extend Fig1, 2
source("Functions/lead time.Extend4.R")          #Generate Extend Fig4
source("Functions/AUC.Extend Fig5.R")            #Generate Extend Fig5
source("Functions/lead time.Extend Fig6.R")      #Generate Extend Fig6
source("Functions/Extend Fig7-10.R")             #Generate Extend Fig7-10
