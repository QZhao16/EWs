setwd("C:/Users/QINGHUA ZHAO/Downloads/Feb-2 2024/3")
source("0.function.all.R")
#
disease_data1<-read.csv("AIDO.disease-Meningococcal Disease.all.csv");
disease_data2<-read.csv("AIDO.disease-Middle East Respiratory Syndrome (MERS-CoV).all.csv");
disease_data3<-read.csv("AIDO.disease-Monkeypox.all.csv");
disease_data4<-read.csv("AIDO.disease-Mumps.all.csv")
disease_data5<-read.csv("AIDO.disease-Nipah.all.csv");
disease_data6<-read.csv("AIDO.disease-Norovirus.all.csv")



disease_data=as.data.frame(rbind(disease_data1,disease_data2,disease_data3,
                                 disease_data4,disease_data5,disease_data6))

the_diseases<-"6 diseases in total" 
the_length<-length( unique(disease_data$full_name) )
sumary_finals=first_start=NULL


for (i_disease in 1:the_length){

the_countrys<-unique(disease_data$full_name)[i_disease]
the_countrys
subs_data=disease_data[which(disease_data$full_name %in% unique(disease_data$full_name)[i_disease]),]
#
#plot(subs_data$value, type="l")
subs_data$Incidence<- subs_data$value #Incidence
subs_data$date<- as.Date(subs_data$start, "%Y-%m-%d") #transfer date
subs_data=subs_data[!is.na(subs_data$date), ] #remove NA date
library(tidyverse)
library(dplyr)
subs_data=subs_data[!duplicated(subs_data$date), ] # remove duplicate
subs_data=subs_data[order(subs_data$date),] #sort from most recent to least recent
#estimate Re
results_1=estimateRe(dates=subs_data$date,incidenceData=as.data.frame(subs_data$Incidence))
dim(results_1)
# extract Rt and confidence interval (CI) position
CI_upper_start=which(results_1$date==results_1$date[1])[2] #start date
CI_upper_end=which(results_1$date==results_1$date[length(results_1$date)])[2] #end date
mean_start=which(results_1$date==results_1$date[1])[1] #start date
mean_end=which(results_1$date==results_1$date[length(results_1$date)])[1] #end date
CI_lower_start=which(results_1$date==results_1$date[1])[3] #start date
CI_lower_end=which(results_1$date==results_1$date[length(results_1$date)])[3] #end date
#merge 
mean_Rt=as.data.frame( cbind(as.data.frame(results_1$date[mean_start:mean_end]),results_1$value[mean_start:mean_end]) )
colnames(mean_Rt)=c("date","Rt")
CI_Rt_uppper=as.data.frame( cbind(as.data.frame(results_1$date[CI_upper_start:CI_upper_end]),results_1$value[CI_upper_start:CI_upper_end]) )
colnames(CI_Rt_uppper)=c("date","CI_Rt_uppper")
CI_Rt_lower=as.data.frame( cbind(as.data.frame(results_1$date[CI_lower_start:CI_lower_end]),results_1$value[CI_lower_start:CI_lower_end]) )
colnames(CI_Rt_lower)=c("date","CI_Rt_lower")
finals1=merge(mean_Rt,CI_Rt_uppper,by="date")
finals2=merge(finals1,CI_Rt_lower,by="date")
dim(CI_Rt_uppper)
dim(finals2)
dim(subs_data)
subs_data=merge(finals2,subs_data,by="date")
head(subs_data)
subs_data=subs_data[!is.na(subs_data$Rt), ] # remove NA Rt
#plot(subs_data$value, type="l")
# find tipping point Rt=1, i.e. lower CI =1  ###### ########
date_position=subs_data$date[floor(subs_data$CI_Rt_lower)>=1]
date_position
#define parameter
The_frequecyss<-function(subs_data){
same_year=subs_data[format(subs_data$date,'%Y') %in% format(subs_data$date,'%Y')[1],"date"]
same_month=same_year[format(same_year,'%m') %in% format(same_year,'%m')[1]]
if (length(same_month)>=2){The_frequecys=as.numeric(format(same_month,'%d')[2])-as.numeric(format(same_month,'%d')[1])
   if(The_frequecys==1){The_frequecys="daily"}
   if(The_frequecys==7){The_frequecys="weekly"}
}#if

if (length(same_month)==1 && !(format(same_month,'%m')==12) ){
  same_month=same_year[format(same_year,'%m') %in% format(same_year,'%m')[2]]
  if(length(same_month)==1){The_frequecys="monthly"}
  if(length(same_month)>=2){The_frequecys=as.numeric(format(same_month,'%d')[2])-as.numeric(format(same_month,'%d')[1])
  if(The_frequecys==1){The_frequecys="daily"}
  if(The_frequecys==7){The_frequecys="weekly"}  }
}#if

if (length(same_month)==1 && format(same_month,'%m')==12 ){
  same_year=subs_data[format(subs_data$date,'%Y') %in% unique(format(subs_data$date,'%Y'))[2],"date"]
  same_month=same_year[format(same_year,'%m') %in% format(same_year,'%m')[1]]
  if(length(same_month)==1){The_frequecys="monthly"}
  if(length(same_month)>=2){The_frequecys=as.numeric(format(same_month,'%d')[2])-as.numeric(format(same_month,'%d')[1])
  if(The_frequecys==1){The_frequecys="daily"}
  if(The_frequecys==7){The_frequecys="weekly"}  }
}#if

return(The_frequecys)
}#dunction

The_frequece<-The_frequecyss(subs_data)

#
outbreak_position<-function(date_position){
  outbreak_positions=NULL
  the_year=as.numeric(format(date_position,'%Y'))
  i=2010
  for (i in unique(the_year)){ #examine each year
    #case 1: 4 in within month, or two consectutives in within month
    year_position<-date_position[the_year==i]
    the_month=as.numeric(format(year_position,'%m'))
    j=9
    for (j in unique(the_month)){ #examine each month
      if (sum(the_month %in% j)>=2){
        posi_find=which( as.numeric(format(year_position,'%m')) %in% j )[1] 
        outbreak_point<-year_position[posi_find] 
        outbreak_positions=rbind(outbreak_positions,as.character(as.Date(outbreak_point,'%Y-%m-%d')) )
      }#if
    }#for
    #case 2: 4 consectutives within 2 months        
    month_difference<-diff(the_month)
    if (any(month_difference==1) ){
      year_position
      the_month
      month_difference
      k=1
      for (k in which(month_difference==1)){
        
        the_1<-which(month_difference==1)+1 #1 position
        the_1_before<-which(month_difference==1) #the one before the 1 position
        
        last_month_month=the_month[the_1_before]
        last_month_day=as.numeric( format(year_position[the_1_before],'%d'))
        next_month_day=as.numeric( format(year_position[the_1],'%d'))
        returns="No"
        # last month judging
        if (last_month_month==(1|3|5|7|8|10|12) && last_month_day==31){returns="YES"}
        if (last_month_month==(4|6|9|11) && last_month_day==30 ){returns="YES"}
        if (last_month_month==2 && (last_month_day==28 || last_month_day==29)) {returns="YES"}
        #nex month judging
        if (next_month_day==1 && returns=="YES"){ outbreak_positions=rbind(outbreak_positions,as.character(as.Date(year_position[the_1_before],'%Y-%m-%d')) ) }
      } #for 
    }#if
    
  }# for
  return(outbreak_positions)
} # outbreak_position function

outbreak_positions=as.Date(outbreak_position(date_position),"%Y-%m-%d")

# find the outbreak-point which is right before the defining tipping point above
outbreak_before_position<-function(subs_data,outbreak_positions){
  outbreak_before_poits=NULL
  #case 1
  if(length(outbreak_positions)==1) {
    
    if(which(date_position %in% outbreak_positions) >=2){
      outbreak_before_poit<-date_position[which(date_position %in% outbreak_positions)-1]
      outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )
    } else {
      outbreak_before_poit=subs_data$date[1] #first day
      outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )
    }#else
  }#if
  #case2
  if(length(outbreak_positions)>=2) {
    for (i in 1:length(outbreak_positions)){
      if (i==1){
        if(which(date_position %in% outbreak_positions) >=2){
          outbreak_before_poit<-date_position[which(date_position %in% outbreak_positions)-1]
          outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )
        } else {
          outbreak_before_poit=subs_data$date[1] #first day
          outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )
        }#else
        #outbreak_before_poit=subs_data$date[1] #first day
        #outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_before_poit,"%Y-%m-%d")) )  
      } 
      
      if (i>1){
        outbreak_positions_2<-date_position[which(date_position %in% outbreak_positions[i])-1] # the point before current outbreak point
        #sub_year<-date_position[format(date_position,"%y") %in% format(outbreak_positions[i-1],"%y")] # within the year before current outbreak point
        #sub_month<-sub_year[format(sub_year,"%m") %in% format(outbreak_positions[i-1],"%m")] # within the month of the year
        #outbreak_positions_2<-sub_month[length(sub_month)]  
        outbreak_before_poits=rbind(outbreak_before_poits, as.character(as.Date(outbreak_positions_2,"%Y-%m-%d")) )  }
    }# for
  }#if
  return(outbreak_before_poits)
} # outbreak_before_positions function

outbreak_before_positions=outbreak_before_position(subs_data,outbreak_positions)

# bind, star and end date
start_end=NULL
if(length(outbreak_positions)>0) {
  start_end<-as.data.frame(cbind(as.character(outbreak_before_positions),as.character(outbreak_positions)))
  colnames(start_end)<-c("start","end")
  start_end$start<-as.Date(start_end$start,"%Y-%m-%d");start_end$end<-as.Date(start_end$end,"%Y-%m-%d")
  start_end
} 
start_end

#find lowest 5% CI, where previous outbreak-wave completely ended 
subs_data_31=subs_data_32=subs_data_33=subs_data_34=
  subs_data_35=subs_data_36=subs_data_36=subs_data_37=
  subs_data_38=subs_data_39=subs_data_310=subs_data_311=
  subs_data_312=NULL  
i=1
if (length(c(start_end))==0){subs_data_31<-subs_data} else {
  for (i in 1:nrow(start_end)){
    if (i==1){ 
      if (start_end$start[1]==subs_data$date[1]){
        starts<-1
        ends<-which(subs_data$date %in% start_end$end[1])
        subs_data_31<-subs_data[starts:ends,]
        }else{
    starts<-which(subs_data$date %in% start_end$start[1])
    ends<-which(subs_data$date %in% start_end$end[1])
    subs_data_2<-subs_data[starts:ends,]
    lowest<-which(subs_data_2$CI_Rt_lower %in% min(subs_data_2$CI_Rt_lower)[1]);
    subs_data_31<-subs_data_2[lowest:nrow(subs_data_2),]}#else
      }#if
    if (i==2){
      starts2<-which(subs_data$date %in% start_end$start[2])
      ends2<-which(subs_data$date %in% start_end$end[2])
      subs_data_22<-subs_data[starts2:ends2,]
      lowest2<-which(subs_data_22$CI_Rt_lower %in% min(subs_data_22$CI_Rt_lower)[1]);
      subs_data_32<-subs_data_22[lowest2:nrow(subs_data_22),]   }
    if (i==3){
      starts3<-which(subs_data$date %in% start_end$start[3])
      ends3<-which(subs_data$date %in% start_end$end[3])
      subs_data_23<-subs_data[starts3:ends3,]
      lowest3<-which(subs_data_23$CI_Rt_lower %in% min(subs_data_23$CI_Rt_lower)[1]);
      subs_data_33<-subs_data_23[lowest3:nrow(subs_data_23),]   }
    if (i==4){
      starts4<-which(subs_data$date %in% start_end$start[4])
      ends4<-which(subs_data$date %in% start_end$end[4])
      subs_data_24<-subs_data[starts4:ends4,]
      lowest4<-which(subs_data_24$CI_Rt_lower %in% min(subs_data_24$CI_Rt_lower)[1]);
      subs_data_34<-subs_data_24[lowest4:nrow(subs_data_24),]   }
    if (i==5){
      starts5<-which(subs_data$date %in% start_end$start[5])
      ends5<-which(subs_data$date %in% start_end$end[5])
      subs_data_25<-subs_data[starts5:ends5,]
      lowest5<-which(subs_data_25$CI_Rt_lower %in% min(subs_data_25$CI_Rt_lower)[1]);
      subs_data_35<-subs_data_25[lowest5:nrow(subs_data_25),]   }
    if (i==6){
      starts6<-which(subs_data$date %in% start_end$start[6])
      ends6<-which(subs_data$date %in% start_end$end[6])
      subs_data_26<-subs_data[starts6:ends6,]
      lowest6<-which(subs_data_26$CI_Rt_lower %in% min(subs_data_26$CI_Rt_lower)[1]);
      subs_data_36<-subs_data_26[lowest6:nrow(subs_data_26),]   }
    if (i==7){
      starts7<-which(subs_data$date %in% start_end$start[7])
      ends7<-which(subs_data$date %in% start_end$end[7])
      subs_data_27<-subs_data[starts7:ends7,]
      lowest7<-which(subs_data_27$CI_Rt_lower %in% min(subs_data_27$CI_Rt_lower)[1]);
      subs_data_37<-subs_data_27[lowest7:nrow(subs_data_27),]   }
    if (i==8){
      starts8<-which(subs_data$date %in% start_end$start[8])
      ends8<-which(subs_data$date %in% start_end$end[8])
      subs_data_28<-subs_data[starts8:ends8,]
      lowest8<-which(subs_data_28$CI_Rt_lower %in% min(subs_data_28$CI_Rt_lower)[1]);
      subs_data_38<-subs_data_28[lowest8:nrow(subs_data_28),]   }
    if (i==9){
      starts9<-which(subs_data$date %in% start_end$start[9])
      ends9<-which(subs_data$date %in% start_end$end[9])
      subs_data_29<-subs_data[starts9:ends9,]
      lowest9<-which(subs_data_29$CI_Rt_lower %in% min(subs_data_29$CI_Rt_lower)[1]);
      subs_data_39<-subs_data_29[lowest9:nrow(subs_data_29),]   }
    if (i==10){
      starts10<-which(subs_data$date %in% start_end$start[10])
      ends10<-which(subs_data$date %in% start_end$end[10])
      subs_data_210<-subs_data[starts10:ends10,]
      lowest10<-which(subs_data_210$CI_Rt_lower %in% min(subs_data_210$CI_Rt_lower)[1]);
      subs_data_310<-subs_data_210[lowest10:nrow(subs_data_210),]   }
    if (i==11){
      starts11<-which(subs_data$date %in% start_end$start[11])
      ends11<-which(subs_data$date %in% start_end$end[11])
      subs_data_211<-subs_data[starts11:ends11,]
      lowest11<-which(subs_data_211$CI_Rt_lower %in% min(subs_data_211$CI_Rt_lower)[1]);
      subs_data_311<-subs_data_211[lowest11:nrow(subs_data_211),]   }
    if (i==12){
      starts12<-which(subs_data$date %in% start_end$start[12])
      ends12<-which(subs_data$date %in% start_end$end[12])
      subs_data_212<-subs_data[starts12:ends12,]
      lowest12<-which(subs_data_212$CI_Rt_lower %in% min(subs_data_212$CI_Rt_lower)[1]);
      subs_data_312<-subs_data_212[lowest12:nrow(subs_data_212),]   }
    
} #for
} #else

#

#### function
#if (nrow(start_end)>=1){the_outbreak="Yes"} else {the_outbreak="No"}
if (length(c(start_end))==0){the_outbreak="No"} else {the_outbreak="Yes"} 
#subs_data_31=subs_data
#ggplot(subs_data_32,aes(x = date, y = Incidence)) + geom_line() +theme_bw()
length_threshold<-13

i=1
the_total=0
if (length(c(start_end))==0 ){if(nrow(subs_data_31)>=length_threshold ){new_datas=subs_data_31;the_total=1;i_number=1;
first_start=rbind(first_start,EWs_do(new_datas))

diease_posi<-which(first_start$disease %in% the_diseases);
country_posi<-which(first_start$country_region %in% the_countrys);
first_start$the_total[ diease_posi[diease_posi %in% country_posi] ]=the_total
} }


if (length(c(start_end))>=1){
  for (i_number in 1:nrow(start_end)){
    if(i_number==1){if (nrow(subs_data_31)>=length_threshold){ new_datas=subs_data_31;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==2){if (nrow(subs_data_32)>=length_threshold){ new_datas=subs_data_32;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==3){if (nrow(subs_data_33)>=length_threshold){ new_datas=subs_data_33;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==4){if (nrow(subs_data_34)>=length_threshold){ new_datas=subs_data_34;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==5){if (nrow(subs_data_35)>=length_threshold){ new_datas=subs_data_35;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==6){if (nrow(subs_data_36)>=length_threshold){ new_datas=subs_data_36;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==7){if (nrow(subs_data_37)>=length_threshold){ new_datas=subs_data_37;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==8){if (nrow(subs_data_38)>=length_threshold){ new_datas=subs_data_38;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==9){if (nrow(subs_data_39)>=length_threshold){ new_datas=subs_data_39;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==10){if (nrow(subs_data_310)>=length_threshold){ new_datas=subs_data_310;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==11){if (nrow(subs_data_311)>=length_threshold){ new_datas=subs_data_311;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    if(i_number==12){if (nrow(subs_data_312)>=length_threshold){ new_datas=subs_data_312;the_total=the_total+1;first_start=rbind(first_start,EWs_do(new_datas))}}
    
  }#for
  
  if (the_total>0){
    diease_posi<-which(first_start$disease %in% the_diseases);
    country_posi<-which(first_start$country_region %in% the_countrys);
    first_start$the_total[ diease_posi[diease_posi %in% country_posi] ]=the_total}
  
} #if




sumary_finals=rbind(sumary_finals, c(the_diseases,the_countrys,the_outbreak,the_total,The_frequece))
sumary_finals

#
#write.csv(start_end, paste("Outbreak day for ",the_diseases," at ",subs_data$full_name[1],".csv",sep=""))
#write.csv(sumary_finals, paste("Summary for ",the_diseases,".csv",sep=""))
#write.csv(first_start, paste("EWIs for ",the_diseases,".csv",sep=""))

}# the  for (i_disease in 1:the_length){



#### part 2, figure drawing
true_positiv=true_positive(first_start)
true_positiv$true_positives_rate<-true_positiv$rate_significant_p;true_positiv$false_negative_rate<-1-true_positiv$rate_significant_p
true_positiv$EWs=rownames(true_positiv)
subs1=true_positiv[,c(3,5)];subs1$class="true positive rate";colnames(subs1)<-c("Rate","EWs","class")
subs2=true_positiv[,c(4,5)];subs2$class="false negative rate";colnames(subs2)<-c("Rate","EWs","class")
true_positi<-as.data.frame(rbind(subs1,subs2))

False_positiv=False_positive(first_start)
False_positiv$false_positives_rate<-False_positiv$rate_significant_p;False_positiv$ture_negative_rate<-1-False_positiv$rate_significant_p
False_positiv$EWs=rownames(False_positiv)
subs1=False_positiv[,c(3,5)];subs1$class="False positive rate";colnames(subs1)<-c("Rate","EWs","class")
subs2=False_positiv[,c(4,5)];subs2$class="True negative rate";colnames(subs2)<-c("Rate","EWs","class")
false_positi<-as.data.frame(rbind(subs1,subs2))

## plotting results #
# confusion matrix
ggplot(data=true_positi, aes(x=EWs, y=Rate,fill=class)) +
  geom_bar(stat="identity")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+ 
  geom_hline(yintercept=0.5, linetype="dashed",color = "black", size=1)+
  labs(title="",x ="Early warming signals", y = "Accuracy")
ggsave(filename = "True positive rate.png", width = 10, height = 9.3, dpi = 600, units = "in", device='png')

ggplot(data=false_positi, aes(x=EWs, y=Rate,fill=class)) +
  geom_bar(stat="identity")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+ 
  geom_hline(yintercept=0.5, linetype="dashed",color = "black", size=1)+
  labs(title="",x ="Early warming signals", y = "Accuracy")
ggsave(filename = "False negative rate.png", width = 10, height = 9.3, dpi = 600, units = "in", device='png')


# Roc AUC curve
######### AUC-ROC analysis   
str(first_start)
first_start$Tau_original<-as.numeric(first_start$Tau_original)
first_start$P_value<-as.numeric(first_start$P_value)

png("ROC-1.png", width = 140, height = 140, units = "mm", res = 300)


data_fin2<-first_start %>% filter(Tau_original != "NA") #remove NA
data_fin2$Tau_original
data_fin2$positive_negative_case=NA
data_fin2$positive_negative_case[data_fin2$outbreaks == "Yes"]=1 
data_fin2$positive_negative_case[data_fin2$outbreaks == "No"]=0 
## 1. SD
data_fin2_1<-data_fin2 %>% filter(EWs == "SD") #remove NA
library(pROC)
model=NULL
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_1, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve=NULL
roc_curve <- roc(response =data_fin2_1$positive_negative_case, predictor =predicted_scores )
#
auc_value_1=auc(roc_curve)# Calculate AUC
plot(roc_curve, main = paste("ROC Curve)"), 
     ylim=c(0,1),asp = NA,
     xlab="False-positive (1 -specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="lightblue")


## 2. Poincare_variability
unique(data_fin2$EWs)
data_fin2_2<-data_fin2 %>% filter(EWs == "Poincare_variability") #remove NA
library(ROCR)

model=NULL
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC
lines(roc_curve2, col="red")


## 3. FFT_AMP
unique(data_fin2$EWs)
data_fin2_3<-data_fin2 %>% filter(EWs == "FFT_AMP") #remove NA
library(ROCR)

model=NULL
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_3, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve3=NULL
roc_curve3 <- roc(response =data_fin2_3$positive_negative_case, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve3)# Calculate AUC
lines(roc_curve3, col="purple")



## 4. first_differenced_variance
unique(data_fin2$EWs)
data_fin2_4<-data_fin2 %>% filter(EWs == "first_differenced_variance") #remove NA
library(ROCR)

model=NULL

# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_4, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve4=NULL
roc_curve4 <- roc(response =data_fin2_4$positive_negative_case, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve4)# Calculate AUC
lines(roc_curve4, col="#FFE200")


legend(0.8, 0.4, legend=c(paste("SD (AUC=",round(auc_value_1, 2),")",sep=""), 
                          paste("Poincare_variability (AUC=",round(auc_value_2, 2),")",sep=""),
                          paste("FFT_AMP (AUC=",round(auc_value_3, 2),")",sep=""), 
                          paste("first_differenced_variance (AUC=",round(auc_value_4, 2),")",sep="")),
       col=c("lightblue", "red","purple","#FFE200"), lty=1, cex=0.9,
       title="Line types")


dev.off()




##### part 7.2
png("ROC-2.png", width = 140, height = 140, units = "mm", res = 300)


data_fin2<-first_start %>% filter(Tau_original != "NA") #remove NA
data_fin2$Tau_original
data_fin2$positive_negative_case=NA
data_fin2$positive_negative_case[data_fin2$outbreaks == "Yes"]=1  
data_fin2$positive_negative_case[data_fin2$outbreaks == "No"]=0 
## 1. AR1
unique(data_fin2$EWs)
data_fin2_1<-data_fin2 %>% filter(EWs == "AR1") #remove NA
library(pROC)
model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_1, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve=NULL
roc_curve <- roc(response =data_fin2_1$positive_negative_case, predictor =predicted_scores )
#
auc_value_1=auc(roc_curve)# Calculate AUC
plot(roc_curve, main = paste("ROC Curve)"), 
     ylim=c(0,1),asp = NA,
     xlab="False-positive (1 - specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="lightblue")




## 2. AR2
unique(data_fin2$EWs)
data_fin2_2<-data_fin2 %>% filter(EWs == "AR2") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC
#lines(roc_curve2, main = paste("ROC Curve (AUC =", auc_value, ")"), col="red")
lines(roc_curve2, col="red")



## 3. AR3
unique(data_fin2$EWs)
data_fin2_3<-data_fin2 %>% filter(EWs == "AR3") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_3, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve3=NULL
roc_curve3 <- roc(response =data_fin2_3$positive_negative_case, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve3)# Calculate AUC
lines(roc_curve3, col="purple")



## 4. Skewness
unique(data_fin2$EWs)
data_fin2_4<-data_fin2 %>% filter(EWs == "Skewness") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_4, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve4=NULL
roc_curve4 <- roc(response =data_fin2_4$positive_negative_case, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve4)# Calculate AUC
lines(roc_curve4, col="#FFE200")


legend(0.7, 0.5, legend=c(paste("AR1 (AUC=",round(auc_value_1, 2),")",sep=""), 
                          paste("AR2 (AUC=",round(auc_value_2, 2),")",sep=""),
                          paste("AR3 (AUC=",round(auc_value_3, 2),")",sep=""), 
                          paste("Skewness (AUC=",round(auc_value_4, 2),")",sep="")),
       col=c("lightblue", "red","purple","#FFE200"), lty=1, cex=0.8,
       title="Line types")

dev.off()




##### part 7.3
png("ROC-3.png", width = 140, height = 140, units = "mm", res = 300)


data_fin2<-first_start %>% filter(Tau_original != "NA") #remove NA
data_fin2$Tau_original
data_fin2$positive_negative_case=NA
data_fin2$positive_negative_case[data_fin2$outbreaks == "Yes"]=1  
data_fin2$positive_negative_case[data_fin2$outbreaks == "No"]=0  
## 1. Kurtosis
unique(data_fin2$EWs)
data_fin2_1<-data_fin2 %>% filter(EWs == "Kurtosis") #remove NA
library(pROC)
model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_1, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve=NULL
roc_curve <- roc(response =data_fin2_1$positive_negative_case, predictor =predicted_scores )
#
auc_value_1=auc(roc_curve)# Calculate AUC
plot(roc_curve, main = paste("ROC Curve)"), 
     ylim=c(0,1),asp = NA,
     xlab="False-positive (1 - specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="lightblue")





## 2. CV
unique(data_fin2$EWs)
data_fin2_2<-data_fin2 %>% filter(EWs == "CV") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC
lines(roc_curve2, col="red")



## 3. Autocovariance
unique(data_fin2$EWs)
data_fin2_3<-data_fin2 %>% filter(EWs == "Autocovariance") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_3, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve3=NULL
roc_curve3 <- roc(response =data_fin2_3$positive_negative_case, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve3)# Calculate AUC
lines(roc_curve3, col="purple")



## 4. index_of_dispersion
unique(data_fin2$EWs)
data_fin2_4<-data_fin2 %>% filter(EWs == "index_of_dispersion") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_4, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve4=NULL
roc_curve4 <- roc(response =data_fin2_4$positive_negative_case, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve4)# Calculate AUC
lines(roc_curve4, col="#FFE200")


legend(0.7, 0.5, legend=c(paste("Kurtosis (AUC=",round(auc_value_1, 2),")",sep=""), 
                          paste("CV (AUC=",round(auc_value_2, 2),")",sep=""),
                          paste("Autocovariance (AUC=",round(auc_value_3, 2),")",sep=""), 
                          paste("index_of_dispersion (AUC=",round(auc_value_4, 2),")",sep="")),
       col=c("lightblue", "red","purple","#FFE200"), lty=1, cex=0.8,
       title="Line types")

dev.off()



##### part 7.4
png("ROC-4.png", width = 140, height = 140, units = "mm", res = 300)


data_fin2<-first_start %>% filter(Tau_original != "NA") #remove NA
data_fin2$Tau_original
data_fin2$positive_negative_case=NA
data_fin2$positive_negative_case[data_fin2$outbreaks == "Yes"]=1 
data_fin2$positive_negative_case[data_fin2$outbreaks == "No"]=0  
## 1. density_ratio
unique(data_fin2$EWs)
data_fin2_1<-data_fin2 %>% filter(EWs == "density_ratio") #remove NA
library(pROC)
model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_1, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve=NULL
roc_curve <- roc(response =data_fin2_1$positive_negative_case, predictor =predicted_scores )
#
auc_value_1=auc(roc_curve)# Calculate AUC
plot(roc_curve, main = paste("ROC Curve)"), 
     ylim=c(0,1),asp = NA,
     xlab="False-positive (1 - specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="lightblue")





## 2. relative_dispersions
unique(data_fin2$EWs)
data_fin2_2<-data_fin2 %>% filter(EWs == "relative_dispersions") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC

#lines(roc_curve2, main = paste("ROC Curve (AUC =", auc_value, ")"), col="red")
lines(roc_curve2, col="red")



## 3. Hurst_exponents
unique(data_fin2$EWs)
data_fin2_3<-data_fin2 %>% filter(EWs == "Hurst_exponents") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_3, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve3=NULL
roc_curve3 <- roc(response =data_fin2_3$positive_negative_case, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve3)# Calculate AUC
lines(roc_curve3, col="purple")



## 4. time_series_acceleration
unique(data_fin2$EWs)
data_fin2_4<-data_fin2 %>% filter(EWs == "time_series_acceleration") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_4, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve4=NULL
roc_curve4 <- roc(response =data_fin2_4$positive_negative_case, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve4)# Calculate AUC
lines(roc_curve4, col="#FFE200")


legend(0.7, 0.5, legend=c(paste("density_ratio (AUC=",round(auc_value_1, 2),")",sep=""), 
                          paste("relative_dispersions (AUC=",round(auc_value_2, 2),")",sep=""),
                          paste("Hurst_exponents (AUC=",round(auc_value_3, 2),")",sep=""), 
                          paste("time_series_acceleration (AUC=",round(auc_value_4, 2),")",sep="")),
       col=c("lightblue", "red","purple","#FFE200"), lty=1, cex=0.8,
       title="Line types")

dev.off()




##### part 7.5
png("ROC-5.png", width = 140, height = 140, units = "mm", res = 300)


data_fin2<-first_start %>% filter(Tau_original != "NA") #remove NA
data_fin2$Tau_original
data_fin2$positive_negative_case=NA
data_fin2$positive_negative_case[data_fin2$outbreaks == "Yes"]=1  
data_fin2$positive_negative_case[data_fin2$outbreaks == "No"]=0  
## 1. Slopes
unique(data_fin2$EWs)
data_fin2_1<-data_fin2 %>% filter(EWs == "Slopes") #remove NA
library(pROC)
model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_1, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve=NULL
roc_curve <- roc(response =data_fin2_1$positive_negative_case, predictor =predicted_scores )
#
auc_value_1=auc(roc_curve)# Calculate AUC
plot(roc_curve, main = paste("ROC Curve)"), 
     ylim=c(0,1),asp = NA,
     xlab="False-positive (1 - specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="lightblue")





## 2. no_outliers
unique(data_fin2$EWs)
data_fin2_2<-data_fin2 %>% filter(EWs == "no_outliers") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC

#lines(roc_curve2, main = paste("ROC Curve (AUC =", auc_value, ")"), col="red")
lines(roc_curve2, col="red")



## 3. Step_changes
unique(data_fin2$EWs)
data_fin2_3<-data_fin2 %>% filter(EWs == "Step_changes") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_3, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve3=NULL
roc_curve3 <- roc(response =data_fin2_3$positive_negative_case, predictor =predicted_scores )
#
auc_value_3=auc(roc_curve3)# Calculate AUC
lines(roc_curve3, col="purple")



## 4. N_peaks
unique(data_fin2$EWs)
data_fin2_4<-data_fin2 %>% filter(EWs == "N_peaks") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_4, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve4=NULL
roc_curve4 <- roc(response =data_fin2_4$positive_negative_case, predictor =predicted_scores )
#
auc_value_4=auc(roc_curve4)# Calculate AUC
lines(roc_curve4, col="#FFE200")


legend(0.7, 0.5, legend=c(paste("Slopes (AUC=",round(auc_value_1, 2),")",sep=""), 
                          paste("no_outliers (AUC=",round(auc_value_2, 2),")",sep=""),
                          paste("Step_changes (AUC=",round(auc_value_3, 2),")",sep=""), 
                          paste("N_peaks (AUC=",round(auc_value_4, 2),")",sep="")),
       col=c("lightblue", "red","purple","#FFE200"), lty=1, cex=0.8,
       title="Line types")

dev.off()




##### part 7.6
png("ROC-6.png", width = 140, height = 140, units = "mm", res = 300)

data_fin2<-first_start %>% filter(Tau_original != "NA") #remove NA
data_fin2$Tau_original
data_fin2$positive_negative_case=NA
data_fin2$positive_negative_case[data_fin2$outbreaks == "Yes"]=1  
data_fin2$positive_negative_case[data_fin2$outbreaks == "No"]=0  
## 1. Turning_Points
unique(data_fin2$EWs)
data_fin2_1<-data_fin2 %>% filter(EWs == "Turning_Points") #remove NA
library(pROC)
model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_1, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve=NULL
roc_curve <- roc(response =data_fin2_1$positive_negative_case, predictor =predicted_scores )
#
auc_value_1=auc(roc_curve)# Calculate AUC
plot(roc_curve, main = paste("ROC Curve)"), 
     ylim=c(0,1),asp = NA,
     xlab="False-positive (1 - specificity)",
     ylab="True-positive (sensitivity)",
     grid = TRUE, legacy.axes = TRUE, col="lightblue")





## 2. Max_eigen
unique(data_fin2$EWs)
data_fin2_2<-data_fin2 %>% filter(EWs == "Max_eigen") #remove NA
library(ROCR)

model=NULL


# Fit a logistic regression model
model <- glm(positive_negative_case ~ Tau_original+P_value, data = data_fin2_2, family = "binomial")
# Predict probabilities for the same data
predicted_scores=NULL
predicted_scores <- predict(model, type = "response")
roc_curve2=NULL
roc_curve2 <- roc(response =data_fin2_2$positive_negative_case, predictor =predicted_scores )
#
auc_value_2=auc(roc_curve2)# Calculate AUC

#lines(roc_curve2, main = paste("ROC Curve (AUC =", auc_value, ")"), col="red")
lines(roc_curve2, col="red")


legend(0.7, 0.5, legend=c(paste("Turning_Points (AUC=",round(auc_value_1, 2),")",sep=""), 
                          paste("Max_eigen (AUC=",round(auc_value_2, 2),")",sep="")
),
col=c("lightblue", "red","purple","#FFE200"), lty=1, cex=0.8,
title="Line types")

dev.off()


####
disease_data1<-read.csv("AIDO.disease-Meningococcal Disease.all.csv");
disease_data2<-read.csv("AIDO.disease-Middle East Respiratory Syndrome (MERS-CoV).all.csv");
disease_data3<-read.csv("AIDO.disease-Monkeypox.all.csv");
disease_data4<-read.csv("AIDO.disease-Mumps.all.csv")
disease_data5<-read.csv("AIDO.disease-Nipah.all.csv");
disease_data6<-read.csv("AIDO.disease-Norovirus.all.csv")
finsss<-as.data.frame(rbind(data_1,data_2,data_3,data_4,data_5,data_6))
#write.csv(finsss,"summary.regions.csv")
write.csv(unique(first_start$country_region),"summary.regions.csv")
write.csv(c("Meningococcal Disease","Middle East Respiratory Syndrome (MERS-CoV)",
            "Monkeypox","Mumps","Nipah","Norovirus"),"summary.disease.csv")


### plotting all regions where all disease are from
unique(first_start$country_region)

library(rnaturalearth)
library(rnaturalearthdata)
library(rnaturalearthhires)
library(sf)
library(ggplot2)


# Get world map data
world <- ne_countries(scale = "medium", returnclass = "sf")
# Sampled countries (replace with your list of countries)
sampled_countries <- c("United Kingdom","India","C�te d'Ivoire","USA",
                       "Jordan","The Central African Republic",
                       "Congo","Israel","Sweden","Serbia",
                       "Austria","India","Philippines","Canada")
# Subset world map data for sampled countries
sampled_countries_map <- world[world$name %in% sampled_countries, ]
# Get state-level shapefile data for a specific country (e.g., USA)
usa_states <- ne_states(country = "united states of america", returnclass = "sf")
# Sampled states within the USA (replace with your list of states)
sampled_states <- c("Ohio", "Kansas", "Chicago", "Columbia")
sampled_states_map <- usa_states[usa_states$name %in% sampled_states, ]

# Get state-level shapefile data for a specific country (e.g., USA)
Uganda_states <- ne_states(country = "Democratic Republic of the Congo", returnclass = "sf")
# Sampled states within the USA (replace with your list of states)
sampled_states <- c("Impfondo")
# Subset state-level shapefile data for sampled states
sampled_states_map_2 <- Uganda_states[Uganda_states$name %in% sampled_states, ]

# Plot world map with sampled countries and states highlighted
ggplot() +
  geom_sf(data = world, fill = "lightgrey") +
  geom_sf(data = sampled_countries_map, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map, fill = "purple", color = "black") +
  geom_sf(data = sampled_states_map_2, fill = "purple", color = "black") +
  labs(title = "Diseases Origions") +
  theme_minimal()+
  theme(plot.title = element_text(hjust = 0.5, size=18))
ggsave(filename = "Diseases Origions.png", width = 10, height = 9.3, dpi = 600, units = "in", device='png')
