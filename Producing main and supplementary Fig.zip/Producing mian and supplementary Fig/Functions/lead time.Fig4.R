library(mgcv)
library(tidyverse)
library(dplyr)
library(ggplot2)
library(ggeffects)
library(Matrix)
library(lme4)
library(glmmTMB)
library(ggplot2)
library(glmmADMB)


load("Data/Leadtime.RData")

options(na.action = "na.fail")
summary(model_full <- glmmTMB(
  Responses_time ~
    
  poly(temp_in_window_log,2)+
  poly(PRCP_log,2)+
  HDI_s+
  shortst_incubation_time_log+
  length_time_series_log+
  Pathegon_type+
  Vector_borne+
     
  Pathegon_type*poly(temp_in_window_log,2)+
  Pathegon_type*poly(PRCP_log,2)+
  Vector_borne*poly(temp_in_window_log,2)+
  Vector_borne*poly(PRCP_log,2)+
      
    (1 | country_region:disease),
  ziformula = ~ 1,
  data = sub_3,
  family = nbinom2(link = "log")
)  
)


# R square
ll_full <- logLik(model_full)
####Null model_marginal
null_model_marginal <- glmmTMB(Responses_time ~(1 | country_region:disease ), ziformula = ~ 1, data = sub_3,family = nbinom2(link = "log") )  
ll_null_marginal <- logLik(null_model_marginal)
# Marginal R square
r_squared_marginal <- 1 - (ll_full/ll_null_marginal)
r_squared_marginal 
####Null model_conditional
null_model_marginal <- glmmTMB(Responses_time ~ 1,ziformula = ~ 1, data = sub_3,family = nbinom2(link = "log") )  
ll_null_conditional <- logLik(null_model_marginal)
# Marginal R square
r_squared_conditional <- 1 - (ll_full/ll_null_conditional)
r_squared_conditional  




preds <- ggpredict(model_full, terms = c("temp_in_window_log[all]","Vector_borne[all]"))
preds <- as.data.frame(preds)
# 
fig3_temp_Vector_borne<-ggplot(preds, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Ln(temperature[�C]+20)",
       y = "Lead time (day)",
       color = "Vector-borne") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8), 
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10))  +
  scale_y_continuous(limit = c(-2,105))+
  scale_x_continuous(limit = c(2,4.5))

fig3_temp_Vector_borne
fig3_temp_Vector_borne<- fig3_temp_Vector_borne +geom_point(data = sub_3, aes(x = temp_in_window_log, y = Responses_time), shape=20, color="black",size=3) +
  geom_point(data = sub_3, aes(x = temp_in_window_log, y = Responses_time, color=Vector_borne ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_temp_Vector_borne


ggsave(filename = "Fig 4-1.png", width = 70, height = 60, dpi = 600, units = "mm", device='png')



preds <- ggpredict(model_full, terms = c("PRCP_log[all]","Vector_borne[all]"))
preds <- as.data.frame(preds)

fig3_prep_Vector_borne<-ggplot(preds, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Ln(precipitation[mm]+0.1)",
       y = "Lead time (day)",
       color = "Vector-borne") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10))  +
  scale_y_continuous(limit = c(-2,105))+
  scale_x_continuous(limit = c(-3.2,0.5))

fig3_prep_Vector_borne
fig3_prep_Vector_borne<- fig3_prep_Vector_borne +geom_point(data = sub_3, aes(x = PRCP_log, y = Responses_time), shape=20, color="black",size=3) +
  geom_point(data = sub_3, aes(x = PRCP_log, y = Responses_time, color=Vector_borne ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_prep_Vector_borne


ggsave(filename = "Fig 4-2.png", width = 70, height = 60, dpi = 600, units = "mm", device='png')





preds <- ggpredict(model_full, terms = c("PRCP_log[all]","Pathegon_type[all]"))
preds <- as.data.frame(preds)

fig3_prep_Pathegon_type<-ggplot(preds, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Ln(precipitation[mm]+0.1)",
       y = "Lead time (day)",
       color = "Pathogen type") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10),
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10))  +
  scale_y_continuous(limit = c(-2,105))+
  scale_x_continuous(limit = c(-3.2,0.5))

fig3_prep_Pathegon_type
fig3_prep_Pathegon_type<- fig3_prep_Pathegon_type +geom_point(data = sub_3, aes(x = PRCP_log, y = Responses_time), shape=20, color="black",size=3) +
  geom_point(data = sub_3, aes(x = PRCP_log, y = Responses_time, color=Pathegon_type ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_prep_Pathegon_type


ggsave(filename = "Fig 4-3.png", width = 70, height = 60, dpi = 600, units = "mm", device='png')






preds <- ggpredict(model_full, terms = c("temp_in_window_log[all]","Pathegon_type[all]"))
preds <- as.data.frame(preds)

fig3_temp_Pathegon_type<-ggplot(preds, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Ln(temperature[�C]+20)",
       y = "Lead time (day)",
       color = "Pathogen type") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10))  +
  scale_y_continuous(limit = c(-2,105))+
  scale_x_continuous(limit = c(2,4.5))

fig3_temp_Pathegon_type
fig3_temp_Pathegon_type<- fig3_temp_Pathegon_type +geom_point(data = sub_3, aes(x = temp_in_window_log, y = Responses_time), shape=20, color="black",size=3) +
  geom_point(data = sub_3, aes(x = temp_in_window_log, y = Responses_time, color=Pathegon_type ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_temp_Pathegon_type



ggsave(filename = "Fig 4-4.png", width = 70, height = 60, dpi = 600, units = "mm", device='png')


############### HDI
## $emmeans
library(dplyr)
library(ggplot2)
summary_stats <- sub_3 %>%
  group_by(HDI_s) %>%
  summarise(
    MeanResponse = mean(Responses_time, na.rm = TRUE),
    SDResponse = sd(Responses_time, na.rm = TRUE),
    N = n(),  
    SE = SDResponse / sqrt(N)  
  )

(multiple_comparison=emmeans::emmeans(model_full, pairwise~HDI_s, adj="holm"))
summary_stats<-as.data.frame(summary_stats)
colnames(summary_stats)<-c("HDI",colnames(summary_stats)[2:5])
summary_stats$HDI_s<-c("0high","3low","2medium")
limits <- aes(ymax = MeanResponse + SE, ymin = MeanResponse - SE)
dodge <- position_dodge(width = 0.9)

HDis<-ggplot(summary_stats, aes(x = HDI_s, y = MeanResponse, fill = HDI_s)) + geom_bar(position = dodge, stat = "identity") +
  geom_errorbar(limits, position = dodge, width = 0.2)+
  labs(title = "",
       x = "HDI",
       y = "Lead time (day)",
       color = "HDI"
  ) +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10),  
        axis.text.x = element_text(colour="black",size=8),   
        axis.text.y = element_text(colour="black",size=8),   
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10)) +
  scale_y_continuous(limit = c(0,30))+

  # 
  geom_segment(aes(x = 1, y = 30, xend = 3.2, yend = 30))+
  geom_segment(aes(x = 1, y = 30, xend = 1, yend = 30))+
  geom_segment(aes(x = 3.2, y = 30, xend = 3.2, yend = 30))+
  
  geom_segment(aes(x = 1, y = 29, xend = 2, yend = 29))+
  geom_segment(aes(x = 1, y = 29, xend = 1, yend = 29))+
  geom_segment(aes(x = 2, y = 29, xend = 2, yend = 29))+
  
  geom_segment(aes(x = 2, y = 26, xend = 3.2, yend = 26))+
  geom_segment(aes(x = 2, y = 26, xend = 2, yend = 26))+
  geom_segment(aes(x = 3.2, y = 26, xend = 3.2, yend = 26))+  
  
  
  scale_fill_manual(
    name = "HDI", 
    values = c("0high" = "#F8766D", "3low" = "#6699FF", "2medium" = "#0CB702"),
    labels = c("0high" = "high", "3low" = "low","2medium" = "medium" ))+
  scale_x_discrete(labels = c("0high" = "high", "2medium" = "medium", "3low" = "low"))


HDis  
HDis <- HDis+geom_errorbar(limits, position = dodge, width=0.2) +
  geom_bar(position = dodge, stat = "identity")+
  annotate("text", x = 1.5, y=27.5, label = "P=0.02", size=3)+
  annotate("text", x = 2.5, y=24, label = "P=0.001", size=3)+
  annotate("text", x = 2.5, y=28, label = "P<0.0001", size=3)


HDis

ggsave(filename = "Fig 4-5.png", width = 70, height = 60, dpi = 600, units = "mm", device='png')
