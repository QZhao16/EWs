load(file = "Data/data.FigS7-S10.RData")
data.FigS9

library(ggplot2)
limits <- aes(ymax = MeanResponse + SE, ymin = MeanResponse - SE)
dodge <- position_dodge(width = 0.9)
outbreak_type<-ggplot(data.FigS9$outbreak_type, aes(x = outbreak.type, y = MeanResponse, fill = outbreak.type)) + geom_bar(position = dodge, stat = "identity") +
  geom_errorbar(limits, position = dodge, width = 0.2)+
  labs(title = "",
       x = "Outbreak type",
       y = "Lead time (day)",
       color = "") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), #,face="bold"
        axis.text.x = element_text(colour="black",size=8),  #,face="bold"
        axis.text.y = element_text(colour="black",size=8),  #,face="bold"
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8)) +
  scale_y_continuous(limit = c(-2,40))+
  annotate("text", x = 1.5, y=40, label = "P>0.05", size=3)

outbreak_type

outbreak_type+geom_errorbar(limits, position = dodge, width=0.2) +
  geom_bar(position = dodge, stat = "identity")+scale_fill_manual(values = c("first" = "#00A9FF", "latter" = "#8494FF")) 

ggsave(filename = "Fig S8.png", width = 80, height = 90, dpi = 600, units = "mm", device='png')




library(ggplot2)
fig3_populationdensity_Pathegon_type<-ggplot(data.FigS9$population.Pathegon_type, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="dashed") +
  labs(title = "",
       x = "Ln(population density)",
       y = "Lead time (day)",
       color = "Pathogen type") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), #,face="bold"
        axis.text.x = element_text(colour="black",size=8),  #,face="bold"
        axis.text.y = element_text(colour="black",size=8),  #,face="bold"
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10))  +#element_blank()
  scale_y_continuous(limit = c(-2,105))+
  scale_x_continuous(limit = c(0,9))

fig3_populationdensity_Pathegon_type

fig3_populationdensity_Pathegon_type<- fig3_populationdensity_Pathegon_type +geom_point(data = data.FigS9$sub_3, aes(x = population_density_log, y = Responses_time), shape=20, color="black",size=3) +
  geom_point(data = data.FigS9$sub_3, aes(x = population_density_log, y = Responses_time, color=Pathegon_type ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) +scale_color_manual(values = c("virus" = "#F8766D", "bacteria" = "#00A9FF")) 
fig3_populationdensity_Pathegon_type




# Plotting the interaction
fig3_populationdensity_Vector_borne<-ggplot(data.FigS9$population.Vector_borne, aes(x = x, y = predicted,color=group)) +
  geom_line(aes(x = x, y = predicted),size=1, linetype="dashed") +
  labs(title = "",
       x = "Ln(population density)",
       y = "Lead time (day)",
       color = "Vector-borne") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), #,face="bold"
        axis.text.x = element_text(colour="black",size=8),  #,face="bold"
        axis.text.y = element_text(colour="black",size=8),  #,face="bold"
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=10),
        legend.title =element_text(size=10))  +#element_blank()
  scale_y_continuous(limit = c(-2,105))+
  scale_x_continuous(limit = c(0,9))

fig3_populationdensity_Vector_borne
fig3_populationdensity_Vector_borne<- fig3_populationdensity_Vector_borne +geom_point(data = data.FigS9$sub_3, aes(x = population_density_log, y = Responses_time), shape=20, color="black",size=3) +
  geom_point(data = data.FigS9$sub_3, aes(x = population_density_log, y = Responses_time, color=Vector_borne ), show.legend = TRUE) +
  theme(plot.title = element_text(hjust = 0.5, size = 11)) +scale_color_manual(values = c("No" = "#F8766D", "Yes" = "#00A9FF")) #F8766D   #00BFC4 , #00A9FF #8494FF

fig3_populationdensity_Vector_borne


library(cowplot)
fig1 <- fig3_populationdensity_Vector_borne + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))
fig2 <- fig3_populationdensity_Pathegon_type + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))

X11(width=15, height=18)
combined_plot <- plot_grid(
  fig1, fig2, #fig3, 
  nrow = 1, ncol = 2, 
  align = "hv", 
  axis = "lrbt",
  rel_heights = c(1, 1,1, 1,1, 1,1, 1),
  rel_widths = c(1, 1,1, 1,1, 1,1, 1),
  labels = c("a", "b", "c", "d", "e", "f","g", "h"),
  label_size = 10
)

print(combined_plot)

ggsave(filename = "Fig S9.png", width = 170, height = 90, dpi = 600, units = "mm", device='png')




library(ggplot2)
# Creating a histogram
ggplot(data.FigS9$outbreak.distribution, aes(x = the_total)) + 
  geom_histogram(binwidth = 1, fill = "grey", color = "black") +
  labs(title = "Frequency for the number of outbreaks",
       x = "The number of outbreaks in each time series",
       y = "Count",
       color = "")+
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom')


ggsave(filename = "fig S10.png", width = 100, height = 100, dpi = 600, units = "mm", device='png')

