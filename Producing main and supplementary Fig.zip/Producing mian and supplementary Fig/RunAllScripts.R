
# set current folder as Working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()

source("Functions/map.Fig2.R")              #Generate Fig 2
source("Functions/ROC-AUC.Fig3.R")          #Generate Fig 3
source("Functions/lead time.Fig4.R")        #Generate Fig 4
source("Functions/Cox proportional hazard model.Fig5-FigS3.R") #Generate Fig 5, S3
source("Functions/FigS1-S2.R")              #Generate Fig S1, S2
source("Functions/lead time.FigS4.R")       #Generate Fig S4
source("Functions/AUC.Fig S5.R")            #Generate Fig S5
source("Functions/lead time.FigS6.R")       #Generate Fig S6
source("Functions/FigS7-S10.R")             #Generate Fig S7-10
