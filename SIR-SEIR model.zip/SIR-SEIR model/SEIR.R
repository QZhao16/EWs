################################################
######### Part 1: time-varying beta,  absolute abundance, no noise
################################################

library(deSolve)

# SEIR model differential equations
seir_model <- function(time, state, parameters) {
  with(as.list(c(state, parameters)), {
    
    # Define a function for beta as a time-varying parameter
    beta <- beta_function(time)
    
    dS <- -beta * S * I
    dE <- beta * S * I - sigma * E
    dI <- sigma * E - gamma * I
    dR <- gamma * I
    
    return(list(c(dS, dE, dI, dR)))
  })
}

beta_function <- function(time) { if (time <= 70) {return(0.0005)} else {return( 0.005+0.0002*(time-70) ) }}

# Initial number of individuals in each compartment
initial_state_values <- c(S = 99, E = 1, I = 0, R = 0)

# Parameters for the model
parameters <- c(sigma = 0.5, gamma = 0.1)

# Time sequence: from day 0 to day 160 in daily intervals
times <- seq(0, 200, by = 1)

# Solve the differential equations
result <- ode(y = initial_state_values, times = times, func = seir_model, parms = parameters, method = "ode45")

# Convert result to a data frame for plotting
result_df <- as.data.frame(result)

# Plot the results
plot(x = result_df$time, y = result_df$S, ylab = "Number of individuals", xlab = "Time (days)", type = "l", col = "blue", ylim = c(0, 1000), main = "SEIR Model Simulation")
lines(x = result_df$time, y = result_df$E, col = "yellow")
lines(x = result_df$time, y = result_df$I, col = "red")
lines(x = result_df$time, y = result_df$R, col = "green")
legend("right", c("Susceptible", "Exposed", "Infectious", "Recovered"), fill = c("blue", "yellow", "red", "green"))

#R_naught, R_e
output2=as.data.frame(result_df)
R_naught <- c(rep(0.0005, 70), 0.0005+0.0002*(71:200-70)  )/(parameters[2])
R_e <- R_naught*output2$S
R_e
# Plot SEIR time series
plot(output2$time, output2$S, type = "l", col = "blue", lwd = 2, xlab = "Time", ylab = "Number of Individuals") #, ylim=c(1,max(c(S,I,R)))
lines(output2$time, output2$E, type = "l", col = "black", lwd = 2)
lines(output2$time, output2$I, type = "l", col = "red", lwd = 2)
lines(output2$time, output2$R, type = "l", col = "green", lwd = 2)
legend("top", c("Susceptible","Exposed", "Infected", "Recovered"), col = c("blue","black", "red", "green"), lty = c(1, 1, 1))
# Plot Rt
plot(R_e, type = "l", col = "blue", lwd = 2, xlab = "Time", ylab = "Re") #, ylim=c(1,max(c(S,I,R)))





################################################
######### Part 2: time-varying beta,  absolute abundance,  noise
################################################

library(deSolve)

# Define the SEIR model function with time-varying beta and stochasticity
SEIRModelStochastic <- function(time, state, parameters) {
  with(as.list(c(state, parameters)), {
    
    # Define a function for beta as a time-varying parameter
    beta <- beta_function(time)
    
    # Stochasticity term (white noise)
    noise <- rnorm(4, mean = 0, sd = 0.001) # Adjust the sd as needed
    
    # Differential equations with stochasticity
    dS <- -beta * S * I
    dE <- beta * S * I - sigma * E
    dI <- (sigma * E - gamma * I + noise[3]) * dt
    dR <- gamma * I
    
    # Ensure non-negative values for state variables
    dS <- max(dS, 0)  # Ensure S remains non-negative
    dE <- max(dE, 0)  # Ensure E remains non-negative
    dI <- max(dI, 0)  # Ensure I remains non-negative
    dR <- max(dR, 0)  # Ensure R remains non-negative
    
    return(list(c(dS, dE, dI, dR)))
  })
}

beta_function <- function(time) { if (time <= 70) {return(0.0005)} else {return( 0.0005+0.0002*(time-70) ) }}

# Initial number of individuals in each compartment
initial_state <- c(S = 99, E = 1, I = 0, R = 0)

# Parameters for the model
parameters <- c(sigma = 0.6, gamma = 0.1)

dt <- 0.1 #0.1  # Time step for stochastic simulation

# Set the time points for simulation
time_points <- seq(0, 200, by = dt)

# Set random seed for reproducibility
set.seed(123)

# Solve the stochastic SEIR model differential equations
output <- ode(y = initial_state, times = time_points, func = SEIRModelStochastic, parms = parameters)

# Plot the results
plot(output, xlab = "Time", ylab = "cases", main = "Stochastic SEIR Model Simulation")
legend("topright", legend = c("Susceptible", "Exposed", "Infectious", "Recovered"), col = 1:4, lty = 1)

#R_naught, R_e
output2=as.data.frame(output)
R_naught <- c(rep(0.0005, 70), 0.0005+0.0002*(71:2000-70)  )/(parameters[2])
R_e <- R_naught*output2$S[1:length(R_naught)] 


# Plot SEIR time series
plot(output2$time, output2$S, type = "l", col = "blue", lwd = 2, xlab = "Time", ylim=c(1,max(c(output2$S,output2$I,output2$R))), ylab = "Number of Individuals") #
lines(output2$time, output2$E, type = "l", col = "black", lwd = 2)
lines(output2$time, output2$I, type = "l", col = "red", lwd = 2)
output2$I
lines(output2$time, output2$R, type = "l", col = "green", lwd = 2)
legend("top", c("Susceptible","Exposed", "Infected", "Recovered"), col = c("blue","black", "red", "green"), lty = c(1, 1, 1))
# Plot Rt
plot(R_e, type = "l", col = "blue", lwd = 2, xlab = "Time", ylab = "Re") #, ylim=c(1,max(c(S,I,R)))




