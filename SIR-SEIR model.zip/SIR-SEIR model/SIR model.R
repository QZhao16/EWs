
#############################################################################################
############################ Part 1  abolute values, time-varying beta, no noise #########
#############################################################################################
library(deSolve)
library(ggplot2)

# Define the ODE system with time-varying beta
sir_ode <- function(t, state, parameters) {
  par <- as.list(c(state, parameters))
  with(par, {
    
    # Define beta that monotonically increases, then decreases
    beta_t <- beta * (1 + 0.5 * tanh((t - peak_time)/width))
    
    dS <- -beta_t * S * I / N
    dI <- beta_t * S * I / N - gamma * I
    dR <- gamma * I
    
    list(c(dS, dI, dR))
  })
}

# Initial state values
init <- c(S = 990,  # susceptible
          I = 10,    # infected
          R = 0)     # recovered

# Parameters
parameters <- c(beta = 0.1,       # average infection rate
                gamma = 0.1,      # recovery rate
                N = 1000,         # total population
                peak_time = 100,   # time when beta peaks
                width = 20)       # width of the peak in beta

# Time sequence
times <- seq(0, 1000, by = 1)

# Solve the ODE system
out <- ode(y = init, times = times, func = sir_ode, parms = parameters)

# Convert output to data frame
out <- as.data.frame(out)

# Calculate Re over time
out$Re <- with(out, parameters["beta"] * (1 + 0.5 * tanh((time - parameters["peak_time"])/parameters["width"])) * S / (parameters["gamma"] * parameters["N"]))

out$S
out$I

# Plot the SIR model outputs
p1 <- ggplot(data = out, aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "SIR Model with Time-Varying Beta",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))

# Plot Re over time
p2 <- ggplot(data = out, aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

# Display plots
library(gridExtra)
grid.arrange(p1, p2, ncol = 1)





############################################################
############## part 2  abolute values, time-varying beta, with noise
############################################################
library(deSolve)
library(ggplot2)
library(gridExtra)

# Define the ODE system
sir_ode <- function(t, state, parameters) {
  par <- as.list(c(state, parameters))
  
  with(par, {
    beta_t <- beta_min + (beta_max - beta_min) / (1 + exp(-k * (t - t_mid)))  # Time-varying beta
    
    dS <- -beta_t * S * I / N
    dI <- beta_t * S * I / N - gamma * I
    dR <- gamma * I
    
    # Adding white noise to I
    noise_strength <- 0.1
    I <- max(I + rnorm(1, mean = 0, sd = noise_strength), 0)
    
    # Ensure non-negativity
    S <- max(S, 0)
    R <- max(R, 0)
    
    list(c(dS, dI, dR))
  })
}

# Initial state values and parameters
init <- c(S = 990, I = 10, R = 0)
parameters <- c(beta_min = 0.05, #0.1  # Minimum transmission rate
                beta_max = 0.5,   # Maximum transmission rate
                k = 0.1,          # Controls the steepness of the transition
                t_mid = 100,       # Time when beta(t) is mid-way between beta_min and beta_max
                gamma = 0.1,      # Recovery rate
                N = 1000)         # Total population

# Time sequence
times <- seq(0, 200, by = 1)

# Solve the ODE system
out <- ode(y = init, times = times, func = sir_ode, parms = parameters)
out <- as.data.frame(out)

# Calculating Re over time with time-varying beta
out$Re <- with(out, (parameters["beta_min"] + (parameters["beta_max"] - parameters["beta_min"]) / (1 + exp(-parameters["k"]* (times - parameters["t_mid"])))) * out$S / (parameters["gamma"] * parameters["N"]))

# Plotting
p1 <- ggplot(data = out, aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "SIR Model with Time-Varying Beta and Noise",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))

p2 <- ggplot(data = out, aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number (Re) over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

# Display plots
grid.arrange(p1, p2, ncol = 1)
