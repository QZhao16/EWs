##### load data
# convert week to date
# Set path
Root_Path <- 'C:/zhao088/US2023/U notre dame/meeting/meeting July2023/data from Jason/ews_data/ews_data'
OPath <- paste(Root_Path,sep='')
setwd(OPath)

data1=read.csv("taiwan.csv")
head(data1)


### average to same sampling frequency (per week in each year)
library(lubridate) # split date
unique(data1$Disease)

ii=2
for (ii in 1: length(unique(data1$Disease))) {
  
  data2=subset(data1,Disease==unique(data1$Disease)[ii] )
  
  
  eachdate<-as.data.frame( matrix(NA,nrow=nrow(data1), ncol=ncol(data1) +2) )
  eachdate[,1]<- unique(data1$Disease)[ii] #data1$Disease
  eachdate[,5]<- data1$ADM0
  eachdate[,6]<- data1$ADM1
  eachdate[,7]<- data1$ADM2
  colnames(eachdate)<- colnames(data1)
  
  j=2015
  i=1
  index=0
  # fill true temprature into NA-matrix
  for (j in unique(data2$EpiYear) ) {
    
    sub_unique<-subset(data2, EpiYear==j )
    
    for (i in unique(sub_unique$EpiWeek) ) {
      
      index=index+1
      
      sub_unique2<-subset(sub_unique, EpiWeek==i )
      
      eachdate$EpiYear[index]=j
      eachdate$EpiWeek[index]=i
      eachdate$Incidence[index]= mean(sub_unique2$Incidence,na.rm=TRUE)} # for i
  } # for j  
  
  eachdate2=eachdate[!is.na(eachdate$EpiYear), ] #remove NA year/incidence
  write.csv(eachdate2, file = paste("taiwan.disease.",unique(data1$Disease)[ii],'.csv',sep = "") )
  
}# for ii


