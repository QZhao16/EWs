library(mlbench)   #Version 2.1.3
library(Cubist)    #Version 0.4.2.1
library(tseriesChaos) #Version 0.1.13.1
library(TTR)       #Version 0.24.3
library(DMwR)      #Version 0.4.1
library(ifultools) #Version 2.0.26
library(wmtsa)     #Version 2.0.3
library(DescTools) #Version 0.99.49

library(scatterplot3d) #Version 0.3.44
library(forecast)   #Version 8.21
library(gtools)     #Version 3.9.4 
library(infotheo)   #Version 1.2.0.1

library(rEDM)       #Version 1.2.3
# inastall 1.2.3 rEDM with codes below:
packageurl <- "http://cran.r-project.org/src/contrib/Archive/rEDM/rEDM_1.2.3.tar.gz"
install.packages(packageurl, repos=NULL, type="source")
packageVersion("rEDM") #Version 1.2.3

library(seasonal)#Version 1.9.0
library(ape)     #Version 5.7.1
library(rgee)    #Version 1.1.5
library(ggplot2) #Version 3.4.2
library(tidyr)   #Version 1.3.0
library(ggplot2) #Version 3.4.2
library(reticulate) #Version 1.28
library(earlywarnings) #Version 1.1.29




#####meaning of each each earlier warming signal (EWs)
#####
#ar1, the autoregressive coefficient ar(1) of a first order AR model fitted on the data within the rolling window.
#sd, the standard deviation of the data estimated within each rolling window.
#sk, the skewness of the data estimated within each rolling window. 
#kurt, the kurtosis of the data estimated within each rolling window. 
#cv, the coefficient of variation of the data estimated within each rolling window. 
#returnrate, the return rate of the data estimated as 1-ar(1) cofficient within each rolling window. 
#densratio, the density ratio of the power spectrum of the data estimated as the ratio of low frequencies over high frequencies within each rolling window; 
#acf1, the autocorrelation at first lag of the data estimated within each rolling window.


##### load data
# convert week to date
# Set path
Root_Path <- 'C:/zhao088/US2023/U notre dame/meeting/meeting July2023/data from Jason/ews_data/ews_data'
OPath <- paste(Root_Path,sep='')
setwd(OPath)

data1=read.csv("colombia.csv")
head(data1)


### average to same sampling frequency (per week in each year)
library(lubridate) # split date
unique(data1$Disease)

ii=2
for (ii in 1: length(unique(data1$Disease))) {
  
data2=subset(data1,Disease==unique(data1$Disease)[ii] )
  

eachdate<-as.data.frame( matrix(NA,nrow=nrow(data1), ncol=ncol(data1) +2) )
eachdate[,1]<- unique(data1$Disease)[ii] #data1$Disease
eachdate[,5]<- data1$ADM0
eachdate[,6]<- data1$ADM1
eachdate[,7]<- data1$ADM2
colnames(eachdate)<- colnames(data1)

j=2015
i=1
index=0
# fill true temprature into NA-matrix
for (j in unique(data2$EpiYear) ) {
  
  sub_unique<-subset(data2, EpiYear==j )
  
  for (i in unique(sub_unique$EpiWeek) ) {
    
    index=index+1
    
    sub_unique2<-subset(sub_unique, EpiWeek==i )
    
    eachdate$EpiYear[index]=j
    eachdate$EpiWeek[index]=i
    eachdate$Incidence[index]= mean(sub_unique2$Incidence,na.rm=TRUE)} # for i
} # for j  

eachdate2=eachdate[!is.na(eachdate$EpiYear), ] #remove NA year/incidence
write.csv(eachdate2, file = paste("colombia.disease.",unique(data1$Disease)[ii],'.csv',sep = "") )

}# for ii


### visulize per disease over time
#[1] "Chikungunya"             "Dengue"                  "Hepatitis A"             "Hepatitis B"            
#[5] "Hepatitis C"             "Measles"                 "Pertussis"               "Malaria (P. falciparum)"
#[9] "Malaria (P. malariae)"   "Malaria (P. vivax)"      "Tuberculosis"            "Varicella"              
#[13] "Zika Virus" 
data_try=read.csv("colombia.disease.Chikungunya.csv") #
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Dengue.csv") # 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Hepatitis A.csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Hepatitis B.csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Hepatitis C.csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Measles.csv") # 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Pertussis.csv") # 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Malaria (P. falciparum).csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Malaria (P. malariae).csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Malaria (P. vivax).csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Tuberculosis.csv") #
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Varicella.csv")# 
plot(data_try$Incidence, type="l")
data_try=read.csv("colombia.disease.Zika Virus.csv")# 
plot(data_try$Incidence, type="l")




############# earlier warming signal analysis (EWS) 
data1=read.csv("colombia.disease.Pertussis.csv") 
plot(data1$Incidence, type="l")

data1=data1[, 2:ncol(data1)] # remove first column
data1=data1[data1$EpiWeek<=52,] # a year has 52 weeks, thus remove >53 week, otherwise as.Date function will give errors

data1$time<- as.Date(paste(data1$EpiYear, data1$EpiWeek,1, sep="-"), "%Y-%U-%u")
data1$time<- as.Date(data1$time, "%Y-%m-%d")
head(data1) 
str(data1)

data1=data1[!is.na(data1$time), ] #remove NA date

library(tidyverse)
data1=data1[!duplicated(data1$time), ] # remove duplicate

# sort by date
library(lubridate)
library(dplyr)

data1=data1[order(as.Date(data1$time, format="%Y-%m-%d")),] # sort date from Jan to Dec (from smallest to largest)

data1$number=1:nrow(data1)
head(data1)
# visulize incidence over time
ggplot(data1,aes(x = time, y = Incidence)) + geom_line() + theme_bw() + xlab("Time") +  ylab("Incidence")


######### new 1
data1$Incidence # checking zero
#data1=data1[100:250,] # remove zero values if neccessary, too many zeros are general statistical problems

data1$date=as.Date(paste(data1$EpiYear, data1$EpiWeek, 1, sep="-"), "%Y-%U-%u") #convert week to date
data1=data1[!is.na(data1$date),] # remove NA
data1=data1[order(data1$date),]# sort date
data1$Incidence=as.numeric(round(data1$Incidence)) # numeric
dim(data1)
# plot
plot(data1$date, data1$Incidence, type="l") 
data1$date


##########
##### Estimate Rt
##########

library(EpiEstim) # package version:2.2.4, to estimate Rt
load("estimateRe function.R") # load this function to estimate Rt. if cannot automatically load, mannually open the file, and then select and run all functions

results_1=estimateRe(dates=data1$date,incidenceData=as.data.frame(data1$Incidence))
dim(results_1)

# extract Rt and confidence interval (CI) position
CI_upper_start=which(results_1$date==results_1$date[1])[2] #start date
CI_upper_end=which(results_1$date==results_1$date[length(results_1$date)])[2] #end date
mean_start=which(results_1$date==results_1$date[1])[1] #start date
mean_end=which(results_1$date==results_1$date[length(results_1$date)])[1] #end date
CI_lower_start=which(results_1$date==results_1$date[1])[3] #start date
CI_lower_end=which(results_1$date==results_1$date[length(results_1$date)])[3] #end date
#merge 
mean_Rt=as.data.frame( cbind(as.data.frame(results_1$date[mean_start:mean_end]),results_1$value[mean_start:mean_end]) )
colnames(mean_Rt)=c("date","Rt")
CI_Rt_uppper=as.data.frame( cbind(as.data.frame(results_1$date[CI_upper_start:CI_upper_end]),results_1$value[CI_upper_start:CI_upper_end]) )
colnames(CI_Rt_uppper)=c("date","CI_Rt_uppper")
CI_Rt_lower=as.data.frame( cbind(as.data.frame(results_1$date[CI_lower_start:CI_lower_end]),results_1$value[CI_lower_start:CI_lower_end]) )
colnames(CI_Rt_lower)=c("date","CI_Rt_lower")
finals1=merge(mean_Rt,CI_Rt_uppper,by="date");finals2=merge(finals1,CI_Rt_lower,by="date")

data1=merge(finals2,data1,by="date")
head(data1)

# show Rt and CI
plot(data1$date,data1$Rt, type="l",col="blue",ylim=c(-1,max(data1$Rt)*2),lwd=0.5,
     xlab="time", ylab="Rt") #Rt
lines(data1$date,data1$CI_Rt_uppper , type="l",col="black", lty=1,lwd=0.5)
lines(data1$date,data1$CI_Rt_lower   , type="l",col="red", lty=1,lwd=2)



###################### calculate the EWs ("cv", "acf", "ar1", "dr", "rr", "skew", "kurt","SD"), using a moving window
# define parameters
removes=1       #starting point
window_size=50  #rolling window size

data1=data1[c(removes:nrow(data1)),] 

library(EWSmethods)

winsize =window_size/nrow(data1)*100

rolling_ews_eg <- uniEWS(data = data1[,c("number","Incidence")], 
                         metrics = c("cv", "acf", "ar1", "dr", "rr", "skew", "kurt","SD"), 
                         method = "rolling", winsize =winsize )
head(rolling_ews_eg$EWS$raw)

results.1=rolling_ews_eg$EWS$raw

colnames(results.1)<-c("number", colnames(results.1)[2:ncol(results.1)]) # match column names
results.1$time <- as.Date(data1$time[results.1$number-removes+1], format="%Y-%m-%d") #add matched date back to datasets.
str(results.1)
# plotting a sigal EWs(e.g. CV) over time
ggplot(results.1,aes(x = time, y = cv)) + 
  geom_line() + theme_bw() +  xlab("Time") + ylab("CV")




##############################
#### Part 2: compute maximum eigenvalue over time
#### from paper:Anticipating the occurrence and type of critical transitions


library(rEDM)   #package version: 1.2.3
library("sapa") #package version, 2.0.3

raw_time_series <- data1$Incidence; length(raw_time_series)  

tau <- 1 # time lag is 1, i.e. x(T+1)=f(x(t))
theta <- seq(0,2.5,by=0.5)

raw_time_series<-as.data.frame(raw_time_series)
step_size <- 1  #rolling window 1 time step (i.e. 1 week in current dataset) per calculating time

window_indices <- seq(window_size, NROW(raw_time_series), step_size)
matrix_result <- matrix(NaN, nrow = length(window_indices), ncol = 5)
index <- 0

for(j in window_indices) {
  index <- index + 1
  rolling_window <- raw_time_series[(j-window_size+1):j,] # select each rolling window
  
  norm_rolling_window <- (rolling_window - mean(rolling_window, na.rm=TRUE))/sd(rolling_window, na.rm=TRUE)
  
  #method 2: simplex projection to find best E (embedding dimension)
  #for each window
  sim_r <- simplex(norm_rolling_window,lib=c(1,floor(length(norm_rolling_window)/2)),pred=c(floor(length(norm_rolling_window)/2)+1,length(norm_rolling_window)),E=c(1:11))
  E <-sim_r[which.min(sim_r$mae),"E"][1] 
  
  
  # calculate best theta
  smap <- s_map(norm_rolling_window, E=E, tau=tau, theta=theta, silent=TRUE)
  best <- order(as.numeric(smap$mae))[1] # find position of best theta having lowest prediction error i.e. lowest mae 
  theta_best <- smap[best,]$theta ## find best theta having lowest prediction error i.e. lowest mae 
  
  # calculate interaction strength with best theta
  smap <- s_map(norm_rolling_window, E=E, tau=tau, theta=theta_best, silent=TRUE, save_smap_coefficients=TRUE)
  
  smap_co <- smap$smap_coefficients[[1]]
  
  # calculate max of eigenvalue
  matrix_eigen <- matrix(NA, nrow = NROW(smap_co), ncol = 3)
  
  for(k in 1:NROW(smap_co))
  {
    if(!is.na(smap_co[k,1]))
    {
      M <- rbind(as.numeric(smap_co[k, 1:E]), cbind(diag(E - 1), rep(0, E - 1)))
      M_eigen <- eigen(M)$values
      lambda1 <- M_eigen[order(abs(M_eigen))[E]]
      
      matrix_eigen[k,1] <- abs(lambda1) #max of eigenvalue
      matrix_eigen[k,2] <- Re(lambda1) # real part of the eigenvalue
      matrix_eigen[k,3] <- Im(lambda1) # imaginary part of the eigenvalue
    }
  }
  
  # save results
  matrix_result[index,1] <- j+removes-1
  matrix_result[index,2] <- as.character( as.Date(data1$time[c(j)],  "%Y-%m-%d") ) # add date back in to dataset
  matrix_result[index,3] <- mean(matrix_eigen[,1],na.rm=TRUE)
  matrix_result[index,4] <- mean(matrix_eigen[,2],na.rm=TRUE)
  matrix_result[index,5] <- mean(matrix_eigen[,3],na.rm=TRUE)
}

eigen <- as.data.frame(matrix_result)

colnames(eigen)<-c("number","time", "abs.lambda","re.lambda","lm.lambda")
head(eigen)

str(data1)
str(eigen)

eigen$time<-as.Date(eigen$time, "%Y-%m-%d")
eigen$number<-as.numeric(eigen$number)
eigen$abs.lambda<-as.numeric(eigen$abs.lambda)
eigen$re.lambda<-as.numeric(eigen$re.lambda)
eigen$lm.lambda<-as.numeric(eigen$lm.lambda)
str(eigen)

# plot
ggplot(eigen,aes(x = time, y = abs.lambda)) + 
  geom_line() + theme_bw() + xlab("Time") + ylab("Max(Eigen)") # larger than 1 means disease outbreak






############### Part 3: 9 warming signals for (variance,variance_first_diff,autocovariance,autocorrelation,decay_time,index_of_dispersion,coefficient_of_variation,skewness,kurtosis)
library(spaero) #package version, 0.6.0
library(pomp)   #package version, 5.1

out <- raw_time_series
dim(out)


EWs=get_stats(
  out,
  center_trend = "grand_mean",
  center_kernel = c("gaussian"),
  center_bandwidth = 100,
  stat_trend = c("local_constant"),
  stat_kernel = c("gaussian"),
  stat_bandwidth = 100,
  lag = 1,
  backward_only = FALSE
)
head(EWs$stats$variance)
length(EWs$stats$variance)
dim(simTransComms$community1)

# pick all EWs 
EWs_signal<-as.data.frame( cbind(as.character( as.Date(data1$time,  "%Y-%m-%d")) ,
                                 EWs$stats$variance,
                                 EWs$stats$variance_first_diff,
                                 EWs$stats$autocovariance,
                                 EWs$stats$autocorrelation,
                                 EWs$stats$decay_time,
                                 EWs$stats$index_of_dispersion,
                                 EWs$stats$coefficient_of_variation,
                                 EWs$stats$skewness,EWs$stats$kurtosis
                                 ) )
colnames(EWs_signal)<-c("time","variance","variance_first_diff","autocovariance","autocorrelation",
                        "decay_time","index_of_dispersion","coefficient_of_variation","skewness",
                        "kurtosis") # then only used:"variance_first_diff","autocovariance","decay_time","index_of_dispersion", because rests are same as line-224


EWs_signal$time<-as.Date(EWs_signal$time,  "%Y-%m-%d") #

# merge
 final_plot_data2 <- merge(data1,results.1,by="time") # combine the "results.1" data with the "raw" time series
 final_plot_data3 <- merge(final_plot_data2,eigen,by="time") # next, combine the "final_plot_data2" data with "eigen" dataset
 final_plot_data4 <- merge(final_plot_data3,EWs_signal,by="time")  # then, combine the "final_plot_data3" data with "EWs_signal" dataset
 
 head(final_plot_data4)

 
 # find tipping point Rt=1, i.e. lower CI =1  
 date_position=data1$date[floor(data1$CI_Rt_lower)>=1]
 date_position
 the_year=as.numeric(format(date_position,'%Y'))
 unique(the_year)
 
 yearss=NULL # only 2 months consutivelly outbreak will treated as outbreak, to elimilate noise.
 # searching literature by now, didn't find universal criteria to define the real outbreak
 i=2007
 for (i in unique(the_year)) { if (length(the_year[the_year==i])>=9) {yearss=cbind(yearss,i)}}
 yearss
 
 # Next, mannually double checking
 position1=as.Date("2011-01-03","%Y-%m-%d") # start of disease first outbreak,consutivelly outbreak from 2011-01-03 to 2011-06-06
 position2=as.Date("2011-06-06","%Y-%m-%d") # end of disease first outbreak
 #position3=as.Date("2013-04-08","%Y-%m-%d") # start of disease 2nd outbreak, but consutivelly outbreak=8 weeks ( from 2013-04-08 to 2013-05-27)
 #position4=as.Date("2013-05-27","%Y-%m-%d") # end of disease 2nd outbreak

 


 
 final_plot_data4$time
 final_plot_data4$Incidence
 fig1= ggplot(final_plot_data4,aes(x = time, y = Incidence)) + 
   geom_line(size=0.5) + 
   geom_point(size=0.5)+
   theme_bw() + 
   #xlab("Time") + ylab("Incidence")
   labs(title= "Cases of Pertussis",y="Cases of Pertussis", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   geom_vline(xintercept = as.numeric(position1), linetype="solid", color = "red",size=0.8)
 fig1
 
 ggsave("fig1.Incidence over time.colombia.Pertussis.png")
 
 
 
 ################### final part, test if monitonically decrease or increase for all 12 EWs
 final_plot_data5=final_plot_data4[1:which(final_plot_data4$time==position1),] # select data prior to outbreak for statistic analysis, slect point is "position1"
 tail(final_plot_data5)
 x=as.numeric(1:nrow(final_plot_data5))
 #cv  acf   ar1    dr  skew  kurt  SD   abs.lambda variance_first_diff autocovariance   autocorrelation decay_time index_of_dispersion

 
 # use the code below to install latest available "Kendall" package
 packageurl <- "https://cran.r-project.org/src/contrib/Archive/Kendall/Kendall_2.2.tar.gz"
 install.packages(packageurl, repos=NULL, type="source")
 library(Kendall) #packageVersion 2.2.1
 
 
 
 MannKendall(final_plot_data5$abs.lambda)
 fig2= ggplot(final_plot_data5,aes(x = time, y = abs.lambda)) + 
   geom_line() + 
   geom_hline(yintercept = 1,col = "black", linetype = "dashed") +
   theme_bw() + 
   #xlab("Time") + ylab("Max(abs(eigen))")
   labs(title= "Max(abs(eigen))",y="Max(abs(eigen))", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   scale_y_continuous(limit = c(0,2))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=1.5, label="",color="red", size=2)
 
 fig2
 
 MannKendall(final_plot_data5$cv)
 fig3= ggplot(final_plot_data5,aes(x = time, y = cv)) + 
   geom_line() + 
   theme_bw() + 
   labs(title= "Coefficient of variation CV",y="Coefficient of variation CV", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=0.6, label="",color="red", size=2)
 
 fig3 
 
 
 final_plot_data5$acf=as.numeric(final_plot_data5$acf)
 MannKendall(final_plot_data5$acf)
 fig4= ggplot(final_plot_data5,aes(x = time, y = acf)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") +  ylab("autocovariance")+
   labs(title= "Autocorrelation at first lag acf(1)",y="Autocorrelation 
at first lag acf(1)", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=0.6, label="",color="red", size=2)
 
 fig4
 
 
 MannKendall(final_plot_data5$ar1)
 fig5= ggplot(final_plot_data5,aes(x = time, y = ar1)) + #ar1 the autoregressive coefficient ar(1) of a first order AR model fitted on the data within the rolling window.
   geom_line() + 
   #  geom_point() + 
   theme_bw() +
   #xlab("Time") + ylab("Autoregressive coefficient ar(1)")
   labs(title= "Autoregressive coefficient ar1",y="Autoregressive 
  coefficient ar(1)", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=0.6, label="",color="red", size=2)
 
 fig5
 
 MannKendall(final_plot_data5$dr)
 fig6= ggplot(final_plot_data5,aes(x = time, y = dr)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") + ylab("Density ratio")
   labs(title= "Density ratio",y="Density ratio", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=0.6, label="",color="red", size=2)
 fig6
 
 MannKendall(final_plot_data5$skew)
 fig7= ggplot(final_plot_data5,aes(x = time, y = skew)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") + ylab("skewness")
   labs(title= "skewness",y="skewness", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=0.6, label="",color="red", size=2)
 fig7
 
 MannKendall(final_plot_data5$kurt)
 fig8= ggplot(final_plot_data5,aes(x = time, y = kurt)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") + ylab("kurtosis")
   labs(title= "kurtosis",y="kurtosis", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=2, label="",color="red", size=2)
 fig8
 
 
 MannKendall(final_plot_data5$SD)
 fig9= ggplot(final_plot_data5,aes(x = time, y = SD)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") + ylab("SD")
   labs(title= "standard deviation(SD)",y="standard deviation(SD)", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=3, label="",color="red", size=2)
 fig9
 
 MannKendall(final_plot_data5$variance_first_diff)
 final_plot_data5$variance_first_diff=as.numeric(final_plot_data5$variance_first_diff)
 fig10= ggplot(final_plot_data5,aes(x = time, y = variance_first_diff)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") + ylab("first-differenced variance")
   labs(title= "first-differenced variance",y="first-differenced variance", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=0.01, label="",color="red", size=2)
 fig10
 
 
 MannKendall(final_plot_data5$autocovariance)
 final_plot_data5$autocovariance=as.numeric(final_plot_data5$autocovariance)
 fig11= ggplot(final_plot_data5,aes(x = time, y = autocovariance)) + 
   geom_line() + 
   theme_bw() + 
   #xlab("Time") +  ylab("autocovariance")+
   labs(title= "autocovariance",y="autocovariance", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=10, label="",color="red", size=2)
 
 fig11
 
 
 MannKendall(final_plot_data5$decay_time)
 final_plot_data5$decay_time=as.numeric(final_plot_data5$decay_time)
 fig12= ggplot(final_plot_data5,aes(x = time, y = decay_time)) + 
   geom_line() + 
   theme_bw() +
   #xlab("Time") +ylab("decay time")
   labs(title= "decay time",y="decay time", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=1.5, label="",color="red", size=2)
 fig12
 
 
 MannKendall(final_plot_data5$index_of_dispersion)
 final_plot_data5$index_of_dispersion=as.numeric(final_plot_data5$index_of_dispersion)
 fig13= ggplot(final_plot_data5,aes(x = time, y = index_of_dispersion)) + 
   geom_line() + 
   theme_bw() +
   #xlab("Time") + ylab("index of dispersion")
   labs(title= "index of dispersion",y="index of dispersion", x = "Time")+
   theme(plot.title = element_text(hjust = 0.5))+
   #theme(plot.title = element_text(hjust = 0.5,size=6), legend.position='bottom')+
   theme(plot.title = element_text(hjust = 0.5,size=6))+
   theme(axis.title.y = element_text(colour="black",size=6), #,face="bold"
         axis.text.x = element_text(angle = 0,colour="black",size=6),  #,face="bold"
         axis.text.y = element_text(colour="black",size=6),  #,face="bold"
         axis.title.x = element_text(colour="black",size=6),
         legend.text=element_text(size=6),
         legend.title =element_text(size=6))+
   annotate(geom="text", x=as.Date("2009-06-30","%Y-%m-%d"), y=3, label="",color="red", size=2)
 fig13
 
 
 
 
 
 
 
 
 
 
 
 library(cowplot)
 X11(width=15, height=18)
 legend_b <- get_legend( fig1 +guides(color = guide_legend(nrow = 4)) +
                           theme(legend.position = "bottom"))
 
 prow <-plot_grid(fig1 + theme(legend.position="none"),
                  fig2 + theme(legend.position="none"),
                  fig3 + theme(legend.position="none"),
                  
                  fig4 + theme(legend.position="none"),
                  fig5 + theme(legend.position="none"),
                  fig6 + theme(legend.position="none"),
                  
                  fig7 + theme(legend.position="none"),
                  fig8 + theme(legend.position="none"),
                  fig9 + theme(legend.position="none"),
                  
                  fig10 + theme(legend.position="none"),
                  fig11 + theme(legend.position="none"),
                  fig12 + theme(legend.position="none"),
                  
                  fig13 + theme(legend.position="none"),
                  
                  align = 'vh',
                  labels = c("a", "b", "c", "d", "e", "f", "g", "h", "i","j", "k", "l", "m"),
                  label_size=7,
                  hjust = -0,
                  ncol  = 4,
                  nrow  = 4)
 
 plot_grid(prow, legend_b,ncol = 1,rel_heights = c(1, 0)) #0.1 is lengend 0.1 height
 
 
 ggsave(filename = "EWs.colombia.Pertussis.png", bg = "transparent", width = 180, height = 180, dpi = 600,  units = "mm", device='png')
 
