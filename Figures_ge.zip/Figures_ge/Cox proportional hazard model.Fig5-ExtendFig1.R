library(multcompView)
library(tidyverse)
library(lmerTest)
library(reshape2)
library(multcomp)
library(emmeans)
library(cluster)
library(scales)
library(coxme)
library(car)
library(pcr)
library(ggplot2)
library(ggeffects)
library(glmmTMB)
library(Matrix)
library(lme4)


################################### log-using
load("Cox proportional hazard model.RData")

summary(model_s1111 <- coxme::coxme(Surv(seq_length, outbreak_posit2)~ 
                                      
                                      I(scale(temp_in_window_mean_log)^2)+
                                      scale(temp_in_window_mean_log)+
                                      I(scale(PRCP_mean_log)^2)+
                                      scale(PRCP_mean_log)+
                                      HDI_s+
                                      scale(length_time_series_log)+
                                      Pathegon_type+
                                      Vector_borne+
                                      
                                      Pathegon_type*I(scale(temp_in_window_mean_log)^2)+
                                      Pathegon_type*scale(temp_in_window_mean_log)+
                                      
                                      Vector_borne*scale(PRCP_mean_log)+
                                      Vector_borne*I(scale(PRCP_mean_log)^2)+
                                      Vector_borne*HDI_s+
                                      
                                      (1|country_region/disease),
                                    data=sub_3) )



# raw coeffiecent
model_summary <- summary(model_s1111)
coefficients_table <- model_summary$coef
coefficients_table<-as.data.frame(coefficients_table)
coeff_ = data.frame(predictor=rownames(coefficients_table), coef=coefficients_table$coef, se=coefficients_table$se,p_value=coefficients_table$p )
#
coeff_$predictor<-c(
  "temperature^2",
  "temperature",
  "precipitation^2",
  "precipitation",
  "HDI (low)",
  "HDI (medium)",
  "length time series",
  "Pathogen type",
  "Vector borne",
  
  "Pathogen type*temperature^2",
  "Pathogen type*temperature",
  "Vector borne*precipitation",
  "Vector borne*precipitation^2",
  "Vector borne*HDI (low)",
  "Vector borne*HDI (medium)"
  
  
)

library(scales) # to access break formatting functions
Fig_coeffcient<- ggplot(coeff_, aes(x=predictor,  y=coef, fill=predictor))+
  geom_col()+
  geom_point(size=0.4)+
  geom_errorbar(aes(ymin=coef-se, ymax=coef+se), width=0.2, size=0.3)+
  coord_flip() +
  theme(legend.position="none")+
  ylab("Coefficient")+
  xlab("")+
  ggtitle("") +
  theme(plot.title = element_text(hjust = 0.5,size=9), legend.position='none')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  scale_y_continuous(limits=c(-11, 42))+
  geom_hline(yintercept=0, linetype="dashed",size=0.5)+
  
  geom_text(aes(x = 14.5, y = 30, label = "P=0.01*"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 13.3, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  
  geom_text(aes(x = 12.5, y = 32, label = "P=0.001**"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 11.3, y = 32, label = "P=0.0003***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 10.5, y = 32, label = "P=0.85"), size=2.6,vjust = -1, color = "black")+
  
  geom_text(aes(x = 9.3, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 8.5, y = 32, label = "P=0.36"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 7.5, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 6.3, y = 32, label =  "P=0.85"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 5.3, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 4.5, y = 32, label = "P=0.06"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 3.5, y = 32, label = "P=0.009**"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 2.5, y = 32, label = "P<0.0001***"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 1.5, y = 32, label = "P=0.95"), size=2.6,vjust = -1, color = "black")+
  geom_text(aes(x = 0.5, y = 32, label = "P=0.64"), size=2.6,vjust = -1, color = "black")
Fig_coeffcient










#############
###### Part 1: only for tau value
#############
#cosme
options(na.action = "na.fail")
summary(model_ <- coxme::coxme(Surv(seq_length, outbreak_posit2)~ 
                                 tau_value+
                             (1|country_region/disease),
                           data=sub_3) )


# raw coeffiecent
model_summary <- summary(model_)
coefficients_table <- model_summary$coef
coefficients_table<-as.data.frame(coefficients_table)
coeff_ = data.frame(predictor=rownames(coefficients_table), coef=coefficients_table$coef, se=coefficients_table$se )
#
coeff_$predictor<-c("tau_value")
#
library(scales) 
Fig_coeffcient<- ggplot(coeff_, aes(x=predictor,  y=coef, color=predictor))+
  geom_line() +
  geom_point(size=1.5)+
  geom_errorbar(aes(ymin=coef-se, ymax=coef+se), width=0.2, size=0.5)+
  theme_gray() +
  theme(legend.position="none")+
  ylab("Coefficient")+
  xlab("Tau value of RIs")+
  ggtitle("") +
  theme(plot.title = element_text(hjust = 0.5,size=9), legend.position='none')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_blank(),  
        axis.text.y = element_text(colour="black",size=10),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  scale_y_continuous(limits=c(0, 2))+
geom_text(aes(x = 1, y = 1.8, label = "P=0.03*"), size=3,vjust = -1, color = "black")

Fig_coeffcient


#glmmtmb
summary(model_full <- glmmTMB(
    length_ss~
    tau_value+
    (1 | country_region:disease ),
  data = sub_3,
  family = nbinom2(link = "log")
)  
)


preds <- ggpredict(model_full, terms = c("tau_value[all]"))
preds <- as.data.frame(preds)
#
fig3_incubation<-ggplot(preds, aes(x = x, y = predicted)) +
  geom_line(aes(x = x, y = predicted),linewidth=1, linetype="solid") +
  geom_ribbon(aes(ymin = conf.low, ymax = conf.high), alpha = 0.2, fill = "gray15",linetype = "dashed", size=NA) +
  labs(title = "",
       x = "Tau value of RIs",
       y = "Time to outbreak (day)",
       color = "") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5, size = 10), legend.position = 'bottom') +
  theme(plot.title = element_text(hjust = 0.5,size=12), legend.position='bottom')+
  guides(color = guide_legend(nrow = 1))+
  theme(axis.title.y = element_text(colour="black",size=10), 
        axis.text.x = element_text(colour="black",size=8),  
        axis.text.y = element_text(colour="black",size=8),  
        axis.title.x = element_text(colour="black",size=10),
        legend.text=element_text(size=8),
        legend.title =element_text(size=8))  +
  scale_y_continuous(limit = c(4,63))+
  scale_x_continuous(limit = c(-0.8,1))

fig3_incubation

fig3_incubation<- fig3_incubation +geom_point(data = sub_3, aes(x = tau_value , y = length_ss), color="#00A9FF", shape=20, size=3) + #color="#00A9FF",  color="#8494FF",  
theme(plot.title = element_text(hjust = 0.5, size = 11)) 
fig3_incubation



############### 
library(cowplot)
fig1 <- Fig_coeffcient + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))
fig2 <- fig3_incubation + theme(plot.margin = unit(c(0.1, 0.1, 0.1, 0.1), "cm"))

X11(width=15, height=18)
combined_plot <- plot_grid(
  fig1, fig2, 
  nrow = 1, ncol = 2, 
  align = "hv", 
  axis = "lrbt",
  rel_heights = c(1, 1,1, 1,1, 1,1, 1),
  rel_widths = c(1, 1,1, 1,1, 1,1, 1),
  labels = c("a", "b", "c", "d", "e", "f","g", "h"),
  label_size = 10
)

# Display the combined plot
print(combined_plot)





