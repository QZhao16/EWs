library(mlbench)   #Version 2.1.3
library(Cubist)    #Version 0.4.2.1
library(tseriesChaos) #Version 0.1.13.1
library(TTR)       #Version 0.24.3
library(ifultools) #Version 2.0.26
library(wmtsa)     #Version 2.0.3
library(DescTools) #Version 0.99.49
library(scatterplot3d) #Version 0.3.44
library(forecast)   #Version 8.21
library(gtools)     #Version 3.9.4 
library(infotheo)   #Version 1.2.0.1
library(rEDM)       #Version 1.2.3
library(seasonal)#Version 1.9.0
library(ape)     #Version 5.7.1
library(rgee)    #Version 1.1.5
library(ggplot2) #Version 3.4.2
library(tidyr)   #Version 1.3.0
library(ggplot2) #Version 3.4.2
library(reticulate) #Version 1.28
library(earlywarnings) #Version 1.1.29
library(gridExtra) #Version 2.3

# Part 1: ADIO data
setwd("C:/zhao088/US2023/U notre dame/meeting/meeting July2023/data from Jason/ews_data/ews_data")
#
data1<-read.csv("bolivia.disease.Dengue.csv")
head(data1)
dim(data1)
plot(data1$Incidence, type="l")

data1=data1[data1$EpiWeek<=52,] # remove >53 week
data1$date<- as.Date(paste(data1$EpiYear, data1$EpiWeek,1, sep="-"), "%Y-%U-%u")

data1$date<- as.Date(data1$date, "%Y-%m-%d")
data1=data1[!is.na(data1$date), ] #remove NA date
library(tidyverse)
library(dplyr)
data1=data1[!duplicated(data1$date), ] # remove duplicate
head(data1)

data1=data1[order(data1$date),] #sort from most recent to least recent

#estimate Re
load("estimateRe function.R")
results_1=estimateRe(dates=data1$date,incidenceData=as.data.frame(data1$Incidence))
dim(results_1)
# extract Rt and confidence interval (CI) position
CI_upper_start=which(results_1$date==results_1$date[1])[2] #start date
CI_upper_end=which(results_1$date==results_1$date[length(results_1$date)])[2] #end date
mean_start=which(results_1$date==results_1$date[1])[1] #start date
mean_end=which(results_1$date==results_1$date[length(results_1$date)])[1] #end date
CI_lower_start=which(results_1$date==results_1$date[1])[3] #start date
CI_lower_end=which(results_1$date==results_1$date[length(results_1$date)])[3] #end date
#merge 
mean_Rt=as.data.frame( cbind(as.data.frame(results_1$date[mean_start:mean_end]),results_1$value[mean_start:mean_end]) )
colnames(mean_Rt)=c("date","Rt")
CI_Rt_uppper=as.data.frame( cbind(as.data.frame(results_1$date[CI_upper_start:CI_upper_end]),results_1$value[CI_upper_start:CI_upper_end]) )
colnames(CI_Rt_uppper)=c("date","CI_Rt_uppper")
CI_Rt_lower=as.data.frame( cbind(as.data.frame(results_1$date[CI_lower_start:CI_lower_end]),results_1$value[CI_lower_start:CI_lower_end]) )
colnames(CI_Rt_lower)=c("date","CI_Rt_lower")
finals1=merge(mean_Rt,CI_Rt_uppper,by="date")
finals2=merge(finals1,CI_Rt_lower,by="date")

dim(CI_Rt_uppper)
dim(finals2)
dim(data1)

data1=merge(finals2,data1,by="date")
head(data1)

data1=data1[!is.na(data1$Rt), ] # remove NA Rt

# find tipping point Rt=1, i.e. lower CI =1  ###### ######### new 2
date_position=data1$date[floor(data1$CI_Rt_lower)>=1]
date_position
the_year=as.numeric(format(date_position,'%Y'))
unique(the_year)

#yearss=NULL # only 2 months consutivelly outbreak will treated as outbreak, to elimilate noise.
#i=2007
#for (i in unique(the_year)) { if (length(the_year[the_year==i])>=2) {yearss=cbind(yearss,i)}}
#yearss
#position1=date_position[which(the_year==yearss[1])[1]]# disease first outbreak
#position1_end=date_position[max(which(the_year==yearss[1]))] # end disease first outbreak
#position2=date_position[which(the_year==yearss[2])[1]]# disease second outbreak
#position2_end=date_position[max(which(the_year==yearss[2]))] # end disease second outbreak
#position3=date_position[which(the_year==yearss[3])[1]]# disease third outbreak
#position3_end=date_position[max(which(the_year==yearss[3]))]# end disease third outbreak

position1=as.Date("2016-1-18","%Y-%m-%d") # start of first outbreak
position1_end=as.Date("2016-1-25","%Y-%m-%d") # end of first outbreak
position2=as.Date("2017-1-30","%Y-%m-%d") # start of second outbreak
position2_end=as.Date("2017-2-20","%Y-%m-%d") # end of second outbreak
position3=as.Date("2018-1-15","%Y-%m-%d") # start of 3nd outbreak
position3_end=as.Date("2018-3-5","%Y-%m-%d") # end of 3nd outbreak
position4=as.Date("2018-10-29","%Y-%m-%d") # start of 4th outbreak


fig0= ggplot(data1,aes(x = date, y = Incidence)) + 
  geom_line() + 
  #geom_vline(xintercept = data1$inflection_pt,col = "grey60", linetype = "dashed") +
  ##geom_hline(yintercept = 1,col = "red", linetype = "dashed") +
  theme_bw() + 
  #xlab("Time") + ylab("Incidence")
  labs(title= "Dengue cases at Bolivia",y="Cases over time", x = "Time")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_vline(xintercept = as.numeric(position1), linetype="dashed", color = "red",size=0.7)+
  geom_vline(xintercept = as.numeric(position1_end), linetype="dashed", color = "blue",size=0.7)+
  geom_vline(xintercept = as.numeric(position2), linetype="dashed", color = "red",size=0.7)+
  geom_vline(xintercept = as.numeric(position2_end), linetype="dashed", color = "blue",size=0.7)+
  geom_vline(xintercept = as.numeric(position3), linetype="dashed", color = "red",size=0.7)+
  geom_vline(xintercept = as.numeric(position3_end), linetype="dashed", color = "blue",size=0.7)+
  geom_vline(xintercept = as.numeric(position4), linetype="dashed", color = "red",size=0.7)
  #geom_vline(xintercept = as.numeric(position4_end), linetype="dashed", color = "blue",size=0.7)+
  #geom_vline(xintercept = as.numeric(position5), linetype="dashed", color = "red",size=1.5)+
  #geom_vline(xintercept = as.numeric(position5_end), linetype="dashed", color = "blue",size=0.7)+
  #geom_vline(xintercept = as.numeric(position6), linetype="dashed", color = "red",size=1.5)+
  #geom_vline(xintercept = as.numeric(position6_end), linetype="dashed", color = "blue",size=0.7)+
  #geom_vline(xintercept = as.numeric(position7), linetype="dashed", color = "red",size=1.5)+
  #geom_vline(xintercept = as.numeric(position7_end), linetype="dashed", color = "blue",size=0.7)+
  #geom_vline(xintercept = as.numeric(position8), linetype="dashed", color = "red",size=1.5)+
  #geom_vline(xintercept = as.numeric(position8_end), linetype="dashed", color = "blue",size=0.7)


fig0
ggsave(filename = "0.Dengue cases at Bolivia.png", bg = "transparent", width = 180, height = 180, dpi = 600,  units = "mm", device='png')



#  Part:2, the tippiong point: 1)two consecutive points with Re>=1; 2)at least 3 points with Re>=1 within a month
write.csv(data1,"0.bolivia.disease.Dengue-re.csv")

phase_1<-data1[3:26,] # Phase 1: small outbreak, visibly judge
phase_2<-data1[28:74,] # Phase 2: small outbreak, visibly judge
phase_3<-data1[82:114,] # Phase 3: big outbreak, visibly judge, use the big outbreak


load("12 common EWs-1.R")
load("13.vest_functions-1.R")
load("0.surrogates5.R")



##################### testing Phase 1:
new_data=phase_1

#common EWs + P value
leng_window=10 # difine the length of time window
number=100 # fine the number of surrogates
final_results_1=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
                      c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
                      c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
                      c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
                      c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                      c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                      c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
                      c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                      c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                      c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                      c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                      c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                      #vest function
                      c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)),"relative_dispersions"),
                      #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                      c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                      c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                      c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                      #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                      c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                      c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                      c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                      c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                      c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                      c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys") )

final_results_1=as.data.frame(final_results_1)
final_results_1$disease="Dengue"
final_results_1$country_region="Bolivia"
colnames(final_results_1)=c("P_value","trend","disease","country_region") #1 upward; -1 downward




###### plot EWs
jpeg(file="0.AR(1)-phase1.png")
plot(1:length(AR1(new_data$Incidence,leng_window,1)),AR1(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(1)")
text(10,0.2,"P=0.39, Kendall's Tau")
dev.off()

jpeg(file="0.AR(2)-phase1.png")
plot(1:length(AR2(new_data$Incidence,leng_window,1)),AR2(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(2)")
text(10,0.2,"P=0.11, Kendall's Tau")
dev.off()

jpeg(file="0.AR(3)-phase1.png")
plot(1:length(AR3(new_data$Incidence,leng_window,1)),AR3(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(3)")
text(10,0.2,"P=0.45, Kendall's Tau")
dev.off()

jpeg(file="0.SD-phase1.png")
plot(1:length(SD(new_data$Incidence,leng_window,1)),SD(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="SD")
text(10,50,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Skewness-phase1.png")
plot(1:length(Skewness(new_data$Incidence,leng_window,1)),Skewness(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Skewness")
text(10,0.2,"P=0.49, Kendall's Tau")
dev.off()

final_results_1
jpeg(file="0.Kurtosis-phase1.png")
plot(1:length(Kurtosis(new_data$Incidence,leng_window,1)),Kurtosis(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Kurtosis")
text(10,0.2,"P=0.49, Kendall's Tau")
dev.off()

jpeg(file="0.CV-phase1.png")
plot(1:length(CV(new_data$Incidence,leng_window,1)),CV(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="CV")
text(10,0.8,"P=0.27, Kendall's Tau")
dev.off()

jpeg(file="0.first_differenced_variance-phase1.png")
plot(1:length(first_differenced_variance(new_data$Incidence,leng_window,1)),first_differenced_variance(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="first_differenced_variance")
text(10,1000,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Autocovariance-phase1.png")
plot(1:length(Autocovariance(new_data$Incidence,leng_window,1)),Autocovariance(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Autocovariance")
text(10,5000,"P=0.05, Kendall's Tau")
dev.off()


jpeg(file="0.index_of_dispersion-phase1.png")
plot(1:length(index_of_dispersion(new_data$Incidence,leng_window,1)),index_of_dispersion(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="index_of_dispersion")
text(10,20,"P=0.08, Kendall's Tau")
dev.off()

jpeg(file="0.density_ratio-phase1.png")
plot(1:length(density_ratio(new_data$Incidence,leng_window,1)),density_ratio(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="density_ratio")
text(10,0.2,"P=0.19, Kendall's Tau")
dev.off()

jpeg(file="0.Max_eigen-phase1.png")
plot(1:length(Max_eigen(new_data$Incidence,leng_window,1)),Max_eigen(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Max_eigen")
text(10,1,"P=0.08, Kendall's Tau")
dev.off()

#vest function
jpeg(file="0.relative_dispersions-phase1.png")
plot(1:length(relative_dispersions(new_data$Incidence,leng_window,1)),relative_dispersions(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="relative_dispersions")
text(10,0.7,"P=0.08, Kendall's Tau")
dev.off()

jpeg(file="0.Hurst_exponents-phase1.png")
plot(1:length(Hurst_exponents(new_data$Incidence,leng_window,1)),Hurst_exponents(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Hurst_exponents")
text(10,-0.4,"P=0.09, Kendall's Tau")
dev.off()

jpeg(file="0.time_series_acceleration-phase1.png")
plot(1:length(time_series_acceleration(new_data$Incidence,leng_window,1)),time_series_acceleration(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="time_series_acceleration")
text(10,0.2,"P=0.3,4 Kendall's Tau")
dev.off()

jpeg(file="0.Slopes-phase1.png")
plot(1:length(Slopes(new_data$Incidence,leng_window,1)),Slopes(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Slopes")
text(10,0.02,"P=0.13, Kendall's Tau")
dev.off()

jpeg(file="0.no_outliers-phase1.png")
plot(1:length(no_outliers(new_data$Incidence,leng_window,1)),no_outliers(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="no_outliers")
text(10,1,"P=0.32, Kendall's Tau")
dev.off()


jpeg(file="0.Step_changes-phase1.png")
plot(1:length(Step_changes(new_data$Incidence,leng_window,1)),Step_changes(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Step_changes")
text(10,0.2,"P=0.46, Kendall's Tau")
dev.off()


jpeg(file="0.N_peaks-phase1.png")
plot(1:length(N_peaks(new_data$Incidence,leng_window,1)),N_peaks(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="N_peaks")
text(20,0.25,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Turning_Points-phase1.png")
plot(1:length(Turning_Points(new_data$Incidence,leng_window,1)),Turning_Points(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Turning_Points")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.FFT_AMP-phase1.png")
plot(1:length(FFT_AMP(new_data$Incidence,leng_window,1)),FFT_AMP(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="FFT_AMP")
text(10,1,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.poincare_variabilitys-phase1.png")
plot(1:length(poincare_variabilitys(new_data$Incidence,leng_window,1)),poincare_variabilitys(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="poincare_variabilitys")
text(20,1,"P=0.19, Kendall's Tau")
dev.off()




##################### testing Phase 2:
new_data=phase_2

#common EWs + P value
leng_window=10 # difine the length of time window
number=100 # fine the number of surrogates
final_results_1=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
                      c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
                      c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
                      c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
                      c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
                      c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
                      c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
                      c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
                      c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
                      c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
                      c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
                      c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
                      #vest function
                      c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)),"relative_dispersions"),
                      #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
                      c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
                      c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
                      c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
                      #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
                      c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
                      c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
                      c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
                      c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
                      c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
                      c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys") )

final_results_1=as.data.frame(final_results_1)
final_results_1$disease="Dengue"
final_results_1$country_region="Bolivia"
colnames(final_results_1)=c("P_value","trend","disease","country_region") #1 upward; -1 downward




###### plot EWs
jpeg(file="0.AR(1)-phase2.png")
plot(1:length(AR1(new_data$Incidence,leng_window,1)),AR1(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(1)")
text(10,0.2,"P=0.16, Kendall's Tau")
dev.off()

jpeg(file="0.AR(2)-phase2.png")
plot(1:length(AR2(new_data$Incidence,leng_window,1)),AR2(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(2)")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.AR(3)-phase2.png")
plot(1:length(AR3(new_data$Incidence,leng_window,1)),AR3(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(3)")
text(10,0.2,"P=0.48, Kendall's Tau")
dev.off()

jpeg(file="0.SD-phase2.png")
plot(1:length(SD(new_data$Incidence,leng_window,1)),SD(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="SD")
text(10,5,"P=0.02, Kendall's Tau")
dev.off()

jpeg(file="0.Skewness-phase2.png")
plot(1:length(Skewness(new_data$Incidence,leng_window,1)),Skewness(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Skewness")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

final_results_1
jpeg(file="0.Kurtosis-phase2.png")
plot(1:length(Kurtosis(new_data$Incidence,leng_window,1)),Kurtosis(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Kurtosis")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.CV-phase2.png")
plot(1:length(CV(new_data$Incidence,leng_window,1)),CV(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="CV")
text(10,0.8,"P=0.33, Kendall's Tau")
dev.off()

jpeg(file="0.first_differenced_variance-phase2.png")
plot(1:length(first_differenced_variance(new_data$Incidence,leng_window,1)),first_differenced_variance(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="first_differenced_variance")
text(10,10,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Autocovariance-phase2.png")
plot(1:length(Autocovariance(new_data$Incidence,leng_window,1)),Autocovariance(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Autocovariance")
text(10,5,"P=0.01, Kendall's Tau")
dev.off()


jpeg(file="0.index_of_dispersion-phase2.png")
plot(1:length(index_of_dispersion(new_data$Incidence,leng_window,1)),index_of_dispersion(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="index_of_dispersion")
text(10,2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.density_ratio-phase2.png")
plot(1:length(density_ratio(new_data$Incidence,leng_window,1)),density_ratio(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="density_ratio")
text(10,0.2,"P=0.43, Kendall's Tau")
dev.off()

jpeg(file="0.Max_eigen-phase2.png")
plot(1:length(Max_eigen(new_data$Incidence,leng_window,1)),Max_eigen(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Max_eigen")
text(10,0.2,"P=0.02, Kendall's Tau")
dev.off()

#vest function
jpeg(file="0.relative_dispersions-phase2.png")
plot(1:length(relative_dispersions(new_data$Incidence,leng_window,1)),relative_dispersions(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="relative_dispersions")
text(10,0.7,"P=0.44, Kendall's Tau")
dev.off()

jpeg(file="0.Hurst_exponents-phase2.png")
plot(1:length(Hurst_exponents(new_data$Incidence,leng_window,1)),Hurst_exponents(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Hurst_exponents")
text(10,-0.4,"P=0.08, Kendall's Tau")
dev.off()

jpeg(file="0.time_series_acceleration-phase2.png")
plot(1:length(time_series_acceleration(new_data$Incidence,leng_window,1)),time_series_acceleration(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="time_series_acceleration")
text(10,0.2,"P=0.05, Kendall's Tau")
dev.off()

jpeg(file="0.Slopes-phase2.png")
plot(1:length(Slopes(new_data$Incidence,leng_window,1)),Slopes(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Slopes")
text(10,0.02,"P=0.42, Kendall's Tau")
dev.off()

jpeg(file="0.no_outliers-phase2.png")
plot(1:length(no_outliers(new_data$Incidence,leng_window,1)),no_outliers(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="no_outliers")
text(10,1,"P=0, Kendall's Tau")
dev.off()


jpeg(file="0.Step_changes-phase2.png")
plot(1:length(Step_changes(new_data$Incidence,leng_window,1)),Step_changes(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Step_changes")
text(10,0.2,"P=0.33, Kendall's Tau")
dev.off()


jpeg(file="0.N_peaks-phase2.png")
plot(1:length(N_peaks(new_data$Incidence,leng_window,1)),N_peaks(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="N_peaks")
text(20,0.25,"P=0.3, Kendall's Tau")
dev.off()

jpeg(file="0.Turning_Points-phase2.png")
plot(1:length(Turning_Points(new_data$Incidence,leng_window,1)),Turning_Points(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Turning_Points")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.FFT_AMP-phase2.png")
plot(1:length(FFT_AMP(new_data$Incidence,leng_window,1)),FFT_AMP(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="FFT_AMP")
text(10,1,"P=0.01, Kendall's Tau")
dev.off()

jpeg(file="0.poincare_variabilitys-phase2.png")
plot(1:length(poincare_variabilitys(new_data$Incidence,leng_window,1)),poincare_variabilitys(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="poincare_variabilitys")
text(20,1,"P=0.26, Kendall's Tau")
dev.off()


##################### testing Phase 3:
new_data=phase_3

#common EWs + P value
leng_window=10 # difine the length of time window
number=100 # fine the number of surrogates
final_results_1=rbind(c(Ebisuzaki_method(number,AR1(new_data$Incidence,leng_window,1)),"AR1"),
      c(Ebisuzaki_method(number,AR2(new_data$Incidence,leng_window,1)),"AR2"),
      c(Ebisuzaki_method(number,AR3(new_data$Incidence,leng_window,1)),"AR3"),
      c(Ebisuzaki_method(number,SD(new_data$Incidence,leng_window,1)),"SD"),
      c(Ebisuzaki_method(number,Skewness(new_data$Incidence,leng_window,1)),"Skewness"),
      c(Ebisuzaki_method(number,Kurtosis(new_data$Incidence,leng_window,1)),"Kurtosis"),
      c(Ebisuzaki_method(number,CV(new_data$Incidence,leng_window,1)),"CV"),
      c(Ebisuzaki_method(number,first_differenced_variance(new_data$Incidence,leng_window,1)),"first_differenced_variance"),
      c(Ebisuzaki_method(number,Autocovariance(new_data$Incidence,leng_window,1)),"Autocovariance"),
      c(Ebisuzaki_method(number,index_of_dispersion(new_data$Incidence,leng_window,1)),"index_of_dispersion"),
      c(Ebisuzaki_method(number,density_ratio(new_data$Incidence,leng_window,1)),"density_ratio"),
      c(Ebisuzaki_method(number,Max_eigen(new_data$Incidence,leng_window,1)),"Max_eigen"),
      #vest function
      c(Ebisuzaki_method(number,relative_dispersions(new_data$Incidence,leng_window,1)),"relative_dispersions"),
      #c(Ebisuzaki_method(number,max_lyapunov_exps(new_data$Incidence,leng_window,1)),"max_lyapunov_exps"),
      c(Ebisuzaki_method(number,Hurst_exponents(new_data$Incidence,leng_window,1)),"Hurst_exponents"),
      c(Ebisuzaki_method(number,time_series_acceleration(new_data$Incidence,leng_window,1)),"time_series_acceleration"),
      c(Ebisuzaki_method(number,Slopes(new_data$Incidence,leng_window,1)),"Slopes"),
      #c(Ebisuzaki_method(number,Daubechies_DWT(new_data$Incidence,leng_window,1)),"Daubechies_DWT"),
      c(Ebisuzaki_method(number,no_outliers(new_data$Incidence,leng_window,1)),"no_outliers"),
      c(Ebisuzaki_method(number,Step_changes(new_data$Incidence,leng_window,1)),"Step_changes"),
      c(Ebisuzaki_method(number,N_peaks(new_data$Incidence,leng_window,1)),"N_peaks"),
      c(Ebisuzaki_method(number,Turning_Points(new_data$Incidence,leng_window,1)),"Turning_Points"),
      c(Ebisuzaki_method(number,FFT_AMP(new_data$Incidence,leng_window,1)),"FFT_AMP"),
      c(Ebisuzaki_method(number,poincare_variabilitys(new_data$Incidence,leng_window,1)),"poincare_variabilitys") )

final_results_1=as.data.frame(final_results_1)
final_results_1$disease="Dengue"
final_results_1$country_region="Bolivia"
colnames(final_results_1)=c("P_value","trend","disease","country_region") #1 upward; -1 downward




###### plot EWs
jpeg(file="0.AR(1)-phase3.png")
plot(1:length(AR1(new_data$Incidence,leng_window,1)),AR1(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(1)")
text(10,0.2,"P=0.41, Kendall's Tau")
dev.off()

jpeg(file="0.AR(2)-phase3.png")
plot(1:length(AR2(new_data$Incidence,leng_window,1)),AR2(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(2)")
text(10,0.2,"P=0.28, Kendall's Tau")
dev.off()

jpeg(file="0.AR(3)-phase3.png")
plot(1:length(AR3(new_data$Incidence,leng_window,1)),AR3(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="AR(3)")
text(10,0.2,"P=0.09, Kendall's Tau")
dev.off()

jpeg(file="0.SD-phase3.png")
plot(1:length(SD(new_data$Incidence,leng_window,1)),SD(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="SD")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Skewness-phase3.png")
plot(1:length(Skewness(new_data$Incidence,leng_window,1)),Skewness(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Skewness")
text(10,0.2,"P=0.19, Kendall's Tau")
dev.off()

final_results_1
jpeg(file="0.Kurtosis-phase3.png")
plot(1:length(Kurtosis(new_data$Incidence,leng_window,1)),Kurtosis(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Kurtosis")
text(10,0.2,"P=0.19, Kendall's Tau")
dev.off()

jpeg(file="0.CV-phase3.png")
plot(1:length(CV(new_data$Incidence,leng_window,1)),CV(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="CV")
text(10,0.8,"P=0.01, Kendall's Tau")
dev.off()

jpeg(file="0.first_differenced_variance-phase3.png")
plot(1:length(first_differenced_variance(new_data$Incidence,leng_window,1)),first_differenced_variance(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="first_differenced_variance")
text(10,10,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Autocovariance-phase3.png")
plot(1:length(Autocovariance(new_data$Incidence,leng_window,1)),Autocovariance(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Autocovariance")
text(10,5,"P=0.11, Kendall's Tau")
dev.off()


jpeg(file="0.index_of_dispersion-phase3.png")
plot(1:length(index_of_dispersion(new_data$Incidence,leng_window,1)),index_of_dispersion(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="index_of_dispersion")
text(10,2,"P=0.19, Kendall's Tau")
dev.off()

jpeg(file="0.density_ratio-phase3.png")
plot(1:length(density_ratio(new_data$Incidence,leng_window,1)),density_ratio(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="density_ratio")
text(10,0.2,"P=0.01, Kendall's Tau")
dev.off()

jpeg(file="0.Max_eigen-phase3.png")
plot(1:length(Max_eigen(new_data$Incidence,leng_window,1)),Max_eigen(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Max_eigen")
text(10,0.2,"P=0.2, Kendall's Tau")
dev.off()

#vest function
jpeg(file="0.relative_dispersions-phase3.png")
plot(1:length(relative_dispersions(new_data$Incidence,leng_window,1)),relative_dispersions(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="relative_dispersions")
text(10,0.7,"P=0.05, Kendall's Tau")
dev.off()

jpeg(file="0.Hurst_exponents-phase3.png")
plot(1:length(Hurst_exponents(new_data$Incidence,leng_window,1)),Hurst_exponents(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Hurst_exponents")
text(10,-0.4,"P=0.03, Kendall's Tau")
dev.off()

jpeg(file="0.time_series_acceleration-phase3.png")
plot(1:length(time_series_acceleration(new_data$Incidence,leng_window,1)),time_series_acceleration(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="time_series_acceleration")
text(10,0.2,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Slopes-phase3.png")
plot(1:length(Slopes(new_data$Incidence,leng_window,1)),Slopes(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Slopes")
text(10,0.02,"P=0.2, Kendall's Tau")
dev.off()

jpeg(file="0.no_outliers-phase3.png")
plot(1:length(no_outliers(new_data$Incidence,leng_window,1)),no_outliers(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="no_outliers")
text(10,1,"P=0.06, Kendall's Tau")
dev.off()


jpeg(file="0.Step_changes-phase3.png")
plot(1:length(Step_changes(new_data$Incidence,leng_window,1)),Step_changes(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Step_changes")
text(10,0.2,"P=0.29, Kendall's Tau")
dev.off()


jpeg(file="0.N_peaks-phase3.png")
plot(1:length(N_peaks(new_data$Incidence,leng_window,1)),N_peaks(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="N_peaks")
text(10,0.25,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.Turning_Points-phase3.png")
plot(1:length(Turning_Points(new_data$Incidence,leng_window,1)),Turning_Points(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="Turning_Points")
text(10,0.2,"P=0.11, Kendall's Tau")
dev.off()

jpeg(file="0.FFT_AMP-phase3.png")
plot(1:length(FFT_AMP(new_data$Incidence,leng_window,1)),FFT_AMP(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="FFT_AMP")
text(10,1,"P=0, Kendall's Tau")
dev.off()

jpeg(file="0.poincare_variabilitys-phase3.png")
plot(1:length(poincare_variabilitys(new_data$Incidence,leng_window,1)),poincare_variabilitys(new_data$Incidence,leng_window,1), 
     type="l",col="blue",lwd=0.5, xlab="time", ylab="poincare_variabilitys")
text(10,1,"P=0.28, Kendall's Tau")
dev.off()
