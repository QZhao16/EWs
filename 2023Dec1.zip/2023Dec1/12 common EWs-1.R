############## Part 1. AR(1)
#1.0
AR1 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    AR_1<-function(x){
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series and its lagged version
      deviations <- x - mean_ts
      lagged_deviations <- c(NA, deviations[-length(deviations)])
      # Compute the AR(1) coefficient
      ar1_coefficient <- sum(deviations * lagged_deviations, na.rm = TRUE) / sum(deviations^2)
      return(ar1_coefficient)
    } # end AR1 function
    
    Ews <- c(Ews, AR_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
AR1(time_series_data)

############## Part 2. AR(2)
AR2 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    AR_2<-function(x){
      #set.seed(1)
      #time_series_data <- ts(rnorm(100))
      # Compute the mean of the time series
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series and its lagged versions
      deviations <- x - mean_ts
      lagged_deviations_1 <- c(NA, deviations[-length(deviations)])
      lagged_deviations_2 <- c(NA, NA, deviations[-(length(deviations)-1)])
      # Remove the NA in the data
      data <- x[!is.na(lagged_deviations_2)]
      lagged_deviations_1 <- lagged_deviations_1[!is.na(lagged_deviations_2)]
      lagged_deviations_2 <- lagged_deviations_2[!is.na(lagged_deviations_2)]
      # Fit an AR(2) model using lm function
      model <- lm(data ~ lagged_deviations_1 + lagged_deviations_2)
      # Print the model to get the AR(2) coefficients
      return(model$coefficients[[3]])
    }    #end AR2 function
    
    Ews <- c(Ews, AR_2(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
AR2(time_series_data)



############## Part 3. AR(3)
AR3 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    AR_3<-function(x){
      # Compute the mean of the time series
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series and its lagged versions
      deviations <- x - mean_ts
      lagged_deviations_1 <- c(NA, deviations[-length(deviations)])
      lagged_deviations_2 <- c(NA, NA, deviations[-(length(deviations)-1)])
      lagged_deviations_3 <- c(NA, NA, NA, deviations[-(length(deviations)-2)])
      # Remove the NA in the data
      data <- x[!is.na(lagged_deviations_3)]
      lagged_deviations_1 <- lagged_deviations_1[!is.na(lagged_deviations_3)]
      lagged_deviations_2 <- lagged_deviations_2[!is.na(lagged_deviations_3)]
      lagged_deviations_3 <- lagged_deviations_3[!is.na(lagged_deviations_3)]
      # Fit an AR(3) model using lm function
      model <- lm(data ~ lagged_deviations_1 + lagged_deviations_2 + lagged_deviations_3)
      # Print the model to get the AR(3) coefficients
      return(model$coefficients[[4]])
    }    #end AR3 function  
    
    Ews <- c(Ews, AR_3(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
AR3(time_series_data)



############## Part 4. SD
SD <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    SD1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the mean of the squared deviations
      mean_squared_deviations <- mean(squared_deviations)
      # Compute the standard deviation as the square root of the mean of the squared deviations
      sd <- sqrt(mean_squared_deviations)
      # Print the standard deviation
      return(sd)
    }    #end SD function
    
    Ews <- c(Ews, SD1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
SD(time_series_data)



############## Part 5. Skewness
Skewness <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Skewness_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the cubed deviations
      cubed_deviations <- deviations^3
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the skewness as the mean of the cubed deviations divided by the square root of the cube of the mean of the squared deviations
      skewness <- mean(cubed_deviations) / sqrt(mean(squared_deviations)^3)
      # Print the skewness
      return(skewness)
    }    #end Skewness function
    
    Ews <- c(Ews, Skewness_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Skewness(time_series_data)


############## Part 6. Kurtosis
Kurtosis <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Kurtosis_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the cubed deviations
      cubed_deviations <- deviations^3
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the skewness as the mean of the cubed deviations divided by the square root of the cube of the mean of the squared deviations
      skewness <- mean(cubed_deviations) / sqrt(mean(squared_deviations)^3)
      # Print the skewness
      return(skewness)
    }    #end Kurtosis function
    
    Ews <- c(Ews, Kurtosis_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Kurtosis(time_series_data)



############## Part 7. coefficient of variation (CV)
CV <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    CV_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the standard deviation as the square root of the mean of the squared deviations
      sd <- sqrt(mean(squared_deviations))
      # Compute the CV as the ratio of the standard deviation to the mean
      cv <- sd / mean_data
      # Print the CV
      return(cv)
    }    #end CV
    
    Ews <- c(Ews, CV_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
CV(time_series_data)



############## Part 8. first_differenced_variance
first_differenced_variance <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    first_differenced_variance_1<-function(x){
      # Compute the first differences of the time series
      first_differences <- diff(x)
      # Compute the mean of the first differences
      mean_diff <- mean(first_differences)
      # Compute the deviations from the mean for the first differences
      deviations <- first_differences - mean_diff
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the first-differenced variance as the mean of the squared deviations
      first_diff_variance <- mean(squared_deviations)
      # Print the first-differenced variance
      return(first_diff_variance)
    }    #end first_diff_variance
    
    Ews <- c(Ews, first_differenced_variance_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
first_differenced_variance(time_series_data)


############## Part 9. Autocovariance
Autocovariance <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Autocovariance_1<-function(x){
      mean_ts <- mean(x)
      # Compute the deviations from the mean for the time series
      deviations <- x - mean_ts
      # Compute the lagged deviations
      lagged_deviations <- c(NA, deviations[-length(deviations)])
      # Compute the autocovariance as the mean of the product of the deviations and the lagged deviations
      autocovariance <- mean(deviations * lagged_deviations, na.rm = TRUE)
      # Print the autocovariance
      return(autocovariance)
    }    #end autocovariance
    
    Ews <- c(Ews, Autocovariance_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Autocovariance(time_series_data)



############## Part 10. The index of dispersion
# a measure of statistical dispersion. defined as the ratio of the variance to the mean
index_of_dispersion <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    index_of_dispersion_1<-function(x){
      # Compute the mean of the data
      mean_data <- mean(x)
      # Compute the deviations from the mean
      deviations <- x - mean_data
      # Compute the squared deviations
      squared_deviations <- deviations^2
      # Compute the variance as the mean of the squared deviations
      variance <- mean(squared_deviations)
      # Compute the index of dispersion as the ratio of the variance to the mean
      index_of_dispersion <- variance / mean_data
      # Print the index of dispersion
      return(index_of_dispersion)
    }    #end index_of_dispersion
    
    Ews <- c(Ews, index_of_dispersion_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
index_of_dispersion(time_series_data)


############## Part 11. density_ratio
density_ratio <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    density_ratio_1<-function(x){
      # Compute the Fast Fourier Transform of the time series data
      fft_data <- fft(x)
      # Compute the spectral density
      spectral_density <- Mod(fft_data)^2
      # Define the low and high frequency ranges
      # These ranges might need to be adjusted depending on your specific needs
      #low_frequency_range <- 2:10
      #high_frequency_range <- 11:20
      # Compute the spectral density at low and high frequencies
      #spectral_density_low <- mean(spectral_density[low_frequency_range])
      #spectral_density_high <- mean(spectral_density[high_frequency_range])
      #by me
      low_frequency_range <-sort(spectral_density)[1:floor(length(spectral_density)/2)]
      high_frequency_range <-sort(spectral_density)[(floor(length(spectral_density)/2)+1):length(spectral_density)]
      # Compute the spectral density at low and high frequencies
      spectral_density_low <- mean(low_frequency_range)
      spectral_density_high <- mean(high_frequency_range)
      # end by me
      # Compute the density ratio as the ratio of the spectral density at low frequency to the spectral density at high frequency
      density_ratio <- spectral_density_low / spectral_density_high
      # Print the density ratio
      return(density_ratio)
    } # end density_ratio
    
    Ews <- c(Ews, density_ratio_1(inciddences[(j-window_size+1):j]) )    
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
density_ratio(time_series_data)


############## Part 12. dominant eigen value
Max_eigen <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=dataset                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    Max_eigen_1 <- function(x){
      library("rEDM")
      library("sapa")
      
      tau <- 1
      theta <- seq(0,10,by=0.5)
      time_series <- (x - mean(x, na.rm=TRUE))/sd(x, na.rm=TRUE)#stadardize data
      #simplex to find E
      sim_r <- simplex(time_series,lib=c(1,floor(length(time_series)/2)),pred=c(floor(length(time_series)/2)+1,length(time_series)),E=c(1:sqrt(length(time_series))))
      E <-sim_r[which.min(sim_r$mae),"E"][1] 
      #E <-sim_r[which.max(sim_r$rho),"E"][1]
      
      # calculate best theta
      smap <- s_map(time_series, E=E, tau=tau, theta=theta, silent=TRUE)
      best <- order(-smap$rho)[1]
      theta_best <- smap[best,]$theta
      # calculate eigenvalues for best theta
      smap <- s_map(time_series, E=E, tau=tau, theta=theta_best, silent=TRUE, save_smap_coefficients=TRUE)
      smap_co <- smap$smap_coefficients[[1]]
      matrix_eigen <- matrix(NA, nrow = NROW(smap_co), ncol = 3)
      for(k in 1:NROW(smap_co)){
        if(!is.na(smap_co[k,1]))
        {
          M <- rbind(as.numeric(smap_co[k, 1:E]), cbind(diag(E - 1), rep(0, E - 1)))
          M_eigen <- eigen(M)$values
          lambda1 <- M_eigen[order(abs(M_eigen))[E]]
          
          matrix_eigen[k,1] <- abs(lambda1)
          matrix_eigen[k,2] <- Re(lambda1)
          matrix_eigen[k,3] <- Im(lambda1)
        }
      }
      
      return(mean(matrix_eigen[,1], na.rm=TRUE))
    } # end Max_eigen
    
    Ews <- c(Ews, Max_eigen_1(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}

# example
set.seed(1)
time_series_data <- rnorm(100)
Max_eigen(time_series_data)





