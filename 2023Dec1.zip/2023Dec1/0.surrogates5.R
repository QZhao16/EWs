
############# method 1, Fourier-transformed data 
#Transforming the original time series data to the frequency domain using the Fourier transform.
#Randomizing the phases of the Fourier-transformed data.
#Transforming back to the time domain to obtain a surrogate time series.
#Repeating steps 1-3 multiple times to generate a distribution of surrogate datasets.
#Comparing the statistic of interest (e.g., the Kendall rank correlation) calculated on the original data to the distribution obtained from the surrogate datasets.


Fourier_method<-function(number_surrogate, original_data) {
  library(tseries)
# Function to generate a surrogate dataset
generate_surrogate <- function(data) {
  n <- length(data)
  fft_data <- fft(data)
  # Generate random phases
  random_phases <- exp(1i * runif(n/2 - 1, -pi, pi))
  # Apply random phases
  fft_data[2:(n/2)] <- fft_data[2:(n/2)] * random_phases
  fft_data[(n/2 + 2):n] <- Conj(fft_data[2:(n/2)])
  # Inverse Fourier transform to get surrogate data
  surrogate_data <- Re(fft(fft_data, inverse = TRUE) / n)
  return(surrogate_data)
}

# Generate number of surrogate datasets
surrogate_stats <- numeric(number_surrogate)
set.seed(2)
for (i in 1:number_surrogate) {
  surrogate_data <- generate_surrogate(original_data)
  surrogate_stats[i] <- cor.test(1:length(surrogate_data), surrogate_data, method = "kendall")$estimate
}

# Calculate the Kendall rank correlation on the original data
original_stat <- cor.test(1:length(original_data), original_data, method = "kendall")$estimate

# Calculate the p-value
if(original_stat>=0) {p_value <- sum(surrogate_stats >= original_stat) / number_surrogate}
if(original_stat<0) {p_value <- sum(surrogate_stats <= original_stat) / number_surrogate}

return ( c(p_value, original_stat/abs(original_stat)) )

}  


# example
set.seed(123)
original_data <- arima.sim(model = list(ar = 0.9), n = 50) # Generate some example time series data
plot(original_data, col="red", type="o")
num_surrogates <- 100 # number of surrogates

Fourier_method(number_surrogate=number_surrogate, original_data=original_data)

#[1] 0.11 1.00 # 0.11 is p value; 1.00 means upward (-1 means downward)
#thus, insignificant upward.



############# method 2, Ebisuzaki (1997), Generate phase-randomized surrogate series as in Ebisuzaki (1997)

Ebisuzaki_method<-function(number_surrogate, original_data) {

original_data=original_data[!(is.na(original_data))] #NA remove
library(astrochron)
surrogates <- as.data.frame( matrix(nrow=length(original_data)), ncol= number_surrogate)
set.seed(2)
for (i in 1:number_surrogate) {
  surrogates[,i] <- surrogates(original_data, nsim=1, preserveMean=T, std=T, genplot=F, verbose=F)
}

#number_surrogate:Number of phase-randomized surrogate series to generate.
#preserveMean:Should surrogate series have the same mean value as data series? (T or F)
#std:Standardize results to guarantee equivalent variance as data series? (T or F)
#genplot:Generate summary plots? Only applies if nsim=1. (T or F)
#verbose:Verbose output? (T or F)

# calculate Kendall's tau for the original data
tau_original <- cor(1:length(original_data),original_data, method="kendall")
# calculate Kendall's tau for each surrogate
tau_surrogates <- apply(surrogates, 2, function(x) cor(1:length(original_data), x, method="kendall"))
# calculate p-value

if(tau_original>=0) {p_value <- sum(tau_surrogates >= tau_original) / number_surrogate}
if(tau_original<0) {p_value <- sum(tau_surrogates <= tau_original) / number_surrogate}

return ( c(p_value, tau_original/abs(tau_original)) )
}



#example data
set.seed(123)
original_data <- rnorm(1000)
plot(original_data, col="red", type="o")
number_surrogate <- 100

Ebisuzaki_method(number_surrogate=number_surrogate, original_data=original_data)

#[1] 0.32 1.00 # 0.32 is p value; 1.00 means upward (-1 means downward)
#thus, insignificant upward.
