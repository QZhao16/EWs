# Part 1,relative_dispersion
#### function: compute a Earlier warming signal (e.g. relative_dispersion) in Vest R package
EWs_ml_1 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "relative_dispersion" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    relative_dispersion <-
      function(x) {
        sd(x) / sd(diff(x)[-1])
      }  # end of the "relative_dispersion" function
    
    Ews <- c(Ews, relative_dispersion(inciddences[(j-window_size+1):j]) )   #compute the "relative_dispersion" for each rolling window
  }
  return(Ews)
}



# Part 2,max_lyapunov_exp
#### function: compute a Earlier warming signal (e.g. max_lyapunov_exp) in Vest R package
EWs_ml_2 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "max_lyapunov_exp" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    max_lyapunov_exp <-
      function(x) {
        library(nonlinearTseries) 
        len <- length(x)
        Reduce(max,
               nonlinearTseries::divergence(
                 nonlinearTseries::maxLyapunov(
                   time.series = x,
                   min.embedding.dim = 1,
                   max.embedding.dim = len,
                   radius = ceiling(sqrt(len)),
                   do.plot = FALSE
                 )
               ))
      }  # end of the "max_lyapunov_exp" function
    
    Ews <- c(Ews, max_lyapunov_exp(inciddences[(j-window_size+1):j]) )   #compute the "max_lyapunov_exp" for each rolling window
  }
  return(Ews)
}

# Part 3, Hurst exponent
#### function: compute a Earlier warming signal (e.g. Hurst exponent) in Vest R package
EWs_ml_3 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Hurst exponent" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    HURST <-
      function(x, nmoments=1) {
        library(Rwave)
        
        cwtwnoise <- DOG(x, 10, 5, nmoments, plot = FALSE)
        mcwtwnoise <- Mod(cwtwnoise)
        mcwtwnoise <- mcwtwnoise * mcwtwnoise
        wspwnoise <- tfmean(mcwtwnoise, plot = FALSE)
        
        hurst.est(wspwnoise, 1:5, 5, plot = FALSE)[[2]]
      }  # end of the "Hurst exponent" function
    
    Ews <- c(Ews, HURST(inciddences[(j-window_size+1):j]) )   #compute the "Hurst exponent" for each rolling window
  }
  return(Ews)
}


# Part 4, time series acceleration
#### function: compute a Earlier warming signal (e.g. time series acceleration) in Vest R package
EWs_ml_4 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "time series acceleration" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    accelaration <-
      function(x) {
        #require(TTR)
        
        if (length(x) > 10) {
          n <- 5
        }
        else {
          n <- 3
        }
        
        if (length(x) < 4) {
          return(
            c(avg_accl=NA,
              sdev_accl=NA)
          )
        }
        
        ts_sma <- TTR::SMA(x, n = n)
        ts_ema <- TTR::EMA(x, n = n)
        
        ts_sma <- ts_sma[!is.na(ts_sma)]
        ts_ema <- ts_ema[!is.na(ts_ema)]
        
        sema <- ts_sma / ts_ema
        sema <- sema[!(is.infinite(sema) | is.na(sema))]
        
        accl_ <- ts_sma / ts_ema
        
        c(avg_accl=mean(accl_),
          sdev_accl=stats::sd(accl_))
      }  # end of the "accelaration" function
    
    Ews <- c(Ews, accelaration(inciddences[(j-window_size+1):j]) )   #compute the "time series acceleration" for each rolling window
  }
  return(Ews)
}



# Part 5, Slope
#### function: compute a Earlier warming signal (e.g. Slope) in Vest R package
EWs_ml_5 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Slope" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    slope <-
      function(x) {
        time_x <- seq_along(x)
        lmfit <- lm(x ~ time_x)
        
        lmfit$coefficients[[2]]
      }  # end of the "Slope" function
    
    Ews <- c(Ews, slope(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 6, Daubechies DWT
#### function: compute a Earlier warming signal (e.g. Daubechies DWT) in Vest R package
EWs_ml_6 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    #library(Rssa)
    #library(chronosphere)
    #library(remotes)
    #library(wavelets)
    
    #install.packages("wmtsa", repos="http://R-Forge.R-project.org")
    library(wmtsa)

    # load the "Daubechies DWT" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    dauDWTenergy <-
      function(x, lvl=4) {
        
        r <-tryCatch(wavDWT(x, wavelet="s8", n.levels=lvl),
                   error = function(e) {
                     NA
                   })
        
        if (is.na(r)) {
          dummy_ed <- rep(NA, times=lvl)
          names(dummy_ed) <- paste0("Ed",1:lvl)
          
          return(c(E_ra5=NA,dummy_ed))
        }
        
        dwt_result <- r$data
        
        E_a5 <- reconstruct(r) # reconstruct(r) is to re-achive the r
        E_a5 <- norm(t(E_a5))
        
        E_dk <- sapply(dwt_result[1:lvl], function(x) norm(t(x)))
        names(E_dk) <- paste0("Ed", 1:length(E_dk))
        
        E_T <- E_a5 + sum(E_dk)
        
        E_ra5 <- E_a5 / E_T
        
        E_rdk <- E_dk / E_T
        
        c(E_ra5=E_ra5,E_rdk)
      }  # end of the "Daubechies DWT" function
    
    Ews <- c(Ews, dauDWTenergy(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 7, no outliers
#### function: compute a Earlier warming signal (e.g. no outliers) in Vest R package
EWs_ml_7 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "no outliers" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    nout2 <-
      function(x) {
        detr <- diff(x)
        
        sum(abs(detr) > 1.5*IQR(detr))
      }  # end of the "no outliers" function
    
    Ews <- c(Ews, nout2(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 8, Step change
#### function: compute a Earlier warming signal (e.g. Step change) in Vest R package
EWs_ml_8 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Step change" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    step_change <-
      function(x) {
        lko <- x[length(x)]
        rv <- x[-length(x)]
        
        has_s_c <- abs(lko - mean(rv)) > 2*sd(rv)
        
        as.integer(has_s_c)
      }  # end of the "Step change" function
    
    Ews <- c(Ews, step_change(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}



# Part 9, N peaks
#### function: compute a Earlier warming signal (e.g. N peaks) in Vest R package
EWs_ml_9 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "N peaks" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    npeaks <-
      function(x) {
        nincr <- sum(diff(sign(diff(x)))==-2)
        ndecr <- sum(diff(sign(diff(x)))==2)
        l <- length(x)
        
        c(ndecr=ndecr/l, nincr=nincr/l)
      }  # end of the "N peaks" function
    
    Ews <- c(Ews, npeaks(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 10, Turning Points
#### function: compute a Earlier warming signal (e.g. Turning Points) in Vest R package
EWs_ml_10 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Turning Points" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    tpoints <-
      function(x) {
        dx <- diff(x)
        sum(sign(dx))
      }  # end of the "Turning Points" function
    
    Ews <- c(Ews, tpoints(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 11, Convert FFT
#### function: compute a Earlier warming signal (e.g. Convert FFT) in Vest R package
EWs_ml_11 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Convert FFT" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    convert.fft <-
      function(cs) {
        sample.rate = 1
        
        cs <- cs / length(cs) # normalize
        
        distance.center <- function(c)
          signif(Mod(c),        4)
        angle           <- function(c)
          signif(180 * Arg(c) / pi, 3)
        
        df <- data.frame(
          cycle    = 0:(length(cs) - 1),
          freq     = 0:(length(cs) - 1) * sample.rate / length(cs),
          strength = sapply(cs, distance.center),
          delay    = sapply(cs, angle)
        )
        df
      }  # end of the "Convert FFT" function
    
    Ews <- c(Ews, convert.fft(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 12, FFT AMP
#### function: compute a Earlier warming signal (e.g. FFT AMP) in Vest R package
EWs_ml_12 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "FFT AMP" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    fft_strength <-
      function(x) {
        dx <- diff(x)
        fft_data <- convert.fft(stats::fft(dx))
        
        mean(fft_data[,"strength"])
      } # end of the "FFT AMP" function
    
    Ews <- c(Ews, fft_strength(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}


# Part 13, Poincare variability
#### function: compute a Earlier warming signal (e.g. Poincare variability) in Vest R package
EWs_ml_13 <- function (dataset=original_data, window_size=50, steps=1){ #the width of rolling window is 50.
  inciddences=original_data                                           # only use the Incidence
  window_indices <- seq(window_size, NROW(dataset), steps)            #cutting data into rolling windows
  #
  Ews <-NULL
  for(j in window_indices) {
    
    # load the "Poincare variability" in  in Vest R package, link: https://github.com/vcerqueira/vest/blob/master/R/statistics.r
    poincare_variability <-
      function(x) {
        sd1 = sd(diff(x))/sqrt(2)
        sd2 = sqrt(2 * var(x) - sd1^2)
        
        c(sd1=sd1,sd2=sd2)
      } # end of the "Poincare variability" function
    
    Ews <- c(Ews, poincare_variability(inciddences[(j-window_size+1):j]) )   
  }
  return(Ews)
}
