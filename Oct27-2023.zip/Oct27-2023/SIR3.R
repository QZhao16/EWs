

setwd("C:/zhao088/Ondrive Wang/OneDrive/Desktop/SIR model simu/R code")
getwd()

#############  SIR model:  no noise

library(deSolve)
library(ggplot2)
library(gridExtra)

SIR_noNoise<- function(running_times) {
  
  my_list <- list()
  
  for (j in 1:running_times){
    
    set.seed(2)
    beta_min <- runif(running_times, min = 0.05, max = 0.1)[j]
    set.seed(2)
    beta_max <- runif(running_times, min = 0.5, max = 5)[j]
    
# Define the ODE system
sir_ode <- function(t, state, parameters, beta_min, beta_max) {
  with(as.list(c(state, parameters)), {
    
    beta_t <- beta_min + (beta_max - beta_min) / (1 + exp(-k * (t - t_mid)))
    
    dS <- -beta_t * S * I / N
    dI <- beta_t * S * I / N - gamma * I
    dR <- gamma * I
    
    return(list(c(dS, dI, dR)))
  })
}

# Initial state values
init <- c(S = 990, I = 10, R = 0)

# Parameters
parameters <- c(k = 0.1, 
                t_mid = 100, 
                gamma = 0.1, 
                N = 1000)

# Time sequence
times <- seq(0, 200, by = 1)

# Solve the ODE system
out <- ode(y = init, times = times, func = sir_ode, parms = parameters, beta_min=beta_min, beta_max=beta_max)
out <- as.data.frame(out)

# Calculate Re over time
#out$Re <- with(out, (beta_min + (beta_max - beta_min) / (1 + exp(-k * (time - t_mid)))) * S / (gamma * N))
#out$Re <- with(out, (parameters['beta_min'] + (parameters['beta_max'] - parameters['beta_min']) / (1 + exp(-parameters['k'] * (time - parameters['t_mid'])))) * S / (parameters['gamma'] * parameters['N']))
out$Re <- with(out, (beta_min + (beta_max - beta_min) / (1 + exp(-parameters['k'] * (time - parameters['t_mid'])))) * S / (parameters['gamma'] * parameters['N']))


#
my_list[[j]]=out
out=NULL

  } # for loop
  
  return(my_list)
}

results_3=SIR_noNoise(running_times=1000)
save(results_3, file = "SIR_noNoise1000.RData")




# Plotting
p1 <- ggplot(data = results_3[[1000]], aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "Deterministic SIR Model with Time-Varying Beta",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))

p2 <- ggplot(data = results_3[[1000]], aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number (Re) over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

# Display plots
grid.arrange(p1, p2, ncol = 1)






############################### SIR model: white noise
library(deSolve)
library(ggplot2)
library(gridExtra)


SIR_Noise<- function(running_times) {
  
  my_list <- list()
  
  for (j in 1:running_times){
    
    set.seed(2)
    beta_min <- runif(running_times, min = 0.05, max = 0.1)[j]
    set.seed(2)
    beta_max <- runif(running_times, min = 0.5, max = 5)[j]
    
    
# Define the ODE system with time-varying beta and noise in I
SIR_noise <- function(t, state, parameters, delta_t, noise, beta_min, beta_max) {
  
  # Unpack state variables
  S = state[1]
  I = state[2]
  R = state[3]
  
  # Unpack parameters 
  k = parameters['k']
  t_mid = parameters['t_mid']
  gamma = parameters['gamma']
  sigma_x = parameters['sigma_x']
  N = parameters['N']
  
  beta_t <- beta_min + (beta_max - beta_min) / (1 + exp(-k * (t - t_mid)))
  
  dS <- (-beta_t * S * I / N) * delta_t
  dI <- (beta_t * S * I / N - gamma * I) * delta_t + sigma_x * rnorm(1, mean = 0, sd = sqrt(noise))
  dR <- (gamma * I) * delta_t
  
  new_S = max(S + dS, 0)
  new_I = max(I + dI, 0)
  new_R = max(R + dR, 0)
  
  return(c(new_S, new_I, new_R))
}

# Initial state values
init <- c(S = 990, I = 10, R = 0)

# Parameters
parameters <- c(k = 0.1, 
                t_mid = 100, 
                gamma = 0.1, 
                N = 1000, 
                sigma_x = 1)

# Time sequence
times <- seq(0, 200, by = 1)
delta_t = times[2] - times[1]

# Simulate using Euler method with noise for I
result = as.data.frame(matrix(0, length(times), 3))
colnames(result) = c("S", "I", "R")
result[1,] = init
noise = 1

set.seed(2)
for (i in 2:length(times)) {
  result[i,] = SIR_noise(times[i], result[i-1,], parameters, delta_t, noise,beta_min, beta_max)
}

result$time = times

# Calculate Re over time
result$Re <- with(result, (beta_min + (beta_max - beta_min) / (1 + exp(-parameters['k'] * (time - parameters['t_mid'])))) * S / (parameters['gamma'] * parameters['N']))



#
my_list[[j]]=result
result=NULL

  } # for loop
  
  return(my_list)
}

results_4=SIR_Noise(running_times=1000)
save(results_4, file = "SIR_Noise1000.RData")




# Plot the SIR model outputs
p1 <- ggplot(data = results_4[[1000]], aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "SIR Model with Time-Varying Beta and Noisy I",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))

# Plot Re over time
p2 <- ggplot(data = results_4[[1000]], aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

# Display plots
grid.arrange(p1, p2, ncol = 1)





