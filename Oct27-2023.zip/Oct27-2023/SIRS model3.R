setwd("C:/zhao088/Ondrive Wang/OneDrive/Desktop/SIR model simu/R code")


################  Part 2,  no noise
library(deSolve)
library(ggplot2)
library(gridExtra)


SIRS_noNoises<- function(running_times) {
  
  my_list <- list()
  
  for (j in 1:running_times){
    
    set.seed(2)
    beta_max <- runif(running_times, min = 2, max = 8)[j]
    set.seed(2)
    sigma <- runif(running_times, min = 2, max = 8)[j]
    
# Define the model
sirs_model <- function(time, state, parameters,beta_max,sigma) {
  with(as.list(c(state, parameters)), {
    
    beta <- beta_max * exp(-((time - t_peak)^2) / (2*sigma^2))
    
    N <- S + I + R  # total population size
    dS <- -beta * S * I / N + gamma * R
    dI <- beta * S * I / N - alpha * I
    dR <- alpha * I - gamma * R
    #Re <- beta / alpha * S / N  # compute Re
    return(list(c(dS, dI, dR)))
  })
}

# Initial conditions
initial_state_values <- c(S = 990, I = 10, R = 0)

# Parameters
parameters <- c(
                #beta_max = 5,    #2,  # Maximum value of beta
                t_peak = 100,    #100,    # Time at which beta reaches its maximum
                #sigma = 10,      # Controls the width of the Gaussian peak
                alpha = 0.1,     # Recovery rate
                gamma = 0.05     #0.05
)   # Rate at which recovered individuals lose immunity

times <- seq(0, 200, by = 1)

# Solve the differential equations
out <- ode(y = initial_state_values, times = times, func = sirs_model, parms = parameters,beta_max=beta_max,sigma=sigma)
# Convert output to data.frame
out <- as.data.frame(out)
# Re
out$Re <- with(out,  beta_max * exp(-((time - parameters['t_peak'])^2) / (2 * sigma^2))* S / (parameters['alpha'] * apply(out[2:4],1, sum)) )


#
my_list[[j]]=out
out=NULL

  } # for loop
  
  return(my_list)
}

results_5=SIRS_noNoises(running_times=1000)
save(results_5, file = "SIRS_noNoise1000.RData")




# Plotting
p1 <- ggplot(data =results_5[[1000]], aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "Deterministic SIR Model with Time-Varying Beta",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))

p2 <- ggplot(data = results_5[[1000]], aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number (Re) over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

# Display plots
grid.arrange(p1, p2, ncol = 1)






################ Part 2, white noise
library(deSolve)
library(ggplot2)
library(gridExtra)

SIRS_Noises<- function(running_times) {
  
  my_list <- list()
  
  for (j in 1:running_times){
    
    set.seed(2)
    beta_max <- runif(running_times, min = 2, max = 8)[j]
    set.seed(2)
    sigma <- runif(running_times, min = 2, max = 8)[j]
    
    
# Define the model
SIRS_noise <- function(time, state, parameters, delta_t, noise, beta_max, sigma) {

  # Unpack state variables
  S = state[1]
  I = state[2]
  R = state[3]
  N <- S + I + R  # total population size
  
  # Unpack parameters 
  #beta_max = parameters['beta_max']
  t_peak = parameters['t_peak']
  #sigma = parameters['sigma']
  gamma = parameters['gamma']
  alpha = parameters['alpha']
  sigma_x = parameters['sigma_x']
  
    #beta <- beta_max * exp(-((time - t_peak)^2) / (2 * sigma^2))
    beta <- beta_max * exp(-((time - t_peak)^2) / (2*sigma^2))
    

    dS <- (-beta * S * I / N + gamma * R) * delta_t
    dI <- (beta * S * I / N - alpha * I) * delta_t + sigma_x * rnorm(1, mean = 0, sd = sqrt(noise))
    dR <- (alpha * I - gamma * R) * delta_t
    
    new_S = max(S + dS, 0)
    new_I = max(I + dI, 0)
    new_R = max(R + dR, 0)
    
    return(c(new_S, new_I, new_R))

}

# Initial conditions
init <- c(S = 990, I = 10, R = 0)

# Parameters
parameters <- c(
                #beta_max = 1, #2,  # Maximum value of beta
                t_peak = 100, #100,    # Time at which beta reaches its maximum
                #sigma = 2,    #10,     # Controls the width of the Gaussian peak
                alpha = 0.1,  #Recovery rate
                gamma = 0.05, #0.05
                sigma_x=1
)   # Rate at which recovered individuals lose immunity

# Time sequence
times <- seq(0, 200, by = 1)
delta_t = times[2] - times[1]


# Simulate using Euler method with noise for I
result = as.data.frame(matrix(0, length(times), 3))
colnames(result) = c("S", "I", "R")
result[1,] = init
noise = 1

set.seed(2)
for (i in 2:length(times)) {
  result[i,] = SIRS_noise(time=times[i], state=result[i-1,], parameters=parameters, delta_t=delta_t, noise=noise, beta_max, sigma)
}

result$time = times

# Calculate Re over time
result$Re <- with(result, beta_max * exp(-((time - parameters['t_peak'])^2) / (2 * sigma^2))* S / (parameters['alpha'] * apply(result[1:3],1, sum)) )


#
my_list[[j]]=result
result=NULL

  } # for loop
  
  return(my_list)
}

results_6=SIRS_Noises(running_times=1000)
save(results_6, file = "SIRS_Noise1000.RData")





# Plotting
p1 <- ggplot(data =results_6[[1000]], aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "Deterministic SIR Model with Time-Varying Beta",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))

p2 <- ggplot(data = results_6[[1000]], aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number (Re) over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

# Display plots
grid.arrange(p1, p2, ncol = 1)




