
setwd("C:/zhao088/Ondrive Wang/OneDrive/Desktop/SIR model simu/R code")

################################################
######### Part 4: time-varying beta ########## absolute abundance, no noise
################################################



  
  library(ggplot2)
  library(deSolve)
  library(gridExtra)
  



SEIR_noNoise<- function(running_times) {
  
  my_list <- list()
  
for (j in 1:running_times){
  
# SEIR model differential equations
seir_model <- function(time, state, parameters) {
  with(as.list(c(state, parameters)), {
    # Define a function for beta as a time-varying parameter
    beta <- beta_function(time)
    
    dS <- -beta * S * I
    dE <- beta * S * I - sigma * E
    dI <- sigma * E - gamma * I
    dR <- gamma * I
    return(list(c(dS, dE, dI, dR)))
  })
}

#beta_function
turning_point=100;minimum_1=0.0005
set.seed(2)
minimum_2 <- runif(running_times, min = 0.15, max = 0.25)
set.seed(2)
incremanet <- runif(running_times, min = 0.0002, max = 0.002)
beta_function <- function(time) { if (time <= turning_point) {return(minimum_1)} else {return( minimum_2[j]+incremanet[j]*(time-turning_point) ) }}

# Initial number of individuals in each compartment
initial_state_values <- c(S = 99, E = 1, I = 0, R = 0)
# Parameters for the model
parameters <- c(sigma = 0.5, gamma = 0.1)
# Time sequence: from day 0 to day 160 in daily intervals
times <- seq(1, 200, by = 1)
# Solve the differential equations
result <- ode(y = initial_state_values, times = times, func = seir_model, parms = parameters) #, method = "ode45"
# Convert result to a data frame for plotting
result_df <- as.data.frame(result)
#R_e
R_naught <- c(rep(minimum_1, turning_point), minimum_2[j]+incremanet[j]*(101:200-turning_point)  )/(parameters[2])
R_e <- R_naught*result_df$S/apply(result_df[,2:5], 1, sum)
result_df$Re =R_e
#
my_list[[j]]=result_df
result_df=NULL
   
    } # for loop
  
  return(my_list)
}


results_1=SEIR_noNoise(running_times=1000)
save(results_1, file = "SEIR_noNoise1000.RData")


# Plot SEIR time series
p1 <- ggplot(data = results_1[[1]], aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "SIR Model with Noise in I",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))


p2 <- ggplot(data =  results_1[[1]], aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number (Re) over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

grid.arrange(p1, p2, ncol = 1)


################################################
######### Part 4.1: time-varying beta ########## absolute abundance,  noise
################################################


##### good 1
SEIR_Noise<- function(running_times) {
  
  my_list <- list()
  
  for (j in 1:running_times){
    
set.seed(2)
minimum_2 <- runif(running_times, min = 0.15, max = 0.25)[j]
set.seed(2)
incremanet <- runif(running_times, min = 0.0002, max = 0.002)[j]

# Lotka-Volterra model with noise only for prey
lotka_volterra_noise_prey <- function(t, state, parameters, delta_t, noise, minimum_2,incremanet) {
  
  
  # Unpack state variables
  S = state[1]
  E = state[2]
  I = state[3]
  R = state[4]
  
  # Unpack parameters 
  turning_point=100;minimum_1=0.0005

  beta_function <- function(t) { if (t <= turning_point) {return(minimum_1)} else {return( minimum_2+incremanet*(t-turning_point) ) }} # Define a function for beta as a time-varying parameter
  sigma = parameters['sigma']
  gamma = parameters['gamma']
  delta = parameters['delta']
  sigma_x = parameters['sigma_x']
  
  #
  dS <- (-beta_function(t) * S * I) * delta_t
  dE <- (beta_function(t) * S * I - sigma * E) * delta_t
  dI <- (sigma * E - gamma * I ) * delta_t+sigma_x * rnorm(1, mean = 0, sd = sqrt(noise))
  dR <- (gamma * I) * delta_t
  
  new_S = max(S + dS,0)
  new_E = max(E + dE,0)
  new_I = max(I + dI,0)
  new_R = max(R + dR,0)
  
  return(c(new_S, new_E,new_I,new_R))
}



# Initial conditions and parameters
initial_state = c(S = 99, E = 1, I = 0, R = 0)

parameters = c(sigma = 0.5, gamma = 0.1, delta=0.01, sigma_x=1)
times = seq(0, 200, by=1)
delta_t = times[2] - times[1]

# Simulate using Euler method with noise for prey
result = as.data.frame( matrix(0, length(times), 4) )
colnames(result) = c("S", "E","I", "R")
result[1,] = initial_state
noise=1

set.seed(2)
for (i in 2:length(times)) {
  result[i,] = lotka_volterra_noise_prey(times[i], result[i-1,], parameters, delta_t, noise, minimum_2,incremanet)
}

# Re
turning_point=100;minimum_1=0.0005
set.seed(2)
minimum_2 <- runif(running_times, min = 0.15, max = 0.2)[j]
set.seed(2)
incremanet <- runif(running_times, min = 0.0002, max = 0.002)[j]
R_naught <- c(rep(minimum_1, length(seq(0, turning_point, by=1))), minimum_2+incremanet*(seq(101, 200, by=1)-turning_point)  )/(parameters["gamma"])
R_e <- R_naught*result[,"S"]/apply(result[,1:4], 1, sum)
R_e
max(R_e)
#
result$Re=R_e
#
result$time=times

#
my_list[[j]]=result
result=NULL

   } # for loop

return(my_list)
}


results_2=SEIR_Noise(running_times=1000)
save(results_2, file = "SEIR_Noise1000.RData")




# Plot SEIR time series
p1 <- ggplot(data = results_2[[1]], aes(x = time)) +
  geom_line(aes(y = S, color = "S"), lwd = 2) +
  geom_line(aes(y = I, color = "I"), lwd = 2) +
  geom_line(aes(y = R, color = "R"), lwd = 2) +
  labs(title = "SIR Model with Noise in I",
       x = "Time",
       y = "Population") +
  theme_minimal() +
  scale_color_manual(values = c("S" = "blue", "I" = "red", "R" = "green"),
                     name = "",
                     breaks = c("S", "I", "R"),
                     labels = c("Susceptible", "Infected", "Recovered"))


p2 <- ggplot(data =  results_2[[1]], aes(x = time)) +
  geom_line(aes(y = Re), color = "purple", lwd = 2) +
  labs(title = "Effective Reproductive Number (Re) over Time",
       x = "Time",
       y = "Re") +
  theme_minimal()

grid.arrange(p1, p2, ncol = 1)



